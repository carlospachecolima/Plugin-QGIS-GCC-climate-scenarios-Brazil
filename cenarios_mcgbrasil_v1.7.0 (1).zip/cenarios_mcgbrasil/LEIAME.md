# Cenários MCGBrasil (v1.2.2)

Complemento QGIS para elaborar **cenários climáticos dos Modelos de Circulação Geral (CMIP6) para o Brasil** a partir do WorldClim v2.1, com correção de viés pelas estações do INMET. Desenvolvido na Embrapa Hortaliças. Versão em inglês: *MCGBrasil Climate Scenarios*.

## Instalação

1. QGIS 3.30 a 3.44 ou QGIS 4.x (testado no 3.34 e no 4.2.3): **Complementos › Gerenciar e instalar complementos › Instalar a partir de ZIP**.
2. Escolha `cenarios_mcgbrasil_v1.2.2.zip` e clique em **Instalar complemento**.
3. Não é preciso instalar bibliotecas: o complemento usa o GDAL e o numpy do QGIS.

## Uso

Abra o **painel do fluxo por fases** pelo ícone na barra de ferramentas (ou *Complementos › Cenários MCGBrasil*). Escolha uma vez a **pasta do projeto**: cada fase grava na sua subpasta e lê a anterior.

| Fase | O que faz | Método | Situação |
|---|---|---|---|
| 1 – Cenários climáticos | WorldClim v2.1 recortado pela área: histórico 1970–2000 e projeções CMIP6 | Fontenelle et al. (2025), *Revista DCS*, doi:10.54899/dcs.v22i83.3456 | pronta |
| 2 – Correção de viés pelo método Delta | Estações do INMET escolhidas automaticamente, delta mensal e r de Pearson | Lima et al. (2026), *Land Degrad. Dev.*, doi:10.1002/ldr.70808, seção 2.6 | pronta |
| 3 – Avaliação de tendência do cenário | Taxas das normais do INMET × taxas projetadas | idem, seção 2.7 | pronta |
| 4 – Comparação WorldClim × Eta histórico (opcional) | Correlação WorldClim × Eta-HadGEM2-ES × INMET | idem, seção 2.8 | em desenvolvimento |

### Fase 1 – tela de seleção (etapa 1.1)

Marque:

- **Variáveis:** Tmin, Tmax, Tmed (média entre Tmin e Tmax), Prec e Evapotranspiração (método de Thornthwaite);
- **Períodos:** 2021–2040, 2041–2060, 2061–2080, 2081–2100 (e o histórico 1970–2000);
- **Cenários:** SSP1 2.6, SSP2 4.5, SSP3 7.0, SSP5 8.5;
- **Modelos:** os 14 GCMs do WorldClim a 30″ (ACCESS-CM2, BCC-CSM2-MR, CMCC-ESM2, EC-Earth3-Veg, FIO-ESM-2-0, GFDL-ESM4, GISS-E2-1-G, HadGEM3-GC31-LL, INM-CM5-0, IPSL-CM6A-LR, MIROC6, MPI-ESM1-2-HR, MRI-ESM2-0, UKESM1-0-LL).

Enquanto você marca, a tela informa **as combinações sem dados no WorldClim** (FIO-ESM-2-0 e HadGEM3-GC31-LL não têm SSP3 7.0; GFDL-ESM4 não tem SSP2 4.5 e, no SSP5 8.5, só tem precipitação) e quantos arquivos serão baixados. Essas combinações são puladas e listadas em `disponibilidade_pt.txt`; as demais seguem normalmente.

O complemento baixa só o retângulo que envolve a área, recorta cada mês pela máscara e gera, para cada grupo de 12 meses, estatísticas (média, mediana, desvio-padrão, IC 95%, área por classe), projeto .qgz, 12 layouts e 12 PNG em português e inglês. Arquivos já baixados e grupos já processados são mantidos.

- **Tmed** = (Tmin + Tmax)/2.
- **ETP** de Thornthwaite (1948) a partir das 12 Tmed do mesmo cenário, com a equação de Willmott et al. (1985) para T ≥ 26,5 °C e correção pelo fotoperíodo da latitude de cada pixel. Tmed e ETP exigem Tmin e Tmax, que são incluídas automaticamente.

Outras etapas: **1.2** histórico com arquivo já baixado, **1.3** projeção com imagem já baixada, **1.4** calcular Tmed e ETP para cenários montados com 1.2 e 1.3.

**Índices.** Além de Tmin, Tmax, Tmed, Prec e ETP (Thornthwaite), a tela de seleção oferece: **IA** – índice de aridez P/ETP, mensal e anual, com as classes da UNEP-WCMC (úmido ≥ 0,65; subúmido seco 0,50–0,65; semiárido 0,20–0,50; árido 0,05–0,20; hiperárido < 0,05), como em Lima et al. (2026, *Land Degradation & Development*); **PCI** – índice de concentração de precipitação anual de Oliver (1980), com as classes uniforme (≤ 10), moderada (10–15), alta (15–20) e muito alta (> 20); **ISC** – índice de severidade de chuvas anual, ISC = PCI × R/P, com R = Σ 68,730·(p²/P)^0,841 (Lima et al., 2025, *Revista Aracê*). As variáveis de origem são baixadas automaticamente. O valor anual aparece como *Anual* nos arquivos e mapas. A etapa 1.4 calcula os índices em projetos já prontos.

**Mapas e escala de cores.** Os layouts e PNG são gerados por último, depois de todos os rasters (inclusive Tmed, ETP e ensemble). A escala de cada variável é a mesma em todos os mapas, do histórico a 2100 e nas Fases 1 e 2: vai do mínimo ao máximo de todos os cenários do projeto (sem correção e corrigidos), para que nenhum cenário futuro sature a paleta e os mapas sejam comparáveis entre si; uma escala fixa pode ser informada em *Parâmetros avançados*. A etapa **1.6** refaz os mapas de um projeto já pronto (Fase 1 ou 2), por exemplo os feitos com versões anteriores.

**Ensemble de modelos.** Na tela de seleção, marque *Gerar ensemble de modelos* e escolha os modelos que entram na média (botão *Mesmos do download* copia a seleção acima). Para projetos já prontos, use a etapa **1.5**, na Fase 1 (sem correção) ou na Fase 2 (corrigida). O ensemble é a média aritmética, pixel a pixel e mês a mês, dos modelos marcados que têm dados naquele cenário (pesos iguais); a tela informa quantos modelos entram em cada SSP e quais ficam de fora (ex.: GFDL-ESM4 no SSP2 4.5). Tmed e ETP do ensemble são a média das Tmed e ETP dos modelos. O resultado fica como o modelo `Ensemble` (`tmax/2041-2060/Ensemble/SSP245`), com estatísticas, layouts e PNG; a subpasta `incerteza` traz o desvio-padrão e a amplitude entre modelos e a lista dos modelos usados. A Fase 2 refaz o ensemble a partir dos modelos corrigidos, com os mesmos modelos, e o AdaptaHorts pode usá-lo como qualquer modelo.

### Fase 2 – 2.1 Método Delta e correlação (estações INMET)

Entradas: (1) o **.zip dos rasters da Fase 1**, que você compacta (a pasta `1_cenarios_climaticos` do projeto ou o projeto inteiro; o complemento acha a Fase 1 dentro do .zip, ignora PNG e `.qgz` e registra o SHA-256 do arquivo); (2) a **pasta de saída**, vazia (ou uma Fase 2 anterior, com *Refazer*). O banco mensal do INMET/BDMEP já vem no complemento (565 estações convencionais e 598 automáticas de todo o país, 1970–2020). A Fase 3 e o AdaptaHorts aceitam a pasta de saída da Fase 2 diretamente. Outro banco exportado do portal do INMET pode ser usado em *Parâmetros avançados*. As estações são escolhidas pela distância ao local de mapeamento (a área do projeto, um município ou estação pelo nome, `Propriá - SE`, ou latitude/longitude): padrão desde a v1.7.0, até 200 km, sem ampliação, só com estações que têm ao menos 120 meses (10 anos) de dados no período e r de Pearson ≥ 0,8 entre as suas médias mensais e as do WorldClim em Tmax, Tmin e Prec (a estação que falha em qualquer critério é eliminada); o critério do artigo (mesma UF ou raio) continua disponível. Antes da média regional, as temperaturas de cada estação são levadas à altitude média da área pelo gradiente térmico (0,65 °C/100 m), com a elevação do WorldClim (`wc2.1_30s_elev`, salva pela etapa 1.1 em `entradas/` ou baixada pela Fase 2). A precipitação é corrigida por fator multiplicativo (observado ÷ WorldClim, limitado a 0,5–2,0 nos meses com WorldClim < 10 mm); o aditivo do artigo é opcional. Arquivos do INMET com cabeçalho incompleto são lidos pela ordem padrão das colunas do BDMEP. Saídas em `<pasta de saída>/correcao_vies/`: estações (CSV e GeoPackage), médias regionais, `delta_<var>_pt|en.csv` (formato das Tabelas 1–3 do artigo), correlação e relatório. Com **Aplicar**, todos os rasters da Fase 1 são corrigidos; Tmed e ETP são recalculadas a partir de Tmin e Tmax corrigidos.

### Fase 3 – 3.1 Taxas das normais do INMET × taxas projetadas

As normais climatológicas oficiais do INMET (1961–1990, 1981–2010 e 1991–2020: Tmax, Tmin, temperatura média compensada, precipitação acumulada e evapotranspiração potencial) já vêm no complemento. Por padrão, as estações ficam a até 200 km do local (critério só raio). A comparação é sempre entre a **média do raster** (pixels da área de estudo) e a **média das normais** das estações selecionadas; a Tmed das normais é (Tmax + Tmin)/2, igual à dos rasters. A **taxa de aumento ou diminuição** é calculada em unidades da variável por ano, do último ano em relação ao primeiro ano da série:

taxa = (valor do último período − valor do primeiro período) ÷ (último ano do último período − primeiro ano do primeiro período)

- Normais: 1961–1990 → 1991–2020 = 59 anos. A ETP só tem normal a partir de 1981–2010 (39 anos).
- Projeções CMIP6: do primeiro ao último período futuro do projeto (2021–2040 → 2081–2100 = 79 anos), por modelo e SSP e na média do conjunto de modelos.
- Mês a mês e no ano (média das temperaturas; soma de precipitação e ETP). Por padrão, em cada mês só entram as estações com normal no primeiro e no último período (pareadas). Se nenhuma estação pareada fechar os 12 meses, usa-se o par de períodos seguinte mais longo e, se preciso (ou se algum mês tiver menos de 3 estações pareadas), o raio é ampliado em passos de 100 km até 500 km; o relatório registra as duas coisas.
- Comparação: razão entre a taxa anual projetada e a observada e r de Pearson entre as 12 taxas mensais.

Saídas em `3_tendencia_normais/`: estações (CSV e GeoPackage), normais regionais, `taxas_pt|en.csv`, taxas por estação, comparação raster × normais e relatório.

### Pasta do projeto

```
<projeto>/
    projeto_mcgbrasil.json
    1_cenarios_climaticos/   <var>/historico/WorldClim/…  e  <var>/<período>/<modelo>/<SSP>/…
    2_correcao_delta/        mesma organização, corrigida, e correcao_vies/
    3_tendencia_normais/     taxas observadas e projetadas
```

O complemento **AdaptaHorts – Risco Climático para Hortaliças** usa esta pasta como entrada climática.

## Responsabilidade

Os cenários são projeções de modelos, com incertezas; use o conjunto de modelos e confira os resultados com dados locais antes de apoiar decisões.

## Integridade

`SHA256SUMS.txt` traz o SHA-256 de cada arquivo do complemento; o `.sha256` ao lado do ZIP confere o pacote inteiro (`sha256sum -c`).
