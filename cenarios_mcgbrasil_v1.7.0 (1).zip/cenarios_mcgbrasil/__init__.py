"""Cenários MCGBrasil / MCGBrasil Climate Scenarios — cenários climáticos CMIP6 (WorldClim v2.1) para o Brasil."""


def classFactory(iface):  # noqa: N802 (nome exigido pelo QGIS)
    from .plugin import MCGBrasilPlugin
    return MCGBrasilPlugin(iface)
