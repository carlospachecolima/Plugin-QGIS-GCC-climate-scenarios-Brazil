"""Fase 1 – Cenários climáticos (Fontenelle et al., 2025, Revista DCS, doi:10.54899/dcs.v22i83.3456).

1.1 Elaborar cenários: escolhe variáveis, períodos, SSPs e modelos; baixa do WorldClim v2.1 e mapeia o histórico
    1970–2000 e as projeções CMIP6; calcula Tmed e ETP (Thornthwaite) quando pedidas; informa as combinações
    sem dados.
1.2 Histórico com arquivo já baixado (uma variável).
1.3 Projeção com imagem já baixada (12 bandas).
1.4 Calcular Tmed e ETP (para pastas montadas com 1.2 e 1.3).
1.5 Ensemble de modelos (média dos modelos marcados), também disponível na tela da 1.1.
"""

from __future__ import annotations

import json
from pathlib import Path

from qgis.core import (QgsProcessing, QgsProcessingException, QgsProcessingOutputFile, QgsProcessingOutputNumber,
                       QgsProcessingOutputString, QgsProcessingParameterBoolean, QgsProcessingParameterDefinition,
                       QgsProcessingParameterEnum, QgsProcessingParameterFile, QgsProcessingParameterMultipleLayers,
                       QgsProcessingParameterNumber, QgsProcessingParameterRasterLayer, QgsProcessingParameterString,
                       QgsProcessingParameterVectorLayer)

from . import projeto as PJ
from .base import (VERSAO_COMPLEMENTO, _Base, _erro_processamento, _exportar_vetor, _Feedback, _ler_simbologia,
                   _nome_camada, _pasta_temp, _tr)
from .cenarios import catalogo as C
from .idioma import IDIOMA, T

L = "en" if IDIOMA == "en" else "pt"
SSP_ROTULOS = [C.SSP_ARTIGO[s] for s in C.SSPS]
VAR_TELA = {
    "tmin": T("Tmin – temperatura mínima (°C)", "Tmin – minimum temperature (°C)"),
    "tmax": T("Tmax – temperatura máxima (°C)", "Tmax – maximum temperature (°C)"),
    "tmed": T("Tmed – média entre Tmin e Tmax (°C)", "Tmean – mean of Tmin and Tmax (°C)"),
    "prec": T("Prec – precipitação (mm)", "Prec – precipitation (mm)"),
    "etp": T("Evapotranspiração potencial – Thornthwaite (mm)", "Potential evapotranspiration – Thornthwaite (mm)"),
    "ia": T("IA – índice de aridez P/ETP, mensal e anual (UNEP)", "AI – aridity index P/PET, monthly and annual (UNEP)"),
    "pci": T("PCI – índice de concentração de precipitação, anual (Oliver, 1980)",
             "PCI – precipitation concentration index, annual (Oliver, 1980)"),
    "isc": T("ISC – índice de severidade de chuvas, anual (PCI × R/P)",
             "ISC – rainfall severity index, annual (PCI × R/P)"),
}
VAR_ROTULOS_BASE = [VAR_TELA[v] for v in C.VARIAVEIS]
DERIV = ("tmed", "etp", "ia", "pci", "isc")
AUTO = T("Automático (pelo nome do arquivo)", "Automatic (from the file name)")
IDIOMAS_ROTULOS = ["Português", "English"]
GRUPO = T("Fase 1 – Cenários climáticos", "Phase 1 – Climate scenarios")


SIGLA = {"pt": {"tmin": "Tmin", "tmax": "Tmax", "tmed": "Tmed", "prec": "Prec", "etp": "ETP", "ia": "IA",
                "pci": "PCI", "isc": "ISC"},
         "en": {"tmin": "Tmin", "tmax": "Tmax", "tmed": "Tmean", "prec": "Prec", "etp": "PET", "ia": "AI",
                "pci": "PCI", "isc": "ISC"}}


def rotulo_ausencias(faltas: list[dict], lang: str = L) -> list[str]:
    """Texto das combinações sem dados no WorldClim (tela e relatório)."""
    out = []
    for f in faltas:
        vs = ", ".join(SIGLA[lang][v] for v in f["variaveis"])
        pers = ", ".join(f["periodos"])
        if lang == "en":
            out.append(f"{f['modelo']} – {C.SSP_ARTIGO[f['ssp']]}: no data for {vs} ({pers})")
        else:
            out.append(f"{f['modelo']} – {C.SSP_ARTIGO[f['ssp']]}: sem dados de {vs} ({pers})")
    return out


AJUDA_FONTE = T(
    "<p><b>Dados:</b> WorldClim v2.1 (Fick &amp; Hijmans, 2017), 30″ (~1 km²): histórico 1970–2000 e 14 modelos "
    "CMIP6 (" + ", ".join(C.MODELOS) + "). FIO-ESM-2-0 e HadGEM3-GC31-LL não têm SSP3 7.0; GFDL-ESM4 não tem "
    "SSP2 4.5 e, no SSP5 8.5, só tem precipitação. Quando faltam dados, o complemento informa e segue com o resto.</p>",
    "<p><b>Data:</b> WorldClim v2.1 (Fick &amp; Hijmans, 2017), 30″ (~1 km²): 1970–2000 historical data and 14 CMIP6 "
    "models (" + ", ".join(C.MODELOS) + "). FIO-ESM-2-0 and HadGEM3-GC31-LL have no SSP3 7.0; GFDL-ESM4 has no "
    "SSP2 4.5 and only precipitation under SSP5 8.5. Missing combinations are reported and skipped.</p>")

AJUDA_PASTAS = T(
    "<p><b>Pasta do projeto</b>: use sempre a mesma pasta em todas as fases. A Fase 1 grava em "
    "<i>1_cenarios_climaticos</i>, com um grupo de 12 rasters mensais por pasta: "
    "<i>prec/historico/WorldClim/prec_historico_WorldClim_Jan.tif</i> … e "
    "<i>prec/2021-2040/ACCESS-CM2/SSP126/prec_2021-2040_ACCESS-CM2_SSP126_Jan.tif</i> …; em cada grupo, "
    "<i>estatisticas_pt|en</i> (12 relatórios e a tabela), <i>mapas_pt|en</i> (12 PNG) e os projetos .qgz com os "
    "12 layouts. Na raiz, <i>manifesto_cenarios.json</i> (entrada das fases seguintes e dos índices de risco) e "
    "<i>disponibilidade_pt|en.txt</i>.</p>",
    "<p><b>Project folder</b>: always use the same folder in every phase. Phase 1 writes to "
    "<i>1_cenarios_climaticos</i>, one group of 12 monthly rasters per folder: "
    "<i>prec/historico/WorldClim/prec_historico_WorldClim_Jan.tif</i> … and "
    "<i>prec/2021-2040/ACCESS-CM2/SSP126/prec_2021-2040_ACCESS-CM2_SSP126_Jan.tif</i> …; in each group, "
    "<i>estatisticas_pt|en</i> (12 reports and the table), <i>mapas_pt|en</i> (12 PNG) and the .qgz projects with "
    "the 12 layouts. At the root, <i>manifesto_cenarios.json</i> (input for the next phases and for the risk "
    "indices) and <i>disponibilidade_pt|en.txt</i>.</p>")

AJUDA_LOTE = T(
    "<p>Fluxo de Fontenelle et al. (2025), <i>Revista DCS</i>, doi:10.54899/dcs.v22i83.3456: recorte pela máscara, "
    "separação das 12 bandas, nomes padronizados, simbologia (.qml), projeto .qgz e, por último, 12 relatórios de "
    "estatísticas (média, mediana, desvio-padrão, IC 95%, área por classe), 12 layouts e 12 PNG em alta resolução, "
    "em português e inglês.</p>",
    "<p>Workflow of Fontenelle et al. (2025), <i>Revista DCS</i>, doi:10.54899/dcs.v22i83.3456: mask clipping, "
    "splitting into 12 bands, standard names, symbology (.qml), .qgz project and, last, 12 statistics reports "
    "(mean, median, SD, 95% CI, area by class), 12 layouts and 12 high-resolution PNG, in Portuguese and "
    "English.</p>")

AJUDA_ENSEMBLE = T(
    "<p><b>Ensemble</b>: média aritmética, pixel a pixel e mês a mês, dos modelos marcados (pesos iguais), para cada "
    "variável, cenário e período. Entram só os modelos com os 12 meses no projeto; os que não têm dados naquele "
    "cenário (ex.: GFDL-ESM4 no SSP2 4.5) ficam de fora e são informados. Tmed e ETP do ensemble são a média das "
    "Tmed e ETP dos modelos. O resultado fica como o modelo <i>Ensemble</i> (<i>tmax/2041-2060/Ensemble/SSP245</i>), "
    "com estatísticas, layouts e PNG, e segue para a correção de viés, para a Fase 3 e para o AdaptaHorts. Na "
    "subpasta <i>incerteza</i> ficam o desvio-padrão e a amplitude entre os modelos, mês a mês.</p>",
    "<p><b>Ensemble</b>: arithmetic mean, pixel by pixel and month by month, of the selected models (equal weights), "
    "for each variable, scenario and period. Only models with all 12 months in the project are used; those with no "
    "data for that scenario (e.g., GFDL-ESM4 under SSP2 4.5) are left out and reported. The ensemble Tmean and PET "
    "are the mean of each model's Tmean and PET. The result is stored as the model <i>Ensemble</i> "
    "(<i>tmax/2041-2060/Ensemble/SSP245</i>), with statistics, layouts and PNG, and feeds bias correction, Phase 3 "
    "and AdaptaHorts. The <i>incerteza</i> subfolder holds the between-model standard deviation and range, month by "
    "month.</p>")

AJUDA_DERIVADAS = T(
    "<p><b>Tmed</b> = (Tmin + Tmax)/2. <b>ETP</b> de Thornthwaite (1948) a partir das 12 Tmed do mesmo cenário, com "
    "a equação de Willmott et al. (1985) para T ≥ 26,5 °C e correção pelo fotoperíodo da latitude de cada pixel. "
    "Ambas exigem Tmin e Tmax, que são incluídas automaticamente.</p>"
    "<p><b>Índices</b> (as variáveis de origem são incluídas automaticamente): <b>IA</b> = P/ETP, mensal e anual "
    "(ΣP/ΣETP), com a ETP de Thornthwaite e as classes da UNEP-WCMC (2007): úmido ≥ 0,65; subúmido seco 0,50–0,65; "
    "semiárido 0,20–0,50; árido 0,05–0,20; hiperárido &lt; 0,05 (Lima et al., 2026, Land Degrad. Dev.). "
    "<b>PCI</b> = 100·Σp²/(Σp)², anual (Oliver, 1980): ≤ 10 uniforme; 10–15 moderada; 15–20 alta; &gt; 20 muito "
    "alta concentração. <b>ISC</b> = PCI × R/P, anual, com R = Σ 68,730·(p²/P)^0,841 (Lima et al., 2025, Revista "
    "Aracê). O valor anual aparece como <i>Anual</i> no nome dos arquivos e nos mapas.</p>",
    "<p><b>Tmean</b> = (Tmin + Tmax)/2. <b>PET</b> by Thornthwaite (1948) from the 12 Tmean of the same scenario, "
    "with the Willmott et al. (1985) equation for T ≥ 26.5 °C and day-length correction by each pixel's latitude. "
    "Both need Tmin and Tmax, which are added automatically.</p>"
    "<p><b>Indices</b> (source variables are added automatically): <b>AI</b> = P/PET, monthly and annual "
    "(ΣP/ΣPET), with Thornthwaite PET and the UNEP-WCMC (2007) classes: humid ≥ 0.65; dry subhumid 0.50–0.65; "
    "semi-arid 0.20–0.50; arid 0.05–0.20; hyper-arid &lt; 0.05 (Lima et al., 2026, Land Degrad. Dev.). "
    "<b>PCI</b> = 100·Σp²/(Σp)², annual (Oliver, 1980): ≤ 10 uniform; 10–15 moderate; 15–20 high; &gt; 20 very high "
    "concentration. <b>ISC</b> = PCI × R/P, annual, with R = Σ 68.730·(p²/P)^0.841 (Lima et al., 2025, Revista "
    "Aracê). The annual value appears as <i>Annual</i> in file names and maps.</p>")


def _area(alg, parameters, context, pasta_fase1: Path) -> Path:
    """Área de estudo informada ou, se vazia, a já gravada no projeto."""
    lyr = alg.parameterAsVectorLayer(parameters, "AREA", context)
    if lyr is not None:
        return _exportar_vetor(lyr, Path(_pasta_temp()) / f"{_nome_camada(lyr)}.gpkg")
    a = Path(pasta_fase1) / C.PASTAS["entradas"] / "area_estudo.gpkg"
    if a.exists():
        return a
    raise QgsProcessingException(T("Informe a área de estudo (o projeto ainda não tem uma).",
                                   "Choose the study area (the project does not have one yet)."))


def _param_area(P):
    P(QgsProcessingParameterVectorLayer("AREA", _tr(T("Área de estudo – máscara (polígono). Vazio = a já usada no "
                                                      "projeto", "Study area – mask (polygon). Empty = the one "
                                                      "already used in the project")),
                                        [QgsProcessing.TypeVectorPolygon], optional=True))


def _param_projeto(P, nome: str):
    P(QgsProcessingParameterFile(nome, _tr(T("Pasta do projeto (a mesma em todas as fases)",
                                             "Project folder (the same in every phase)")),
                                 behavior=QgsProcessingParameterFile.Folder))


def _params_saida(P):
    P(QgsProcessingParameterString("REGIAO", _tr(T("Nome da região (entra nos títulos)",
                                                   "Region name (used in the titles)")), optional=True))
    P(QgsProcessingParameterEnum("IDIOMAS", _tr(T("Idiomas dos relatórios e mapas", "Languages of reports and maps")),
                                 IDIOMAS_ROTULOS, allowMultiple=True, defaultValue=[0, 1]))
    P(QgsProcessingParameterBoolean("GERAR_MAPAS", _tr(T("Gerar simbologia, projetos .qgz, layouts e PNG",
                                                         "Create symbology, .qgz projects, layouts and PNG")),
                                    defaultValue=True))
    P(QgsProcessingParameterNumber("DPI", _tr(T("Resolução dos PNG (dpi)", "PNG resolution (dpi)")),
                                   defaultValue=300, minValue=150, maxValue=1200))
    P(QgsProcessingParameterString("AUTOR", _tr(T("Elaboração (rodapé dos mapas)", "Prepared by (map footer)")),
                                   optional=True))


def _cfg_saida(alg, parameters, context) -> dict:
    return {"idiomas": [("pt", "en")[i] for i in alg.parameterAsEnums(parameters, "IDIOMAS", context)] or [L],
            "gerar_mapas": alg.parameterAsBool(parameters, "GERAR_MAPAS", context),
            "dpi": alg.parameterAsInt(parameters, "DPI", context),
            "regiao": alg.parameterAsString(parameters, "REGIAO", context).strip(),
            "autor": alg.parameterAsString(parameters, "AUTOR", context).strip(),
            "versao": VERSAO_COMPLEMENTO}


def _ler_manifesto(pasta: Path) -> dict:
    from .cenarios.manual import MANIFESTO
    p = pasta / MANIFESTO
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}


def _mapas(pasta: Path, cfg: dict, feedback, forcar: bool = False) -> dict:
    """Layouts e PNG por último, com escala de cores única por variável (cenarios/mapas.py)."""
    from .cenarios import mapas as MP
    man = _ler_manifesto(pasta)
    if not man or not cfg.get("gerar_mapas"):
        return {"grupos": 0, "png": 0, "escalas": {}}
    fb = _Feedback(feedback)
    feedback.pushInfo(T("Gerando os mapas com escala única por variável (do mínimo ao máximo de todos os cenários "
                        "da pasta)…", "Generating maps with a single scale per variable (from the minimum to the "
                        "maximum of all scenarios in the folder)…"))
    outras = []   # as outras fases do projeto (ex.: 2_correcao_delta) entram na amplitude: mesma escala em todas
    fases = {f["pasta"] for f in PJ.FASES if f["n"] in (1, 2)}
    vizinhas = sorted(Path(pasta).parent.iterdir()) if Path(pasta).name in fases else []
    for irma in vizinhas:
        mi = irma / "manifesto_cenarios.json"
        if irma.name in fases and irma.resolve() != Path(pasta).resolve() and mi.exists():
            try:
                outras.append((irma, json.loads(mi.read_text(encoding="utf-8"))))
            except (OSError, ValueError):
                pass
    r = MP.gerar(pasta, man, {**cfg, "qml": None}, prog=fb.progresso, cancelado=fb.cancelado, forcar=forcar,
                 outras=outras)
    for v, e in r["escalas"].items():
        feedback.pushInfo(f"   {v}: {e['min']:g} a {e['max']:g}")
    if outras:
        feedback.pushInfo(T("   A amplitude inclui também: ", "   The range also includes: ")
                          + ", ".join(o.name for o, _ in outras))
    if r["faltam"]:
        por: dict = {}
        for v, f in sorted(r["faltam"].items()):
            por.setdefault(", ".join(f), []).append(v)
        lista = "; ".join(f"{', '.join(vs)}: {f}" for f, vs in por.items())
        feedback.pushWarning(T(f"A escala ainda não cobre todo o intervalo do histórico a 2081–2100 (faltam {lista}). "
                               "Quando esses períodos forem processados, a amplitude será ampliada e os mapas serão "
                               "refeitos automaticamente; depois, rode a etapa 1.6 na outra fase, se houver.",
                               f"The scale does not yet cover the whole range from historical to 2081–2100 (missing "
                               f"{lista}). When those periods are processed, the range will be widened and the maps "
                               "redone automatically; then run step 1.6 on the other phase, if any."))
    feedback.pushInfo(T(f"   {r['grupos']} grupo(s) com mapas novos, {r['png']} PNG.",
                        f"   {r['grupos']} group(s) with new maps, {r['png']} PNG."))
    return r


def _derivadas(pasta: Path, cfg: dict, variaveis: list[str], feedback, mapas: bool = True) -> dict:
    """Calcula Tmed e ETP para todas as combinações com Tmin e Tmax na pasta da Fase 1."""
    from .cenarios import derivadas as DV
    man = _ler_manifesto(pasta)
    if not man:
        return {"grupos": 0, "png": 0, "ja_existiam": 0}
    fb = _Feedback(feedback)
    avisos: list[str] = []
    mcfg = {**cfg, "classes": {}, "qml": None, "gerar_mapas": False}

    def prog(p, m):
        if fb.cancelado():
            from .comum.config import Cancelado
            raise Cancelado("cancelado")
        fb.progresso(p, m)

    r = DV.calcular(pasta, man, mcfg, variaveis, avisos, prog=prog)
    for a in avisos:
        feedback.pushWarning(a)
    if mapas:
        r["png"] = _mapas(pasta, cfg, feedback)["png"]
    return r


def _ensemble(pasta: Path, cfg: dict, modelos: list[str], feedback, variaveis=None, ssps=None, periodos=None,
              min_modelos: int = 2, mapas: bool = True) -> dict:
    """Ensemble dos modelos marcados para todas as combinações do projeto (ou as filtradas)."""
    from .cenarios import ensemble as EN
    man = _ler_manifesto(pasta)
    if not man:
        return {"grupos": 0, "png": 0, "mantidos": 0, "pulados": 0}
    alvos, faltas = EN.planejar(man, modelos, variaveis, ssps, periodos)
    for t in EN.rotulo_faltas(faltas, L):
        feedback.pushInfo(T("   modelo(s) marcado(s) fora do ensemble, sem dados: ", "   selected model(s) left out "
                            "of the ensemble, no data: ") + t)
    fb = _Feedback(feedback)
    avisos: list[str] = []

    def prog(p, m):
        if fb.cancelado():
            from .comum.config import Cancelado
            raise Cancelado("cancelado")
        fb.progresso(p, m)

    for a in alvos:
        a["sem"] = [m for m in modelos if m not in a["membros"]]
    r = EN.calcular(pasta, man, {**cfg, "classes": {}, "qml": None, "gerar_mapas": False}, alvos, avisos, prog=prog,
                    min_modelos=min_modelos)
    for a in avisos:
        feedback.pushWarning(a)
    if mapas:
        r["png"] = _mapas(pasta, cfg, feedback)["png"]
    return r


def _param_ensemble(P, padrao: bool):
    P(QgsProcessingParameterBoolean("ENSEMBLE", _tr(T("Gerar o ensemble (média dos modelos marcados abaixo)",
                                                      "Build the ensemble (mean of the models selected below)")),
                                    defaultValue=padrao))
    P(QgsProcessingParameterEnum("MODELOS_ENSEMBLE", _tr(T("Modelos do ensemble (vazio = todos os escolhidos)",
                                                           "Ensemble models (empty = all selected models)")),
                                 list(C.MODELOS), allowMultiple=True, optional=True, defaultValue=[]))
    par = QgsProcessingParameterNumber("MIN_ENSEMBLE", _tr(T("Mínimo de modelos com dados para formar o ensemble",
                                                             "Minimum number of models with data to form the "
                                                             "ensemble")), defaultValue=2, minValue=2, maxValue=14)
    par.setFlags(par.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
    P(par)


# ============================================================================= 1.1 elaborar cenários
class AlgElaborar(_Base):
    def name(self):
        return "elaborar_cenarios"

    def displayName(self):  # noqa: N802
        return _tr(T("1.1 Elaborar cenários climáticos (histórico e projeções CMIP6)",
                     "1.1 Build climate scenarios (historical and CMIP6 projections)"))

    def group(self):
        return _tr(GRUPO)

    def groupId(self):  # noqa: N802
        return "mcgbrasil_fase1"

    def flags(self):
        return super().flags() | self.FlagNoThreading  # layouts PyQGIS no thread principal

    def shortHelpString(self):  # noqa: N802
        return T(
            "<p>Marque as <b>variáveis</b> (Tmin, Tmax, Tmed, Prec, evapotranspiração de Thornthwaite), os "
            "<b>períodos</b> (2021–2040 a 2081–2100), os <b>cenários</b> (SSP1 2.6, SSP2 4.5, SSP3 7.0, SSP5 8.5) e "
            "os <b>modelos</b> CMIP6. O complemento baixa do WorldClim v2.1 só o retângulo da área, mapeia o "
            "histórico 1970–2000 e cada projeção, e calcula as variáveis derivadas. As combinações sem dados no "
            "WorldClim são informadas no início e no arquivo <i>disponibilidade_pt.txt</i>, e as demais seguem "
            "normalmente. Arquivos já baixados e grupos já processados são mantidos, então dá para repetir a "
            "execução depois de uma queda de conexão.</p>",
            "<p>Tick the <b>variables</b> (Tmin, Tmax, Tmean, Prec, Thornthwaite evapotranspiration), the "
            "<b>periods</b> (2021–2040 to 2081–2100), the <b>scenarios</b> (SSP1 2.6, SSP2 4.5, SSP3 7.0, SSP5 8.5) "
            "and the CMIP6 <b>models</b>. The plugin downloads from WorldClim v2.1 only the box around the area, maps "
            "the 1970–2000 historical data and each projection, and computes the derived variables. Combinations "
            "with no WorldClim data are reported at the start and in <i>disponibilidade_en.txt</i>; the others run "
            "normally. Downloaded files and processed groups are kept, so the run can be repeated after a "
            "connection drop.</p>") + AJUDA_DERIVADAS + AJUDA_ENSEMBLE + AJUDA_LOTE + AJUDA_FONTE + AJUDA_PASTAS + \
            f"<p>v{VERSAO_COMPLEMENTO}</p>"

    def initAlgorithm(self, config=None):  # noqa: N802
        P = self.addParameter
        P(QgsProcessingParameterEnum("VARIAVEIS", _tr(T("Variáveis", "Variables")), [VAR_TELA[v] for v in C.TODAS],
                                     allowMultiple=True, defaultValue=list(range(len(C.TODAS)))))
        P(QgsProcessingParameterEnum("PERIODOS", _tr(T("Períodos", "Periods")), list(C.PERIODOS), allowMultiple=True,
                                     defaultValue=[0, 1, 2, 3]))
        P(QgsProcessingParameterEnum("SSPS", _tr(T("Cenários", "Scenarios")), SSP_ROTULOS, allowMultiple=True,
                                     defaultValue=[0, 1, 2, 3]))
        P(QgsProcessingParameterEnum("MODELOS", _tr(T("Modelos (GCMs)", "Models (GCMs)")), list(C.MODELOS),
                                     allowMultiple=True, defaultValue=list(range(len(C.MODELOS)))))
        P(QgsProcessingParameterBoolean("HISTORICO", _tr(T("Incluir o histórico 1970–2000 (necessário para a correção "
                                                           "de viés e para os índices)",
                                                           "Include the 1970–2000 historical data (needed for bias "
                                                           "correction and for the indices)")), defaultValue=True))
        _param_ensemble(P, False)
        _param_area(P)
        _param_projeto(P, "PASTA")
        _params_saida(P)
        av = [QgsProcessingParameterString("ESCALAS", _tr(T("Escalas de cores fixas (ex.: tmin=10:30; tmax=20:42; "
                                                            "prec=0:400; etp=0:200). Recomendado com muitos modelos",
                                                            "Fixed color scales (e.g., tmin=10:30; tmax=20:42; "
                                                            "prec=0:400; etp=0:200). Recommended with many models")),
                                           optional=True),
              QgsProcessingParameterBoolean("SO_BAIXAR", _tr(T("Apenas baixar, sem processar",
                                                               "Download only, do not process")), defaultValue=False)]
        for par in av:
            par.setFlags(par.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
            P(par)
        self.addOutput(QgsProcessingOutputString("PASTA", _tr(T("Pasta da Fase 1", "Phase 1 folder"))))
        self.addOutput(QgsProcessingOutputNumber("N_ARQUIVOS", _tr(T("Arquivos obtidos", "Files obtained"))))
        self.addOutput(QgsProcessingOutputNumber("N_PROCESSADOS", _tr(T("Grupos de 12 rasters processados",
                                                                        "Groups of 12 rasters processed"))))
        self.addOutput(QgsProcessingOutputNumber("N_DERIVADOS", _tr(T("Grupos de Tmed/ETP calculados",
                                                                      "Tmean/PET groups computed"))))
        self.addOutput(QgsProcessingOutputNumber("N_ENSEMBLE", _tr(T("Grupos do ensemble", "Ensemble groups"))))
        self.addOutput(QgsProcessingOutputNumber("N_PNG", _tr(T("Mapas PNG", "PNG maps"))))
        self.addOutput(QgsProcessingOutputNumber("N_AUSENTES", _tr(T("Combinações sem dados no WorldClim",
                                                                     "Combinations with no WorldClim data"))))

    # ------------------------------------------------------------------ etapas
    def _baixar(self, rot: str, fontes: list[str], destino: Path, env, feedback) -> bool:
        from .cenarios import processamento as Pr
        if destino.exists():
            return True
        fonte = next((f for f in fontes if Pr.existe(f)), None)
        if fonte is None:
            feedback.reportError(T(f"Não encontrado no servidor do WorldClim (ou sem conexão): {rot}",
                                   f"Not found on the WorldClim server (or no connection): {rot}"), False)
            return False
        try:
            Pr.subconjunto(fonte, destino, env)
            return True
        except Exception as exc:  # noqa: BLE001 – rede instável: segue com os demais
            feedback.reportError(T(f"Falha em {rot}: {exc}", f"Failed: {rot}: {exc}"), False)
            return False

    def _processar(self, tipo: str, arquivos: list[Path], feedback) -> bool:
        from .cenarios.manual import executar
        from .comum.config import ErroValidacao
        if self._so_baixar:
            return False
        fb = _Feedback(feedback)
        try:
            r = executar({**self._cfg, "tipo": tipo, "arquivos": [str(a) for a in arquivos]},
                         progresso=None, cancelado=fb.cancelado)
        except ErroValidacao as exc:
            if any("já contém" in m for m in exc.mensagens):
                feedback.pushInfo(T("   já processado nesta pasta, mantido.", "   already processed, kept."))
                return False
            for m in exc.mensagens:
                feedback.reportError(m, False)
            return False
        for a in r["avisos"]:
            if not a.startswith("Escala de cores de"):
                feedback.pushWarning(a)
        self._n_png += r["mapas"].get("n_png", 0)
        feedback.pushInfo(f"   → {r['pasta_grupo']}: 12 rasters, {r['n_txt']} txt, {r['mapas'].get('n_png', 0)} PNG")
        return True

    def processAlgorithm(self, parameters, context, feedback):  # noqa: N802
        from .cenarios import processamento as Pr
        from .cenarios import worldclim as W
        from .comum import geo
        escolhidas = [C.TODAS[i] for i in self.parameterAsEnums(parameters, "VARIAVEIS", context)]
        periodos = [C.PERIODOS[i] for i in self.parameterAsEnums(parameters, "PERIODOS", context)]
        ssps = [C.SSPS[i] for i in self.parameterAsEnums(parameters, "SSPS", context)]
        modelos = [C.MODELOS[i] for i in self.parameterAsEnums(parameters, "MODELOS", context)]
        historico = self.parameterAsBool(parameters, "HISTORICO", context)
        if not escolhidas:
            raise QgsProcessingException(T("Marque ao menos uma variável.", "Tick at least one variable."))
        if not historico and not (periodos and ssps and modelos):
            raise QgsProcessingException(T("Marque o histórico ou ao menos um período, um cenário e um modelo.",
                                           "Tick the historical data or at least one period, scenario and model."))
        base = C.base_necessaria(escolhidas)
        extra = [v for v in base if v not in escolhidas]
        if extra:
            nomes = ", ".join(SIGLA[L][v] for v in extra)
            feedback.pushInfo(T(f"Incluídas por serem necessárias para as variáveis calculadas: {nomes}.",
                                f"Added because the computed variables need them: {nomes}."))
        derivadas = [v for v in escolhidas if v in C.DERIVADAS]

        pasta = PJ.saida_fase1(self.parameterAsFile(parameters, "PASTA", context))
        pasta.mkdir(parents=True, exist_ok=True)
        area_gpkg = _area(self, parameters, context, pasta)
        area, erros = geo.ler_vetor_area(area_gpkg)
        if erros:
            raise QgsProcessingException(" ".join(erros))
        for a in area.avisos:
            feedback.pushWarning(a)
        env, orig = area.limites, pasta / C.PASTAS["originais"]
        Pr.configurar_http(W.OPCOES_HTTP)
        self._cfg = {"area": str(area_gpkg), "saida": str(pasta), **_cfg_saida(self, parameters, context),
                     "simbologia": _ler_simbologia(self.parameterAsString(parameters, "ESCALAS", context))}
        self._so_baixar = self.parameterAsBool(parameters, "SO_BAIXAR", context)
        self._n_png = 0
        gerar_mapas = self._cfg["gerar_mapas"]
        self._cfg["gerar_mapas"] = False    # os mapas saem por último, com escala única (cenarios/mapas.py)

        # ---------------------------------------------------- disponibilidade
        ok, faltas = C.plano(escolhidas, modelos, ssps, periodos)
        texto = {lang: rotulo_ausencias(faltas, lang) for lang in ("pt", "en")}
        if faltas:
            feedback.pushWarning(T(f"Sem dados no WorldClim (30″) para {len(faltas)} combinação(ões) de modelo e "
                                   "cenário – serão puladas:", f"No WorldClim (30″) data for {len(faltas)} "
                                   "model × scenario combination(s) – they will be skipped:"))
            for t in texto[L]:
                feedback.pushWarning("   " + t)
        for lang in ("pt", "en"):
            cab = ("Combinações escolhidas sem dados no WorldClim v2.1 a 30″\n" if lang == "pt" else
                   "Selected combinations with no WorldClim v2.1 30″ data\n")
            (pasta / f"disponibilidade_{lang}.txt").write_text(
                cab + ("\n".join(texto[lang]) if texto[lang] else ("nenhuma" if lang == "pt" else "none")) + "\n",
                encoding="utf-8")

        # ---------------------------------------------------- tarefas
        tarefas = []
        if historico:
            for v in base:
                tarefas.append(("hist", v, None))
        for v in base:                                      # mesma ordem das pastas: var / período / modelo / SSP
            for per in periodos:
                for mod in modelos:
                    for s in ssps:
                        if C.disponivel(mod, s, v):
                            tarefas.append(("fut", v, (mod, s, per)))
        if not tarefas:
            raise QgsProcessingException(T("Nenhuma combinação com dados foi selecionada.",
                                           "No combination with data was selected."))
        if len(modelos) * len(ssps) * len(periodos) > 1 and not self._cfg["simbologia"]:
            feedback.pushInfo(T("Escala de cores automática: os mapas saem por último, com a mesma escala para cada "
                                "variável (do mínimo ao máximo de todos os cenários do projeto). IA e PCI usam as "
                                "classes publicadas (UNEP e Oliver, 1980).", "Automatic color scale: maps are made "
                                "last, with the same scale per variable (from the minimum to the maximum of all "
                                "scenarios in the project). AI and PCI use the published classes (UNEP and Oliver, "
                                "1980)."))
        mde = pasta / C.PASTAS["entradas"] / "elevacao_worldclim.tif"
        if not mde.exists() and not feedback.isCanceled():   # usada no ajuste de altitude da Fase 2
            feedback.pushInfo(T("Elevação do WorldClim (wc2.1_30s_elev), para o ajuste de altitude da Fase 2",
                                "WorldClim elevation (wc2.1_30s_elev), for the Phase 2 altitude adjustment"))
            self._baixar(T("elevação do WorldClim", "WorldClim elevation"), [W.vsi_elevacao()], mde, env, feedback)
        n = proc = 0
        total = len(tarefas) + (1 if derivadas else 0)
        for i, (tipo, v, comb) in enumerate(tarefas):
            if feedback.isCanceled():
                break
            feedback.setProgress(100.0 * i / total)
            if tipo == "hist":
                feedback.pushInfo(f"[{i + 1}/{len(tarefas)}] {v} " + T("histórico 1970–2000", "historical 1970–2000"))
                arqs = []
                for m in range(1, 13):
                    destino = orig / "historico" / v / W.nome_historico(v, m)
                    if self._baixar(f"{v} {m:02d}", [W.vsi_historico(v, m)], destino, env, feedback):
                        arqs.append(destino)
                        n += 1
                if len(arqs) == 12:
                    proc += self._processar("historico", arqs, feedback)
                else:
                    feedback.reportError(T(f"{v}: {12 - len(arqs)} mês(es) não obtido(s); histórico não processado.",
                                           f"{v}: {12 - len(arqs)} month(s) not obtained; historical not processed."),
                                         False)
            else:
                mod, s, per = comb
                rot = f"{v} {per} {mod} {C.SSP_ARTIGO[s]}"
                feedback.pushInfo(f"[{i + 1}/{len(tarefas)}] {rot}")
                destino = orig / "cmip6" / mod / W.nome_futuro(v, mod, s, per)
                if self._baixar(rot, W.fontes_futuro(v, mod, s, per), destino, env, feedback):
                    n += 1
                    proc += self._processar("futuro", [destino], feedback)
        r_der = {"grupos": 0, "png": 0}
        if derivadas and not self._so_baixar and not feedback.isCanceled():
            feedback.pushInfo(T(f"Calculando {', '.join(derivadas)}…", f"Computing {', '.join(derivadas)}…"))
            r_der = _derivadas(pasta, self._cfg, derivadas, feedback, mapas=False)
            feedback.pushInfo(T(f"   {r_der['grupos']} grupo(s) calculado(s), {r_der['png']} PNG.",
                                f"   {r_der['grupos']} group(s) computed, {r_der['png']} PNG."))
        r_ens = {"grupos": 0, "png": 0}
        if self.parameterAsBool(parameters, "ENSEMBLE", context) and not self._so_baixar and not feedback.isCanceled():
            idx = parameters.get("MODELOS_ENSEMBLE") and self.parameterAsEnums(parameters, "MODELOS_ENSEMBLE", context)
            mods_ens = [C.MODELOS[i] for i in idx] if idx else list(modelos)
            feedback.pushInfo(T(f"Ensemble de {len(mods_ens)} modelo(s): {', '.join(mods_ens)}",
                                f"Ensemble of {len(mods_ens)} model(s): {', '.join(mods_ens)}"))
            r_ens = _ensemble(pasta, self._cfg, mods_ens, feedback, escolhidas, ssps, periodos,
                              self.parameterAsInt(parameters, "MIN_ENSEMBLE", context), mapas=False)
            feedback.pushInfo(T(f"   {r_ens['grupos']} grupo(s) do ensemble, {r_ens['png']} PNG.",
                                f"   {r_ens['grupos']} ensemble group(s), {r_ens['png']} PNG."))
        r_map = {"png": 0}
        if gerar_mapas and not self._so_baixar and not feedback.isCanceled():
            self._cfg["gerar_mapas"] = True
            try:
                r_map = _mapas(pasta, self._cfg, feedback)
            except Exception as exc:  # noqa: BLE001
                raise _erro_processamento(exc, feedback)
        if not PJ.eh_legado(pasta):
            PJ.registrar(pasta, regiao=self._cfg["regiao"])
        feedback.pushInfo(T(f"Concluído: resultados em {pasta}", f"Done: results in {pasta}"))
        return {"PASTA": str(pasta), "N_ARQUIVOS": n, "N_PROCESSADOS": proc, "N_DERIVADOS": r_der["grupos"],
                "N_ENSEMBLE": r_ens["grupos"], "N_PNG": r_map["png"],
                "N_AUSENTES": len(faltas)}


# ============================================================================= 1.2 / 1.3 arquivo já baixado
class _AlgImagem(_Base):
    TIPO = "futuro"

    def group(self):
        return _tr(GRUPO)

    def groupId(self):  # noqa: N802
        return "mcgbrasil_fase1"

    def flags(self):
        return super().flags() | self.FlagNoThreading

    def _params_comuns(self):
        P = self.addParameter
        P(QgsProcessingParameterEnum("VARIAVEL", _tr(T("Variável", "Variable")), [AUTO] + VAR_ROTULOS_BASE,
                                     defaultValue=0))
        if self.TIPO == "futuro":
            P(QgsProcessingParameterString("MODELO", _tr(T("Modelo CMIP6 (vazio = pelo nome do arquivo)",
                                                           "CMIP6 model (empty = from the file name)")),
                                           optional=True))
            P(QgsProcessingParameterEnum("SSP", _tr(T("Cenário", "Scenario")), [AUTO] + SSP_ROTULOS, defaultValue=0))
            P(QgsProcessingParameterEnum("PERIODO", _tr(T("Período", "Period")), [AUTO] + list(C.PERIODOS),
                                         defaultValue=0))
        _param_area(P)
        _param_projeto(P, "SAIDA")
        _params_saida(P)
        P(QgsProcessingParameterBoolean("SUBSTITUIR", _tr(T("Substituir se este cenário já existir na pasta",
                                                            "Replace if this scenario already exists")),
                                        defaultValue=False))
        av = [QgsProcessingParameterString("ESCALA", _tr(T("Escala de cores fixa desta variável (mín:máx, ex.: 0:300)",
                                                           "Fixed color scale of this variable (min:max, e.g., "
                                                           "0:300)")), optional=True),
              QgsProcessingParameterString("CLASSES", _tr(T("Limites das classes para área por classe (ex.: 10,30,60,"
                                                            "100)", "Class limits for area by class (e.g., "
                                                            "10,30,60,100)")), optional=True),
              QgsProcessingParameterFile("QML", _tr(T("Estilo .qml próprio (opcional)", "Own .qml style (optional)")),
                                         extension="qml", optional=True)]
        for par in av:
            par.setFlags(par.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
            P(par)
        self.addOutput(QgsProcessingOutputString("SITUACAO", _tr(T("Situação", "Status"))))
        self.addOutput(QgsProcessingOutputString("CENARIO", _tr(T("Cenário processado", "Scenario processed"))))
        self.addOutput(QgsProcessingOutputFile("MANIFESTO", _tr(T("Manifesto da pasta", "Folder manifest"))))
        self.addOutput(QgsProcessingOutputNumber("N_PNG", _tr(T("Mapas PNG", "PNG maps"))))
        self.addOutput(QgsProcessingOutputNumber("N_TXT", _tr(T("Relatórios de estatísticas (.txt)",
                                                                "Statistics reports (.txt)"))))

    def _arquivos(self, parameters, context) -> list[str]:
        raise NotImplementedError

    def processAlgorithm(self, parameters, context, feedback):  # noqa: N802
        from .cenarios.manual import executar
        saida = PJ.saida_fase1(self.parameterAsFile(parameters, "SAIDA", context))
        area = _area(self, parameters, context, saida)
        var = self.parameterAsEnum(parameters, "VARIAVEL", context)
        escala = self.parameterAsString(parameters, "ESCALA", context).strip()
        classes = self.parameterAsString(parameters, "CLASSES", context).strip()
        cfg = {"tipo": self.TIPO, "arquivos": self._arquivos(parameters, context), "area": str(area),
               "saida": str(saida), "variavel": C.VARIAVEIS[var - 1] if var else None,
               **_cfg_saida(self, parameters, context),
               "substituir": self.parameterAsBool(parameters, "SUBSTITUIR", context),
               "qml": self.parameterAsFile(parameters, "QML", context) or None}
        if self.TIPO == "futuro":
            ssp = self.parameterAsEnum(parameters, "SSP", context)
            per = self.parameterAsEnum(parameters, "PERIODO", context)
            cfg.update(modelo=self.parameterAsString(parameters, "MODELO", context).strip() or None,
                       ssp=C.SSPS[ssp - 1] if ssp else None, periodo=C.PERIODOS[per - 1] if per else None)
        try:
            if escala:
                a, b = (float(x.replace(",", ".")) for x in escala.split(":"))
                if b <= a:
                    raise ValueError
                cfg["_escala"] = {"min": a, "max": b}
            if classes:
                lim = [float(x) for x in classes.replace(";", ",").split(",") if x.strip()]
                if not lim or lim != sorted(lim):
                    raise ValueError
                cfg["_classes"] = lim
        except ValueError:
            raise QgsProcessingException(T("Escala: use mín:máx (ex.: 0:300). Classes: limites crescentes separados "
                                           "por vírgula, com ponto decimal (ex.: 10,30,60,100).",
                                           "Scale: use min:max (e.g., 0:300). Classes: increasing limits separated "
                                           "by commas, with decimal point (e.g., 10,30,60,100)."))
        fb = _Feedback(feedback)
        try:
            r = executar(cfg, progresso=fb.progresso, cancelado=fb.cancelado)
        except Exception as exc:  # noqa: BLE001
            raise _erro_processamento(exc, feedback)
        for etapa in r["etapas"]:
            feedback.pushInfo(etapa)
        for a in r["avisos"]:
            feedback.pushWarning(a)
        m = r["mapas"]
        feedback.pushInfo(f"{r['cenario']}: 12 rasters, {r['n_txt']} txt, {m.get('n_png', 0)} PNG – {saida}")
        return {"SITUACAO": r["situacao"], "CENARIO": r["cenario"], "MANIFESTO": str(saida / "manifesto_cenarios.json"),
                "N_PNG": m.get("n_png", 0), "N_TXT": r["n_txt"]}


class AlgCenarioHistorico(_AlgImagem):
    TIPO = "historico"

    def name(self):
        return "cenario_historico"

    def displayName(self):  # noqa: N802
        return _tr(T("1.2 Histórico 1970–2000 com arquivo já baixado (uma variável)",
                     "1.2 Historical 1970–2000 from a downloaded file (one variable)"))

    def shortHelpString(self):  # noqa: N802
        return T("<p>Mapeia o histórico WorldClim v2.1 (1970–2000) de <b>uma variável</b> a partir do <b>.zip</b> "
                 "baixado do WorldClim (ex.: wc2.1_30s_tmin.zip) <b>ou</b> dos <b>12 GeoTIFFs mensais</b>. A primeira "
                 "etapa é o recorte pela máscara de cada arquivo mensal, um a um.</p>",
                 "<p>Maps the WorldClim v2.1 historical data (1970–2000) of <b>one variable</b> from the <b>.zip</b> "
                 "downloaded from WorldClim (e.g., wc2.1_30s_tmin.zip) <b>or</b> the <b>12 monthly GeoTIFFs</b>. The "
                 "first step is clipping each monthly file by the mask, one by one.</p>") \
            + AJUDA_LOTE + AJUDA_FONTE + AJUDA_PASTAS + f"<p>v{VERSAO_COMPLEMENTO}</p>"

    def initAlgorithm(self, config=None):  # noqa: N802
        self.addParameter(QgsProcessingParameterFile("ZIP", _tr(T("Arquivo .zip do WorldClim (uma variável)",
                                                                  "WorldClim .zip file (one variable)")),
                                                     extension="zip", optional=True))
        self.addParameter(QgsProcessingParameterMultipleLayers(
            "MENSAIS", _tr(T("… ou os 12 GeoTIFFs mensais (uma variável)", "… or the 12 monthly GeoTIFFs (one "
                             "variable)")), QgsProcessing.TypeRaster, optional=True))
        self._params_comuns()

    def _arquivos(self, parameters, context) -> list[str]:
        z = self.parameterAsFile(parameters, "ZIP", context)
        camadas = self.parameterAsLayerList(parameters, "MENSAIS", context) or []
        if z and camadas:
            raise QgsProcessingException(T("Informe o .zip ou os 12 GeoTIFFs, não os dois.",
                                           "Give the .zip or the 12 GeoTIFFs, not both."))
        if z:
            return [str(Path(z).resolve())]
        if not camadas:
            raise QgsProcessingException(T("Informe o .zip do WorldClim ou os 12 GeoTIFFs mensais da variável.",
                                           "Give the WorldClim .zip or the variable's 12 monthly GeoTIFFs."))
        return [l.source().split("|")[0] for l in camadas]


class AlgCenarioFuturo(_AlgImagem):
    TIPO = "futuro"

    def name(self):
        return "cenario_futuro"

    def displayName(self):  # noqa: N802
        return _tr(T("1.3 Projeção CMIP6 com imagem já baixada (12 bandas)",
                     "1.3 CMIP6 projection from a downloaded image (12 bands)"))

    def shortHelpString(self):  # noqa: N802
        return T("<p>Mapeia <b>uma imagem CMIP6 do WorldClim</b> (uma variável × modelo × SSP × período, GeoTIFF de "
                 "12 bandas, ex.: wc2.1_30s_tmin_ACCESS-CM2_ssp585_2081-2100.tif): importar, recortar pela máscara "
                 "preservando as 12 bandas, separar as bandas e renomear. Variável, modelo, SSP e período saem do nome "
                 "do arquivo; se ele foi renomeado, preencha os campos.</p>",
                 "<p>Maps <b>one WorldClim CMIP6 image</b> (one variable × model × SSP × period, 12-band GeoTIFF, "
                 "e.g., wc2.1_30s_tmin_ACCESS-CM2_ssp585_2081-2100.tif): import, clip by the mask keeping the 12 "
                 "bands, split the bands and rename. Variable, model, SSP and period come from the file name; if it "
                 "was renamed, fill in the fields.</p>") \
            + AJUDA_LOTE + AJUDA_FONTE + AJUDA_PASTAS + f"<p>v{VERSAO_COMPLEMENTO}</p>"

    def initAlgorithm(self, config=None):  # noqa: N802
        self.addParameter(QgsProcessingParameterRasterLayer(
            "IMAGEM", _tr(T("Imagem WorldClim CMIP6 (GeoTIFF de 12 bandas)", "WorldClim CMIP6 image (12-band "
                            "GeoTIFF)"))))
        self._params_comuns()

    def _arquivos(self, parameters, context) -> list[str]:
        lyr = self.parameterAsRasterLayer(parameters, "IMAGEM", context)
        if lyr is None:
            raise QgsProcessingException(T("Informe a imagem CMIP6.", "Choose the CMIP6 image."))
        return [lyr.source().split("|")[0]]


# ============================================================================= 1.4 derivadas
class AlgDerivadas(_Base):
    def name(self):
        return "calcular_derivadas"

    def displayName(self):  # noqa: N802
        return _tr(T("1.4 Calcular Tmed, ETP e índices (aridez, PCI, ISC)",
                     "1.4 Compute Tmean, PET and indices (aridity, PCI, ISC)"))

    def group(self):
        return _tr(GRUPO)

    def groupId(self):  # noqa: N802
        return "mcgbrasil_fase1"

    def flags(self):
        return super().flags() | self.FlagNoThreading

    def shortHelpString(self):  # noqa: N802
        return T("<p>Calcula Tmed, ETP e os índices para todos os cenários do projeto que já têm as variáveis de "
                 "origem (Tmin e Tmax para Tmed e ETP; Tmin, Tmax e Prec para o IA; Prec para PCI e ISC), no "
                 "histórico e nas projeções. Grupos já calculados são mantidos.</p>",
                 "<p>Computes Tmean, PET and the indices for every scenario in the project that already has the "
                 "source variables (Tmin and Tmax for Tmean and PET; Tmin, Tmax and Prec for AI; Prec for PCI and "
                 "ISC), historical and projections. Groups already computed are kept.</p>") + AJUDA_DERIVADAS + f"<p>v{VERSAO_COMPLEMENTO}</p>"

    def initAlgorithm(self, config=None):  # noqa: N802
        P = self.addParameter
        _param_projeto(P, "PASTA")
        P(QgsProcessingParameterEnum("VARIAVEIS", _tr(T("Variáveis", "Variables")), [VAR_TELA[v] for v in DERIV],
                                     allowMultiple=True, defaultValue=list(range(len(DERIV)))))
        _params_saida(P)
        self.addOutput(QgsProcessingOutputNumber("N_DERIVADOS", _tr(T("Grupos calculados", "Groups computed"))))
        self.addOutput(QgsProcessingOutputNumber("N_PNG", _tr(T("Mapas PNG", "PNG maps"))))

    def processAlgorithm(self, parameters, context, feedback):  # noqa: N802
        pasta = PJ.pasta_fase(self.parameterAsFile(parameters, "PASTA", context), 1)
        if not _ler_manifesto(pasta):
            raise QgsProcessingException(T("O projeto ainda não tem cenários (Fase 1).",
                                           "The project has no scenarios yet (Phase 1)."))
        variaveis = [DERIV[i] for i in self.parameterAsEnums(parameters, "VARIAVEIS", context)]
        cfg = {**_cfg_saida(self, parameters, context), "simbologia": {}}
        try:
            r = _derivadas(pasta, cfg, variaveis, feedback)
        except Exception as exc:  # noqa: BLE001
            raise _erro_processamento(exc, feedback)
        if r["grupos"] == 0 and r["ja_existiam"] == 0:
            feedback.pushWarning(T("Nenhum cenário com Tmin e Tmax completos (12 meses) na pasta.",
                                   "No scenario with complete Tmin and Tmax (12 months) in the folder."))
        feedback.pushInfo(T(f"{r['grupos']} grupo(s) calculado(s); {r['ja_existiam']} já existiam.",
                            f"{r['grupos']} group(s) computed; {r['ja_existiam']} already existed."))
        return {"N_DERIVADOS": r["grupos"], "N_PNG": r["png"]}


# ============================================================================= 1.5 ensemble
class AlgEnsemble(_Base):
    def name(self):
        return "ensemble_modelos"

    def displayName(self):  # noqa: N802
        return _tr(T("1.5 Ensemble de modelos (média dos modelos marcados)",
                     "1.5 Model ensemble (mean of the selected models)"))

    def group(self):
        return _tr(GRUPO)

    def groupId(self):  # noqa: N802
        return "mcgbrasil_fase1"

    def flags(self):
        return super().flags() | self.FlagNoThreading

    def shortHelpString(self):  # noqa: N802
        return T("<p>Monta o ensemble com os cenários já existentes no projeto. Marque os modelos que entram na média. "
                 "Escolha a Fase 1 (sem correção) ou a Fase 2 (corrigida pelo método Delta). O ensemble feito na Fase 1 é "
                 "refeito automaticamente pela Fase 2, com os mesmos modelos, a partir dos modelos corrigidos. Grupos já calculados com os mesmos modelos são "
                 "mantidos; com outros modelos, são refeitos.</p>",
                 "<p>Builds the ensemble from the scenarios already in the project. Tick the models that enter the "
                 "mean. Choose Phase 1 (uncorrected) or Phase 2 (Delta bias-corrected). A Phase 1 ensemble is rebuilt "
                 "automatically by Phase 2, with the same models, from the corrected models. Groups already computed with the same models "
                 "are kept; with other models, they are rebuilt.</p>") + AJUDA_ENSEMBLE + f"<p>v{VERSAO_COMPLEMENTO}</p>"

    def initAlgorithm(self, config=None):  # noqa: N802
        P = self.addParameter
        _param_projeto(P, "PASTA")
        P(QgsProcessingParameterEnum("ORIGEM", _tr(T("Cenários de origem", "Source scenarios")),
                                     [T("Fase 1 – sem correção", "Phase 1 – uncorrected"),
                                      T("Fase 2 – corrigidos pelo método Delta", "Phase 2 – Delta bias-corrected")],
                                     defaultValue=0))
        P(QgsProcessingParameterEnum("MODELOS_ENSEMBLE", _tr(T("Modelos do ensemble", "Ensemble models")),
                                     list(C.MODELOS), allowMultiple=True, defaultValue=list(range(len(C.MODELOS)))))
        P(QgsProcessingParameterEnum("VARIAVEIS", _tr(T("Variáveis", "Variables")), [VAR_TELA[v] for v in C.TODAS],
                                     allowMultiple=True, defaultValue=list(range(len(C.TODAS)))))
        P(QgsProcessingParameterEnum("SSPS", _tr(T("Cenários", "Scenarios")), SSP_ROTULOS, allowMultiple=True,
                                     defaultValue=[0, 1, 2, 3]))
        P(QgsProcessingParameterEnum("PERIODOS", _tr(T("Períodos", "Periods")), list(C.PERIODOS), allowMultiple=True,
                                     defaultValue=[0, 1, 2, 3]))
        P(QgsProcessingParameterNumber("MIN_ENSEMBLE", _tr(T("Mínimo de modelos com dados para formar o ensemble",
                                                             "Minimum number of models with data to form the "
                                                             "ensemble")), defaultValue=2, minValue=2, maxValue=14))
        _params_saida(P)
        self.addOutput(QgsProcessingOutputNumber("N_ENSEMBLE", _tr(T("Grupos do ensemble", "Ensemble groups"))))
        self.addOutput(QgsProcessingOutputNumber("N_PNG", _tr(T("Mapas PNG", "PNG maps"))))

    def processAlgorithm(self, parameters, context, feedback):  # noqa: N802
        origem = self.parameterAsEnum(parameters, "ORIGEM", context)
        pasta = PJ.pasta_fase(self.parameterAsFile(parameters, "PASTA", context), 1 + origem)
        if origem == 1 and not (pasta / "manifesto_cenarios.json").exists():
            raise QgsProcessingException(T("O projeto ainda não tem cenários corrigidos (Fase 2).",
                                           "The project has no bias-corrected scenarios yet (Phase 2)."))
        if not _ler_manifesto(pasta):
            raise QgsProcessingException(T("O projeto ainda não tem cenários (Fase 1).",
                                           "The project has no scenarios yet (Phase 1)."))
        modelos = [C.MODELOS[i] for i in self.parameterAsEnums(parameters, "MODELOS_ENSEMBLE", context)]
        if len(modelos) < 2:
            raise QgsProcessingException(T("Marque ao menos dois modelos.", "Tick at least two models."))
        cfg = {**_cfg_saida(self, parameters, context), "simbologia": {}}
        variaveis = [C.TODAS[i] for i in self.parameterAsEnums(parameters, "VARIAVEIS", context)]
        ssps = [C.SSPS[i] for i in self.parameterAsEnums(parameters, "SSPS", context)]
        periodos = [C.PERIODOS[i] for i in self.parameterAsEnums(parameters, "PERIODOS", context)]
        try:
            r = _ensemble(pasta, cfg, modelos, feedback, variaveis, ssps, periodos,
                          self.parameterAsInt(parameters, "MIN_ENSEMBLE", context))
        except Exception as exc:  # noqa: BLE001
            raise _erro_processamento(exc, feedback)
        feedback.pushInfo(T(f"{r['grupos']} grupo(s) do ensemble calculado(s); {r['mantidos']} mantido(s); "
                            f"{r['pulados']} sem modelos suficientes.",
                            f"{r['grupos']} ensemble group(s) computed; {r['mantidos']} kept; {r['pulados']} without "
                            "enough models."))
        return {"N_ENSEMBLE": r["grupos"], "N_PNG": r["png"]}


# ============================================================================= 1.6 mapas com escala única
class AlgMapas(_Base):
    def name(self):
        return "refazer_mapas"

    def displayName(self):  # noqa: N802
        return _tr(T("1.6 Refazer os mapas com escala única", "1.6 Redo the maps with a single scale"))

    def group(self):
        return _tr(GRUPO)

    def groupId(self):  # noqa: N802
        return "mcgbrasil_fase1"

    def flags(self):
        return super().flags() | self.FlagNoThreading

    def shortHelpString(self):  # noqa: N802
        return T("<p>Refaz os layouts, projetos .qgz e PNG de todos os grupos da pasta, com a <b>escala de cores única "
                 "por variável</b>: do mínimo ao máximo, arredondados, de todos os cenários da pasta (histórico, "
                 "projeções, Tmed, ETP e ensemble). Assim nenhum cenário futuro satura a paleta, e todos os mapas de "
                 "uma variável são comparáveis. Use em projetos feitos com versões anteriores, ou para mudar idioma, "
                 "dpi ou escala fixa. Rasters e estatísticas não mudam.</p>",
                 "<p>Redoes the layouts, .qgz projects and PNG of every group in the folder, with a <b>single color "
                 "scale per variable</b>: from the rounded minimum to maximum of all scenarios in the folder "
                 "(historical, projections, Tmean, PET and ensemble). No future scenario saturates the palette, and "
                 "all maps of a variable are comparable. Use it on projects made with earlier versions, or to change "
                 "language, dpi or fixed scale. Rasters and statistics do not change.</p>") + f"<p>v{VERSAO_COMPLEMENTO}</p>"

    def initAlgorithm(self, config=None):  # noqa: N802
        P = self.addParameter
        _param_projeto(P, "PASTA")
        P(QgsProcessingParameterEnum("ORIGEM", _tr(T("Cenários", "Scenarios")),
                                     [T("Fase 1 – sem correção", "Phase 1 – uncorrected"),
                                      T("Fase 2 – corrigidos pelo método Delta", "Phase 2 – Delta bias-corrected")],
                                     defaultValue=0))
        P(QgsProcessingParameterString("ESCALAS", _tr(T("Escalas de cores fixas (opcional; ex.: tmin=10:30; tmax=20:42)",
                                                        "Fixed color scales (optional; e.g., tmin=10:30; tmax=20:42)")),
                                       optional=True, defaultValue=""))
        _params_saida(P)
        self.addOutput(QgsProcessingOutputNumber("N_PNG", _tr(T("Mapas PNG", "PNG maps"))))

    def processAlgorithm(self, parameters, context, feedback):  # noqa: N802
        origem = self.parameterAsEnum(parameters, "ORIGEM", context)
        entrada = Path(self.parameterAsFile(parameters, "PASTA", context))
        pasta = entrada if (entrada / "manifesto_cenarios.json").exists() else PJ.pasta_fase(entrada, 1 + origem)
        if not _ler_manifesto(pasta):
            raise QgsProcessingException(T(f"Não há cenários em {pasta}.", f"No scenarios in {pasta}."))
        cfg = {**_cfg_saida(self, parameters, context), "gerar_mapas": True,
               "simbologia": _ler_simbologia(self.parameterAsString(parameters, "ESCALAS", context))}
        if not cfg["regiao"]:   # região do projeto, para os títulos
            for d in (entrada, entrada.parent, pasta.parent):
                reg = (PJ.ler_marcador(d) or {}).get("regiao")
                if reg:
                    cfg["regiao"] = reg
                    break
        try:
            r = _mapas(pasta, cfg, feedback, forcar=True)
        except Exception as exc:  # noqa: BLE001
            raise _erro_processamento(exc, feedback)
        return {"N_PNG": r["png"]}
