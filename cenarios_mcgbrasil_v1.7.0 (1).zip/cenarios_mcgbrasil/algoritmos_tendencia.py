"""Fase 3 – Avaliação de tendência do cenário com as normais climatológicas do INMET (Lima et al., 2026, seção 2.7)."""

from __future__ import annotations

import shutil
from pathlib import Path

from qgis.core import (QgsProcessingException, QgsProcessingOutputFile, QgsProcessingOutputFolder,
                       QgsProcessingOutputNumber, QgsProcessingOutputString, QgsProcessingParameterBoolean,
                       QgsProcessingParameterEnum, QgsProcessingParameterFile, QgsProcessingParameterNumber,
                       QgsProcessingParameterString)

from . import projeto as PJ
from .algoritmos_vies import CRITERIOS_ID, CRITERIOS_ROT, LOCAIS, LOCAIS_ID
from .base import VERSAO_COMPLEMENTO, _Base, _erro_processamento, _Feedback, _tr
from .cenarios import catalogo as C
from .idioma import IDIOMA, T

L = "en" if IDIOMA == "en" else "pt"
VARS = ("tmax", "tmin", "tmed", "prec", "etp")
VARS_ROT = [T("Tmax – temperatura máxima", "Tmax – maximum temperature"),
            T("Tmin – temperatura mínima", "Tmin – minimum temperature"),
            T("Tmed – temperatura média compensada", "Tmean – compensated mean temperature"),
            T("Prec – precipitação acumulada", "Prec – accumulated precipitation"),
            T("ETP – evapotranspiração potencial", "PET – potential evapotranspiration")]


class AlgTendencia(_Base):
    def name(self):
        return "tendencia_normais"

    def displayName(self):  # noqa: N802
        return _tr(T("3.1 Taxas das normais do INMET × taxas projetadas", "3.1 INMET normals rates × projected rates"))

    def group(self):
        return _tr(T("Fase 3 – Avaliação de tendência do cenário", "Phase 3 – Scenario trend assessment"))

    def groupId(self):  # noqa: N802
        return "mcgbrasil_fase3"

    def shortHelpString(self):  # noqa: N802
        return T(
            "<p>Calcula as <b>taxas de aumento ou diminuição</b> de Tmax, Tmin, Tmed, Prec e ETP nas <b>normais "
            "climatológicas oficiais do INMET</b> (1961–1990, 1981–2010 e 1991–2020, já incluídas no complemento) e "
            "as compara com as taxas projetadas pelos modelos CMIP6 da Fase 1 (ou da Fase 2, se corrigida), como na "
            "seção 2.7 de Lima et al. (2026), <i>Land Degradation &amp; Development</i>, doi:10.1002/ldr.70808.</p>"
            "<p><b>Taxa</b> (unidade da variável por ano) = (valor do último período − valor do primeiro) ÷ (último ano "
            "do último período − primeiro ano do primeiro período). Normais: 1961–1990 → 1991–2020 = 59 anos; a ETP só "
            "tem normal a partir de 1981–2010 (39 anos). Projeções: do primeiro ao último período futuro do projeto "
            "(2021–2040 → 2081–2100 = 79 anos). Calculada mês a mês e para o ano.</p>"
            "<p><b>Comparação:</b> sempre a <b>média do raster</b> (pixels da área de estudo) com a <b>média das normais</b> "
            "das estações selecionadas, mês a mês e no ano; a Tmed das normais é, por padrão, (Tmax + Tmin)/2, como nos "
            "rasters.</p><p>As estações ficam, por padrão, a até 200 km do local (critério só raio, testado em 1.100 "
            "pontos do país). Por padrão, em cada mês só entram as "
            "estações com normal no primeiro e no último período (pareadas); se uma variável ficar com menos de 3 "
            "estações pareadas em algum mês, ou sem o par de períodos completo, o raio é ampliado em passos de 100 km "
            "até 500 km, e isso fica registrado. Saídas em <i>3_tendencia_normais</i>: "
            "estações, normais regionais, taxas observadas e projetadas (com a média do conjunto de modelos por SSP, a "
            "razão projetada/observada e o r de Pearson entre as 12 taxas mensais), taxas por estação, diferença "
            "WorldClim − normais e relatório em português e inglês.</p>",
            "<p>Computes the <b>rates of increase or decrease</b> of Tmax, Tmin, Tmean, Prec and PET in the <b>official "
            "INMET climatological normals</b> (1961–1990, 1981–2010 and 1991–2020, bundled with the plugin) and "
            "compares them with the rates projected by the Phase 1 CMIP6 models (or Phase 2, if corrected), as in "
            "section 2.7 of Lima et al. (2026), <i>Land Degradation &amp; Development</i>, doi:10.1002/ldr.70808.</p>"
            "<p><b>Rate</b> (variable unit per year) = (last-period value − first-period value) ÷ (last year of the "
            "last period − first year of the first period). Normals: 1961–1990 → 1991–2020 = 59 years; PET only has "
            "normals from 1981–2010 (39 years). Projections: from the project's first to last future period "
            "(2021–2040 → 2081–2100 = 79 years). Computed per month and for the year.</p>"
            "<p><b>Comparison:</b> always the <b>raster mean</b> (study-area pixels) against the <b>mean of the normals</b> "
            "of the selected stations, per month and for the year; the normals Tmean is, by default, (Tmax + Tmin)/2, as "
            "in the rasters.</p><p>By default, stations are within 200 km of the location (radius-only criterion, "
            "tested on 1,100 points across Brazil). By default, for each month only "
            "stations with normals in both the first and last period are used (paired); if a variable has fewer than 3 "
            "paired stations in any month, or no complete pair of periods, the radius is widened in 100 km steps up "
            "to 500 km, and this is recorded. Outputs in "
            "<i>3_tendencia_normais</i>: stations, regional normals, observed and projected rates (with the model "
            "ensemble mean per SSP, the projected/observed ratio and Pearson's r between the 12 monthly rates), "
            "rates per station, WorldClim − normals difference and report in Portuguese and English.</p>") \
            + f"<p>v{VERSAO_COMPLEMENTO}</p>"

    def initAlgorithm(self, config=None):  # noqa: N802
        P = self.addParameter
        P(QgsProcessingParameterFile("PROJETO", _tr(T("Pasta do projeto (lê a Fase 1 ou 2 e grava em "
                                                      "3_tendencia_normais)", "Project folder (reads Phase 1 or 2 and "
                                                      "writes to 3_tendencia_normais)")),
                                     behavior=QgsProcessingParameterFile.Folder))
        P(QgsProcessingParameterEnum("VARIAVEIS", _tr(T("Variáveis", "Variables")), VARS_ROT, allowMultiple=True,
                                     defaultValue=[0, 1, 2, 3, 4]))
        P(QgsProcessingParameterEnum("LOCAL", _tr(T("Local de mapeamento", "Mapping location")), LOCAIS, defaultValue=0))
        P(QgsProcessingParameterString("NOME", _tr(T("Nome do município ou estação (ex.: Propriá - SE)",
                                                     "Municipality or station name (e.g., Propriá - SE)")), optional=True))
        P(QgsProcessingParameterNumber("LATITUDE", _tr(T("Latitude (graus decimais)", "Latitude (decimal degrees)")),
                                       QgsProcessingParameterNumber.Double, optional=True, minValue=-35, maxValue=6))
        P(QgsProcessingParameterNumber("LONGITUDE", _tr(T("Longitude (graus decimais)", "Longitude (decimal degrees)")),
                                       QgsProcessingParameterNumber.Double, optional=True, minValue=-75, maxValue=-28))
        P(QgsProcessingParameterEnum("CRITERIO", _tr(T("Critério de seleção das estações", "Station selection criterion")),
                                     CRITERIOS_ROT, defaultValue=3))
        P(QgsProcessingParameterNumber("RAIO", _tr(T("Raio (km)", "Radius (km)")), QgsProcessingParameterNumber.Double,
                                       defaultValue=200, minValue=1, maxValue=1000))
        P(QgsProcessingParameterEnum("TMED_NORMAL", _tr(T("Tmed das normais", "Normals Tmean")),
                                     [T("(Tmax + Tmin)/2 das normais – igual à Tmed dos rasters (recomendado)",
                                        "(Tmax + Tmin)/2 from the normals – same as the raster Tmean (recommended)"),
                                      T("Média compensada do INMET", "INMET compensated mean")], defaultValue=0))
        P(QgsProcessingParameterBoolean("AMPLIAR", _tr(T("Ampliar o raio em passos de 100 km quando faltar estação "
                                                         "pareada", "Widen the radius in 100 km steps when paired "
                                                         "stations are lacking")), defaultValue=True))
        P(QgsProcessingParameterNumber("MIN_PAREADAS", _tr(T("Mínimo de estações pareadas por mês (ampliação)",
                                                             "Minimum paired stations per month (widening)")),
                                       defaultValue=3, minValue=1, maxValue=20))
        P(QgsProcessingParameterNumber("RAIO_MAX", _tr(T("Raio máximo da ampliação (km)", "Maximum widened radius (km)")),
                                       QgsProcessingParameterNumber.Double, defaultValue=500, minValue=1, maxValue=2000))
        P(QgsProcessingParameterBoolean("PAREADAS", _tr(T("Só estações com normal no primeiro e no último período "
                                                          "(pareadas)", "Only stations with normals in the first and "
                                                          "last period (paired)")), defaultValue=True))
        P(QgsProcessingParameterEnum("PERIODOS", _tr(T("Períodos futuros para a taxa projetada (vazio = primeiro e "
                                                       "último do projeto)", "Future periods for the projected rate "
                                                       "(empty = project's first and last)")), list(C.PERIODOS),
                                     allowMultiple=True, optional=True))
        P(QgsProcessingParameterEnum("IDIOMAS", _tr(T("Idiomas do relatório", "Report languages")),
                                     ["Português", "English"], allowMultiple=True, defaultValue=[0, 1]))
        P(QgsProcessingParameterBoolean("SUBSTITUIR", _tr(T("Refazer: apagar a Fase 3 já existente neste projeto",
                                                            "Redo: delete the existing Phase 3 of this project")),
                                        defaultValue=False))
        self.addOutput(QgsProcessingOutputString("SITUACAO", _tr(T("Situação", "Status"))))
        self.addOutput(QgsProcessingOutputNumber("N_ESTACOES", _tr(T("Estações usadas", "Stations used"))))
        self.addOutput(QgsProcessingOutputString("TAXAS", _tr(T("Taxas anuais observadas", "Observed annual rates"))))
        self.addOutput(QgsProcessingOutputFolder("PASTA", _tr(T("Pasta da Fase 3", "Phase 3 folder"))))
        self.addOutput(QgsProcessingOutputFile("RELATORIO", _tr(T("Relatório", "Report"))))

    def processAlgorithm(self, parameters, context, feedback):  # noqa: N802
        from .tendencia.normais import NOME, UNID, executar
        projeto = Path(self.parameterAsFile(parameters, "PROJETO", context)).resolve()
        cen, origem = PJ.cenarios_do_projeto(projeto)
        tem_cen = (cen / PJ.MANIFESTO_CENARIOS).exists()
        saida = PJ.raiz(projeto) / PJ.fase(3)["pasta"] if not PJ.eh_legado(projeto) else \
            projeto.parent / f"{projeto.name}_{PJ.fase(3)['pasta']}"
        if saida.exists() and any(saida.iterdir()):
            if not self.parameterAsBool(parameters, "SUBSTITUIR", context):
                raise QgsProcessingException(T(f"A Fase 3 já existe neste projeto ({saida}). Marque 'Refazer' para "
                                               "calcular de novo.", f"Phase 3 already exists in this project ({saida}). "
                                               "Tick 'Redo' to compute again."))
            shutil.rmtree(saida)
        tipo = LOCAIS_ID[self.parameterAsEnum(parameters, "LOCAL", context)]
        local = {"tipo": tipo}
        if tipo == "nome":
            local["nome"] = self.parameterAsString(parameters, "NOME", context).strip()
            if not local["nome"]:
                raise QgsProcessingException(T("Informe o nome do município ou da estação.",
                                               "Give the municipality or station name."))
        elif tipo == "coordenadas":
            if parameters.get("LATITUDE") in (None, "") or parameters.get("LONGITUDE") in (None, ""):
                raise QgsProcessingException(T("Informe a latitude e a longitude.", "Give the latitude and longitude."))
            local["lat"] = self.parameterAsDouble(parameters, "LATITUDE", context)
            local["lon"] = self.parameterAsDouble(parameters, "LONGITUDE", context)
        periodos = None
        if parameters.get("PERIODOS") not in (None, "", []):
            periodos = [C.PERIODOS[i] for i in self.parameterAsEnums(parameters, "PERIODOS", context)] or None
        if periodos is not None and len(periodos) < 2:
            raise QgsProcessingException(T("Escolha ao menos dois períodos futuros (ou deixe vazio).",
                                           "Choose at least two future periods (or leave empty)."))
        cfg = {"cenarios": str(cen) if tem_cen else None, "saida": str(saida), "local": local,
               "variaveis": [VARS[i] for i in self.parameterAsEnums(parameters, "VARIAVEIS", context)] or list(VARS),
               "criterio": CRITERIOS_ID[self.parameterAsEnum(parameters, "CRITERIO", context)],
               "raio_km": self.parameterAsDouble(parameters, "RAIO", context),
               "pareadas": self.parameterAsBool(parameters, "PAREADAS", context), "periodos_proj": periodos,
               "ampliar": self.parameterAsBool(parameters, "AMPLIAR", context),
               "raio_max": self.parameterAsDouble(parameters, "RAIO_MAX", context),
               "min_pareadas": self.parameterAsInt(parameters, "MIN_PAREADAS", context),
               "tmed_normal": ("media_tmax_tmin", "compensada")[self.parameterAsEnum(parameters, "TMED_NORMAL", context)],
               "idiomas": [("pt", "en")[i] for i in self.parameterAsEnums(parameters, "IDIOMAS", context)] or [L],
               "versao": VERSAO_COMPLEMENTO}
        if tem_cen:
            feedback.pushInfo(T("Cenários: ", "Scenarios: ") + str(cen) + (T(" (corrigidos, Fase 2)", " (corrected, Phase 2)")
                                                                           if origem == "fase2" else ""))
        fb = _Feedback(feedback)
        try:
            r = executar(cfg, progresso=fb.progresso, cancelado=fb.cancelado)
        except Exception as exc:  # noqa: BLE001
            raise _erro_processamento(exc, feedback)
        ua = T("ano", "yr")
        feedback.pushInfo(T("Estações usadas: ", "Stations used: ") + str(r["n_selecionadas"]))
        for var, o in r["observadas"].items():
            feedback.pushInfo(f"{NOME[L][var]}: {o['periodo_inicial']} → {o['periodo_final']} ({o['anos']} "
                              + T("anos", "yr") + f"): {o['taxa_ano']:+.4f} {UNID[var]}/{ua}")
        for a in r["avisos"]:
            feedback.pushWarning(a)
        lang = L if L in cfg["idiomas"] else cfg["idiomas"][0]
        if not PJ.eh_legado(projeto):
            PJ.registrar(projeto)
        return {"SITUACAO": r["situacao"], "N_ESTACOES": r["n_selecionadas"],
                "TAXAS": "; ".join(f"{NOME[L][v]} {o['taxa_ano']:+.4f}" for v, o in r["observadas"].items()
                                   if o["taxa_ano"] is not None),
                "PASTA": str(saida), "RELATORIO": str(saida / f"relatorio_tendencia_{lang}.md")}
