"""Fase 2 – Correção de viés pelo método Delta (Lima et al., 2026, Land Degrad. Dev., seção 2.6).

2.1 Método Delta regional e correlação de Pearson com estações do INMET escolhidas automaticamente no banco BDMEP.
"""

from __future__ import annotations

import json
import shutil
import tempfile
from pathlib import Path

from qgis.core import (QgsProcessingException, QgsProcessingOutputFile, QgsProcessingOutputFolder,
                       QgsProcessingOutputNumber, QgsProcessingOutputString, QgsProcessingParameterBoolean,
                       QgsProcessingParameterDefinition, QgsProcessingParameterEnum, QgsProcessingParameterFile,
                       QgsProcessingParameterMultipleLayers, QgsProcessingParameterNumber,
                       QgsProcessingParameterString, QgsProcessing)

from . import projeto as PJ
from .base import VERSAO_COMPLEMENTO, _Base, _erro_processamento, _Feedback, _ler_simbologia, _tr
from .idioma import IDIOMA, T

LOCAIS = [T("Área de estudo do projeto (Fase 1)", "Project study area (Phase 1)"),
          T("Município (IBGE) ou estação do INMET, pelo nome", "Municipality (IBGE) or INMET station, by name"),
          T("Coordenadas (latitude e longitude)", "Coordinates (latitude and longitude)")]
LOCAIS_ID = ["area", "nome", "coordenadas"]
BANCO_EMBUTIDO = Path(__file__).resolve().parent / "dados" / "bdmep"   # INMET/BDMEP mensal (dados/LEIAME_dados.md)
CRITERIOS_ROT = [T("Mesma UF OU até o raio (artigo)", "Same state OR within the radius (article)"),
                 T("Mesma UF E até o raio", "Same state AND within the radius"),
                 T("Somente mesma UF", "Same state only"),
                 T("Somente até o raio (padrão)", "Within the radius only (default)")]
CRITERIOS_ID = ["uf_ou_raio", "uf_e_raio", "uf", "raio"]
MEDIAS_ROT = [T("Agrupada: soma de todos os valores mensais ÷ nº de ocorrências (artigo)",
                "Pooled: sum of all monthly values ÷ number of occurrences (article)"),
              T("Média das médias de cada estação", "Mean of each station's mean")]
MEDIAS_ID = ["agrupada", "estacoes"]
PREC_ROT = [T("Aditivo: soma do delta (artigo)", "Additive: add the delta (article)"),
            T("Multiplicativo: fator observado/WorldClim, limitado a 0,5–2,0 nos meses secos (padrão)",
              "Multiplicative: observed/WorldClim factor, limited to 0.5–2.0 in dry months (default)")]
PREC_ID = ["aditivo", "multiplicativo"]
L = "en" if IDIOMA == "en" else "pt"


class AlgDeltaINMET(_Base):
    def name(self):
        return "vies_delta_inmet"

    def displayName(self):  # noqa: N802
        return _tr(T("2.1 Método Delta e correlação de Pearson (estações INMET)",
                     "2.1 Delta method and Pearson correlation (INMET stations)"))

    def group(self):
        return _tr(T("Fase 2 – Correção de viés pelo método Delta", "Phase 2 – Delta-method bias correction"))

    def groupId(self):  # noqa: N802
        return "mcgbrasil_fase2"

    def flags(self):
        return super().flags() | self.FlagNoThreading  # layouts PyQGIS no thread principal

    def shortHelpString(self):  # noqa: N802
        return T(
            "<p>Correção de viés do WorldClim pelo <b>método Delta regional</b> e <b>correlação de Pearson</b>, como "
            "na seção 2.6 de Lima et al. (2026), <i>Land Degradation &amp; Development</i>, doi:10.1002/ldr.70808.</p>"
            "<p><b>Entradas:</b> (1) o <b>.zip dos rasters da Fase 1</b>, que você mesmo compacta: a pasta "
            "<i>1_cenarios_climaticos</i> do projeto (ou o projeto inteiro), com o histórico de tmin, tmax e prec; "
            "o complemento acha a Fase 1 dentro do .zip, ignora PNG e projetos .qgz e registra o SHA-256 do arquivo "
            "no relatório e no manifesto; (2) a <b>pasta de saída</b>, vazia (ou uma Fase 2 anterior, com "
            "<i>Refazer</i>). A Fase 3 e o AdaptaHorts aceitam essa pasta de saída diretamente. O banco mensal do INMET/BDMEP já vem no complemento (565 estações convencionais e 598 "
            "automáticas de todo o país, 1970–2020). Em <i>Parâmetros avançados</i> é possível usar outro banco "
            "exportado do portal do INMET (.zip sem descompactar ou pasta com os CSV).</p>"
            "<p><b>Seleção automática das estações:</b> pelo local de mapeamento (a área de estudo da pasta, um "
            "município ou estação pelo nome — ex.: <i>Propriá - SE</i> — ou latitude/longitude) e pelo critério "
            "(padrão desde a v1.7.0: <i>só até 200 km</i>, sem ampliação; o critério do artigo, <i>mesma UF OU "
            "raio</i>, continua disponível). "
            "Ficam só as estações com ao menos <b>120 meses (10 anos)</b> de dados no período (padrão 1970–2000, o "
            "do WorldClim). Cada estação tem o r de Pearson calculado entre as suas 12 médias mensais e as do WorldClim "
            "na área, para Tmax, Tmin e Prec; se ficar abaixo de <b>0,8</b> em qualquer uma, a estação é retirada por "
            "inteiro. A estação que falha em qualquer critério (distância, 120 meses ou r) é eliminada.</p>"
            "<p><b>Ajuste de altitude:</b> antes da média regional, as temperaturas de cada estação são levadas à "
            "altitude média da área pelo gradiente térmico vertical (0,65 °C/100 m): T + Γ·(z<sub>estação</sub> − "
            "z<sub>área</sub>). A altitude da área vem da elevação do WorldClim (wc2.1_30s_elev), salva pela etapa "
            "1.1 ou baixada agora. Sem isso, estações mais baixas que a área (ex.: Goiás em relação ao DF) criam um "
            "falso viés quente. Altitudes de cadastro suspeitas (ex.: 1,15 m em Brasília, em km) são corrigidas "
            "pelas vizinhas ou a estação sai das temperaturas.</p>"
            "<p><b>Cálculos:</b> médias regionais mensais observadas de Tmax, Tmin, Tmed, Prec e das secundárias do "
            "banco (ETP e ETR do balanço hídrico, deficiência hídrica ETP−ETR, evaporação, insolação, umidade, "
            "nebulosidade, vento, pressão, dias de chuva); média regional do WorldClim histórico (pixels da área); "
            "<b>DC = observado − WorldClim</b> por mês para Tmin e Tmax, <b>fator = observado ÷ WorldClim</b> para "
            "a precipitação (padrão desde a v1.7.0; limitado a 0,5–2,0 nos meses com WorldClim &lt; 10 mm; o "
            "aditivo do artigo continua disponível) e <b>r de Pearson</b> entre as 12 médias mensais.</p>"
            "<p><b>Saídas</b> (pasta <i>2_correcao_delta</i> do projeto): <i>correcao_vies/</i> com as estações (CSV e GeoPackage), as médias "
            "regionais, as tabelas do delta por variável (formato das Tabelas 1–3 do artigo), a correlação e o "
            "relatório em português e inglês. Se <i>Aplicar</i> estiver marcado, todos os rasters da "
            "Fase 1 (histórico e todos os modelos, SSPs e períodos) são corrigidos mês a mês e gravados com a mesma "
            "organização, estatísticas, layouts e PNG — os índices de risco usam essa pasta "
            "corrigida quando recebem a pasta do projeto. Tmed, ETP e os índices (IA, PCI, ISC) são recalculados a "
            "partir de Tmin, Tmax e Prec corrigidas, e o <b>ensemble</b> tem o viés corrigido como a média dos "
            "modelos corrigidos (os mesmos membros da Fase 1), o que equivale a aplicar o Delta ao próprio "
            "ensemble. A Fase 1 não é alterada.</p>"
            "<p>A evapotranspiração da cultura (ETc = Kc × ETo) não está no BDMEP: depende do Kc da hortaliça e "
            "entra nos índices de risco.</p>",
            "<p>WorldClim bias correction by the <b>regional Delta method</b> and <b>Pearson correlation</b>, as in "
            "section 2.6 of Lima et al. (2026), <i>Land Degradation &amp; Development</i>, doi:10.1002/ldr.70808.</p>"
            "<p><b>Inputs:</b> (1) the <b>.zip of the Phase 1 rasters</b>, which you compress yourself: the "
            "project's <i>1_cenarios_climaticos</i> folder (or the whole project), with the tmin, tmax and prec "
            "historical data; the plugin finds Phase 1 inside the .zip, skips PNG and .qgz projects and records the "
            "file's SHA-256 in the report and the manifest; (2) the <b>output folder</b>, empty (or a previous Phase 2, "
            "with <i>Redo</i>). Phase 3 and AdaptaHorts accept this output folder directly. The INMET/BDMEP monthly database is bundled with the plugin (565 conventional and 598 automatic "
            "stations across Brazil, 1970–2020). Under <i>Advanced parameters</i> another database exported from the "
            "INMET portal can be used (.zip not unzipped, or folder with the CSV files).</p>"
            "<p><b>Automatic station selection:</b> by the mapping location (the project's study area, a "
            "municipality or station by name — e.g., <i>Propriá - SE</i> — or latitude/longitude) and the criterion "
            "(default since v1.7.0: <i>within 200 km only</i>, no widening; the article's criterion, <i>same state OR "
            "radius</i>, is still available). "
            "Only stations with at least <b>120 months (10 years)</b> of data in the period are kept (default "
            "1970–2000, the WorldClim period). Each station gets the Pearson r between its 12 monthly means and WorldClim's over the "
            "area, for Tmax, Tmin and Prec; if it falls below <b>0.8</b> in any of them, the whole station is left out "
            "A station failing any criterion (distance, 120 months or r) is eliminated.</p>"
            "<p><b>Altitude adjustment:</b> before the regional mean, each station's temperatures are brought to the "
            "mean altitude of the area by the vertical lapse rate (0.65 °C/100 m): T + Γ·(z<sub>station</sub> − "
            "z<sub>area</sub>). The area altitude comes from the WorldClim elevation (wc2.1_30s_elev), saved by step "
            "1.1 or downloaded now. Without it, stations lower than the area create a false warm bias. Suspicious "
            "registered altitudes (e.g., 1.15 m in Brasília, in km) are fixed from neighbouring stations, or the "
            "station is left out of the temperatures.</p>"
            "<p><b>Calculations:</b> observed regional monthly means of Tmax, Tmin, Tmean, Prec and the secondary "
            "variables in the database (water-balance PET and AET, water deficit, evaporation, sunshine, humidity, "
            "cloudiness, wind, pressure, rainy days); WorldClim historical regional mean (pixels in the area); "
            "<b>DC = observed − WorldClim</b> per month for Tmin and Tmax, <b>factor = observed ÷ WorldClim</b> for "
            "precipitation (default since v1.7.0; limited to 0.5–2.0 in months with WorldClim &lt; 10 mm; the "
            "article's additive method is still available) and <b>Pearson r</b> between the 12 monthly means.</p>"
            "<p><b>Outputs</b> (project folder <i>2_correcao_delta</i>): <i>correcao_vies/</i> with the stations "
            "(CSV and GeoPackage), regional means, delta tables per variable (format of the article's Tables 1–3), "
            "correlation and the report in Portuguese and English. If <i>Apply</i> is ticked, every Phase 1 raster "
            "(historical and all models, SSPs and periods) is corrected month by month and written with the same "
            "organization, statistics, layouts and PNG; Tmean, PET and the indices (AI, PCI, ISC) are recomputed "
            "from the corrected Tmin, Tmax and Prec, and the <b>ensemble</b> is bias-corrected as the mean of the "
            "corrected models (the same members as in Phase 1), which equals applying the Delta to the ensemble. "
            "Phase 1 is not changed.</p>")

    def initAlgorithm(self, config=None):  # noqa: N802
        P = self.addParameter
        par = QgsProcessingParameterMultipleLayers("BANCO", _tr(T(
            "Outro banco INMET/BDMEP, .zip ou .csv (opcional; vazio = banco incluído no complemento)",
            "Other INMET/BDMEP database, .zip or .csv (optional; empty = database bundled with the plugin)")),
            QgsProcessing.TypeFile, optional=True)
        par.setFlags(par.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        P(par)
        par = QgsProcessingParameterFile("BANCO_PASTA", _tr(T("…ou pasta com outro banco (CSV e/ou .zip, lida com subpastas)",
                                            "…or folder with another database (CSV and/or .zip, subfolders included)")),
                                         behavior=QgsProcessingParameterFile.Folder, optional=True)
        par.setFlags(par.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        P(par)
        P(QgsProcessingParameterFile("CENARIOS_ZIP", _tr(T(
            "Rasters da Fase 1 (.zip da pasta 1_cenarios_climaticos, compactada por você)",
            "Phase 1 rasters (.zip of the 1_cenarios_climaticos folder, compressed by you)")),
            behavior=QgsProcessingParameterFile.File, extension="zip"))
        P(QgsProcessingParameterFile("SAIDA", _tr(T("Pasta de saída da Fase 2 (vazia, ou uma Fase 2 anterior com Refazer)",
                                                    "Phase 2 output folder (empty, or a previous Phase 2 with Redo)")),
                                     behavior=QgsProcessingParameterFile.Folder))
        P(QgsProcessingParameterEnum("LOCAL", _tr(T("Local de mapeamento", "Mapping location")), LOCAIS, defaultValue=0))
        P(QgsProcessingParameterString("NOME", _tr(T("Nome do município ou estação (ex.: Propriá - SE)", "Municipality or station name (e.g., Propriá - SE)")), optional=True))
        P(QgsProcessingParameterNumber("LATITUDE", _tr(T("Latitude (graus decimais, ex.: -10.21)", "Latitude (decimal degrees, e.g., -10.21)")),
                                       QgsProcessingParameterNumber.Double, optional=True, minValue=-35, maxValue=6))
        P(QgsProcessingParameterNumber("LONGITUDE", _tr(T("Longitude (graus decimais, ex.: -36.84)", "Longitude (decimal degrees, e.g., -36.84)")),
                                       QgsProcessingParameterNumber.Double, optional=True, minValue=-75, maxValue=-28))
        P(QgsProcessingParameterEnum("CRITERIO", _tr(T("Critério de seleção das estações", "Station selection criterion")), CRITERIOS_ROT, defaultValue=3))
        P(QgsProcessingParameterNumber("RAIO", _tr(T("Raio (km)", "Radius (km)")), QgsProcessingParameterNumber.Double, defaultValue=200,
                                       minValue=1, maxValue=1000))
        P(QgsProcessingParameterBoolean("SUBSTITUIR", _tr(T("Refazer: apagar a Fase 2 já existente na pasta de saída", "Redo: delete the existing Phase 2 in the output folder")),
                                        defaultValue=False))
        P(QgsProcessingParameterBoolean("APLICAR", _tr(T("Aplicar o delta a todos os rasters da Fase 1 (histórico e "
                                                         "projeções)", "Apply the delta to every Phase 1 raster "
                                                         "(historical and projections)")), defaultValue=True))
        P(QgsProcessingParameterString("REGIAO", _tr(T("Nome da região (entra nos títulos)", "Region name (used in the titles)")), optional=True))
        P(QgsProcessingParameterEnum("IDIOMAS", _tr(T("Idiomas dos relatórios e mapas", "Languages of reports and maps")), ["Português", "English"],
                                     allowMultiple=True, defaultValue=[0, 1]))
        P(QgsProcessingParameterBoolean("GERAR_MAPAS", _tr(T("Gerar layouts e PNG dos cenários corrigidos", "Create layouts and PNG of the corrected scenarios")),
                                        defaultValue=True))
        P(QgsProcessingParameterNumber("DPI", _tr(T("Resolução dos PNG (dpi)", "PNG resolution (dpi)")), defaultValue=300, minValue=150,
                                       maxValue=1200))
        P(QgsProcessingParameterString("AUTOR", _tr(T("Elaboração (rodapé dos mapas)", "Prepared by (map footer)")), optional=True))
        av = [QgsProcessingParameterNumber("ANO_INICIAL", _tr(T("Ano inicial das observações", "First year of observations")), defaultValue=1970,
                                           minValue=1900, maxValue=2100),
              QgsProcessingParameterNumber("ANO_FINAL", _tr(T("Ano final das observações", "Last year of observations")), defaultValue=2000,
                                           minValue=1900, maxValue=2100),
              QgsProcessingParameterEnum("MEDIA", _tr(T("Média regional", "Regional mean")), MEDIAS_ROT, defaultValue=0),
              QgsProcessingParameterNumber("MIN_ANOS", _tr(T("Mínimo de anos com dado por estação e mês", "Minimum years with data per station and month")),
                                           defaultValue=1, minValue=1, maxValue=50),
              QgsProcessingParameterEnum("METODO_PREC", _tr(T("Correção da precipitação", "Precipitation correction")), PREC_ROT, defaultValue=1),
              QgsProcessingParameterNumber("MIN_MESES", _tr(T("Mínimo de meses com dado por estação no período (120 = 10 anos)",
                                                              "Minimum months with data per station in the period (120 = 10 years)")),
                                           defaultValue=120, minValue=1, maxValue=600),
              QgsProcessingParameterNumber("RAIO_MAX", _tr(T("Ampliar o raio até (km; igual ao raio = sem ampliação, padrão)",
                                                             "Widen the radius up to (km; equal to the radius = no widening, default)")),
                                           QgsProcessingParameterNumber.Double, defaultValue=200, minValue=0, maxValue=1500),
              QgsProcessingParameterNumber("MIN_ESTACOES", _tr(T("Mínimo de estações por mês (ampliação do raio)",
                                                                 "Minimum stations per month (radius widening)")),
                                           defaultValue=3, minValue=1, maxValue=20),
              QgsProcessingParameterNumber("R_MIN", _tr(T(
                  "Correlação mínima de cada estação com o WorldClim (r; 0 = sem filtro)",
                  "Minimum correlation of each station with WorldClim (r; 0 = no filter)")),
                  QgsProcessingParameterNumber.Double, defaultValue=0.8, minValue=0, maxValue=1),
              QgsProcessingParameterBoolean("AJUSTE_ALTITUDE", _tr(T(
                  "Ajustar as temperaturas das estações à altitude média da área (gradiente térmico)",
                  "Adjust station temperatures to the mean altitude of the area (lapse rate)")), defaultValue=True),
              QgsProcessingParameterNumber("GRADIENTE", _tr(T("Gradiente térmico vertical (°C por 100 m)",
                                                              "Vertical temperature lapse rate (°C per 100 m)")),
                                           QgsProcessingParameterNumber.Double, defaultValue=0.65, minValue=0, maxValue=1.5),
              QgsProcessingParameterString("ESCALAS", _tr(T("Escalas de cores fixas (ex.: tmin=10:30; tmax=20:42; prec=0:400). "
                                                            "Vazio = mín.–máx. de todos os cenários corrigidos",
                                                            "Fixed color scales (e.g., tmin=10:30; tmax=20:42; "
                                                            "prec=0:400). Empty = min–max of all corrected scenarios")), optional=True)]
        for par in av:
            par.setFlags(par.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
            P(par)
        self.addOutput(QgsProcessingOutputString("SITUACAO", _tr(T("Situação", "Status"))))
        self.addOutput(QgsProcessingOutputNumber("N_ESTACOES", _tr(T("Estações usadas", "Stations used"))))
        self.addOutput(QgsProcessingOutputString("PEARSON", _tr(T("r de Pearson (tmax; tmin; prec)", "Pearson r (tmax; tmin; prec)"))))
        self.addOutput(QgsProcessingOutputFolder("TABELAS", _tr(T("Pasta das tabelas da correção", "Correction tables folder"))))
        self.addOutput(QgsProcessingOutputFile("RELATORIO", _tr(T("Relatório da correção", "Correction report"))))
        self.addOutput(QgsProcessingOutputNumber("N_GRUPOS", _tr(T("Grupos de 12 rasters corrigidos", "Groups of 12 corrected rasters"))))
        self.addOutput(QgsProcessingOutputNumber("N_PNG", _tr(T("Mapas PNG", "PNG maps"))))

    def processAlgorithm(self, parameters, context, feedback):  # noqa: N802
        from .vies.delta import executar
        banco = [s.split("|")[0] for s in (self.parameterAsFileList(parameters, "BANCO", context) or []) if s and s.strip()]
        pasta_banco = self.parameterAsFile(parameters, "BANCO_PASTA", context)
        if pasta_banco:
            banco.append(pasta_banco)
        if not banco:
            banco = [str(b) for b in sorted(BANCO_EMBUTIDO.glob("*.zip"))]
            if not banco:
                raise QgsProcessingException(T("Banco do INMET incluído no complemento não encontrado; reinstale o "
                                               "complemento ou informe outro banco.", "INMET database bundled with the "
                                               "plugin not found; reinstall the plugin or give another database."))
            feedback.pushInfo(T("Banco do INMET incluído no complemento (BDMEP, dados mensais de 565 estações "
                                "convencionais e 598 automáticas, 1970–2020).", "INMET database bundled with the plugin "
                                "(BDMEP, monthly data from 565 conventional and 598 automatic stations, 1970–2020)."))
        arq_zip = Path(self.parameterAsFile(parameters, "CENARIOS_ZIP", context))
        saida = Path(self.parameterAsFile(parameters, "SAIDA", context)).resolve()
        _preparar_saida(saida, self.parameterAsBool(parameters, "SUBSTITUIR", context))
        tipo = LOCAIS_ID[self.parameterAsEnum(parameters, "LOCAL", context)]
        local = {"tipo": tipo}
        if tipo == "nome":
            local["nome"] = self.parameterAsString(parameters, "NOME", context).strip()
            if not local["nome"]:
                raise QgsProcessingException(T("Informe o nome do município ou da estação (ex.: Propriá - SE).",
                                               "Give the municipality or station name (e.g., Propriá - SE)."))
        elif tipo == "coordenadas":
            if parameters.get("LATITUDE") in (None, "") or parameters.get("LONGITUDE") in (None, ""):
                raise QgsProcessingException(T("Informe a latitude e a longitude do local.", "Give the latitude and longitude."))
            local["lat"] = self.parameterAsDouble(parameters, "LATITUDE", context)
            local["lon"] = self.parameterAsDouble(parameters, "LONGITUDE", context)
        try:
            simb = _ler_simbologia(self.parameterAsString(parameters, "ESCALAS", context))
        except ValueError as exc:
            raise QgsProcessingException(str(exc))
        cfg = {"banco": banco, "cenarios": "", "saida": str(saida), "local": local,
               "criterio": CRITERIOS_ID[self.parameterAsEnum(parameters, "CRITERIO", context)],
               "raio_km": self.parameterAsDouble(parameters, "RAIO", context),
               "ano0": self.parameterAsInt(parameters, "ANO_INICIAL", context),
               "ano1": self.parameterAsInt(parameters, "ANO_FINAL", context),
               "media": MEDIAS_ID[self.parameterAsEnum(parameters, "MEDIA", context)],
               "min_anos": self.parameterAsInt(parameters, "MIN_ANOS", context),
               "metodo_prec": PREC_ID[self.parameterAsEnum(parameters, "METODO_PREC", context)],
               "min_meses": self.parameterAsInt(parameters, "MIN_MESES", context),
               "r_min_estacao": self.parameterAsDouble(parameters, "R_MIN", context),
               "raio_max": self.parameterAsDouble(parameters, "RAIO_MAX", context),
               "min_estacoes": self.parameterAsInt(parameters, "MIN_ESTACOES", context),
               "ajuste_altitude": self.parameterAsBool(parameters, "AJUSTE_ALTITUDE", context),
               "gradiente": self.parameterAsDouble(parameters, "GRADIENTE", context),
               "aplicar": self.parameterAsBool(parameters, "APLICAR", context),
               "idiomas": [("pt", "en")[i] for i in self.parameterAsEnums(parameters, "IDIOMAS", context)] or [L],
               "gerar_mapas": self.parameterAsBool(parameters, "GERAR_MAPAS", context),
               "dpi": self.parameterAsInt(parameters, "DPI", context),
               "regiao": self.parameterAsString(parameters, "REGIAO", context).strip(),
               "autor": self.parameterAsString(parameters, "AUTOR", context).strip(),
               "simbologia": simb, "versao": VERSAO_COMPLEMENTO}
        fb = _Feedback(feedback)
        from .vies.entrada_zip import ErroZip, extrair
        tmp = Path(tempfile.mkdtemp(prefix="mcgbrasil_fase1_"))
        try:
            feedback.pushInfo(T(f"Lendo os rasters da Fase 1 em {arq_zip.name}…", f"Reading Phase 1 rasters from "
                                f"{arq_zip.name}…"))
            try:
                cenarios, info_zip = extrair(arq_zip, tmp)
            except ErroZip as exc:
                raise QgsProcessingException(str(exc))
            feedback.pushInfo(T(f"   pasta no .zip: {info_zip['pasta_no_zip']}; {info_zip['arquivos_extraidos']} "
                                f"arquivos; SHA-256 {info_zip['sha256']}", f"   folder in the .zip: "
                                f"{info_zip['pasta_no_zip']}; {info_zip['arquivos_extraidos']} files; SHA-256 "
                                f"{info_zip['sha256']}"))
            if info_zip["rasters_ausentes"]:
                feedback.pushWarning(T(f"{info_zip['rasters_ausentes']} raster(s) do manifesto não estão no .zip; "
                                       "esses grupos não serão corrigidos.", f"{info_zip['rasters_ausentes']} "
                                       "raster(s) listed in the manifest are missing from the .zip; those groups "
                                       "will not be corrected."))
            cfg.update(cenarios=str(cenarios), zip_fase1=info_zip)
            r = executar(cfg, progresso=fb.progresso, cancelado=fb.cancelado)
        except QgsProcessingException:
            raise
        except Exception as exc:  # noqa: BLE001
            raise _erro_processamento(exc, feedback)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
        feedback.pushInfo(T("Local: ", "Location: ") + f"{r['local'].descricao} ({', '.join(r['local'].ufs)}). "
                          + T("Estações usadas: ", "Stations used: ") + f"{r['n_selecionadas']}.")
        for l in r["linhas"]:
            if l["selecionada"]:
                feedback.pushInfo(f"  {l['codigo']} {l['nome']} ({l['uf']}, {l['distancia_km']:.1f} km)")
        for v, a in r["ajustes"].items():
            feedback.pushInfo(f"{v}: " + T("r de Pearson", "Pearson r") + f" = {_r(a['pearson'])}; "
                              + T("viés médio", "mean bias") + f" = {a['vies_medio']:+.2f}; "
                              + T("DC mensal = ", "monthly DC = ") + ", ".join(f"{x:+.2f}" for x in a["delta"]))
        for a in r["avisos"]:
            feedback.pushWarning(a)
        if cfg["aplicar"]:
            feedback.pushInfo(T(f"{r['n_grupos']} grupos de 12 rasters corrigidos, {r['n_png']} PNG. Pasta: {r['saida']}",
                                f"{r['n_grupos']} groups of 12 rasters corrected, {r['n_png']} PNG. Folder: {r['saida']}"))
        tab = Path(r["tabelas"])
        return {"SITUACAO": r["situacao"], "N_ESTACOES": r["n_selecionadas"],
                "PEARSON": "; ".join(_r(a["pearson"]) for a in r["ajustes"].values()),
                "TABELAS": str(tab), "RELATORIO": str(tab / f"relatorio_correcao_vies_{L if L in cfg['idiomas'] else cfg['idiomas'][0]}.md"),
                "N_GRUPOS": r["n_grupos"], "N_PNG": r["n_png"]}


def _preparar_saida(saida: Path, substituir: bool) -> None:
    """A pasta de saída deve estar vazia; uma Fase 2 anterior só é apagada com Refazer."""
    if not saida.exists() or not any(saida.iterdir()):
        saida.mkdir(parents=True, exist_ok=True)
        return
    man = saida / PJ.MANIFESTO_CENARIOS
    anterior = False
    try:
        anterior = man.exists() and bool(json.loads(man.read_text(encoding="utf-8")).get("correcao_vies"))
    except (OSError, ValueError):
        pass
    anterior = anterior or (saida / "correcao_vies").is_dir()
    if not anterior:
        raise QgsProcessingException(T(f"A pasta de saída não está vazia e não é uma Fase 2 anterior ({saida}). "
                                       "Escolha uma pasta vazia.", f"The output folder is not empty and is not a "
                                       f"previous Phase 2 ({saida}). Choose an empty folder."))
    if not substituir:
        raise QgsProcessingException(T(f"Já há uma Fase 2 em {saida}. Marque 'Refazer' para apagá-la e calcular de "
                                       "novo, ou escolha outra pasta.", f"There is already a Phase 2 in {saida}. "
                                       "Tick 'Redo' to delete it and compute again, or choose another folder."))
    for x in saida.iterdir():
        shutil.rmtree(x) if x.is_dir() else x.unlink()


def _r(x) -> str:
    return "—" if x is None else f"{x:.3f}"
