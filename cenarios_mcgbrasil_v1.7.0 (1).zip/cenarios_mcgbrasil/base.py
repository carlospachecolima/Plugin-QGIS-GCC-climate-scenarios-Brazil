"""Base comum dos algoritmos de Processamento do Cenários MCGBrasil."""

from __future__ import annotations

import re
import tempfile
import time
from pathlib import Path

from qgis.core import (QgsCoordinateTransformContext, QgsProcessingAlgorithm, QgsProcessingException,
                       QgsVectorFileWriter, QgsVectorLayer)
from qgis.PyQt.QtCore import QCoreApplication, QThread
from qgis.PyQt.QtGui import QIcon

from .comum.config import Cancelado, ErroValidacao
from .idioma import IDIOMA, T

VERSAO_COMPLEMENTO = "1.6.0"
ICONE = str(Path(__file__).parent / "icon.png")
NOME = T("Cenários MCGBrasil", "MCGBrasil Climate Scenarios")
PROVEDOR_ID = "mcgbrasil" if IDIOMA == "pt" else "mcgbrasil_en"
VARIAVEIS_SIMBOLOGIA = ("tmin", "tmax", "tmed", "prec", "etp")


def _tr(texto: str) -> str:
    return QCoreApplication.translate("MCGBrasil", texto)


def _no_thread_principal() -> bool:
    app = QCoreApplication.instance()
    return app is not None and QThread.currentThread() == app.thread()


class _Feedback:
    """Adapta QgsProcessingFeedback ao motor (progresso e cancelamento)."""

    def __init__(self, feedback):
        self.f = feedback
        self._ultimo = 0.0
        self._ultima_msg = ""

    def progresso(self, pct: float, msg: str) -> None:
        if self.f is None:
            return
        self.f.setProgress(pct)
        if msg and msg != self._ultima_msg:
            self.f.setProgressText(msg)
            self._ultima_msg = msg
        agora = time.monotonic()  # no thread principal: mantém a janela responsiva e o Cancelar
        if _no_thread_principal() and agora - self._ultimo > 0.2:
            QCoreApplication.processEvents()
            self._ultimo = agora

    def cancelado(self) -> bool:
        return bool(self.f is not None and self.f.isCanceled())


def _erro_processamento(exc: Exception, feedback) -> QgsProcessingException:
    if isinstance(exc, ErroValidacao):
        for m in exc.mensagens:
            feedback.reportError(m, False)
        return QgsProcessingException(T(f"{len(exc.mensagens)} problema(s) nas entradas (lista acima). "
                                        "Corrija e execute novamente.",
                                        f"{len(exc.mensagens)} input problem(s) (listed above). Fix and run again."))
    if isinstance(exc, Cancelado):
        return QgsProcessingException(T("Processamento cancelado; resultados parciais foram removidos.",
                                        "Processing canceled; partial results were removed."))
    return QgsProcessingException(str(exc))


def _ler_simbologia(texto: str) -> dict:
    """'tmin=14:30; tmax=24:40; prec=0:250' → {'tmin': {'min': 14, 'max': 30}, ...}."""
    out: dict = {}
    for parte in filter(None, (p.strip() for p in (texto or "").replace(",", ";").split(";"))):
        try:
            var, faixa = parte.split("=")
            a, b = faixa.split(":")
            var = var.strip().lower()
            if var not in VARIAVEIS_SIMBOLOGIA:
                raise ValueError
            out[var] = {"min": float(a), "max": float(b)}
        except ValueError:
            raise QgsProcessingException(T(f"Escalas de cores: não entendi '{parte}'. Use, por exemplo, "
                                           "tmin=14:30; prec=0:250.",
                                           f"Color scales: could not read '{parte}'. Use, e.g., tmin=14:30; prec=0:250."))
    return out


def _exportar_vetor(lyr: QgsVectorLayer, destino: Path) -> Path:
    if destino.exists():
        destino.unlink()
    opc = QgsVectorFileWriter.SaveVectorOptions()
    opc.driverName = "GPKG"
    res = QgsVectorFileWriter.writeAsVectorFormatV3(lyr, str(destino), QgsCoordinateTransformContext(), opc)
    if res[0] != QgsVectorFileWriter.NoError:
        raise QgsProcessingException(T(f"Não foi possível exportar a camada {lyr.name()}: {res[1]}",
                                       f"Could not export layer {lyr.name()}: {res[1]}"))
    return destino


def _nome_camada(lyr) -> str:
    base = Path(lyr.source().split("|")[0]).stem or lyr.name() or "area"
    return re.sub(r"[^\w\-]+", "_", base)[:60] or "area"


def _pasta_temp() -> str:
    return tempfile.mkdtemp(prefix="mcgbrasil_area_")


class _Base(QgsProcessingAlgorithm):
    def icon(self):
        return QIcon(ICONE)

    def createInstance(self):  # noqa: N802
        return type(self)()

    _ACOMPANHANTES_SHP = (".shp.xml", ".dbf", ".shx", ".prj", ".cpg", ".qmd", ".sbn", ".sbx", ".qix")

    def preprocessParameters(self, parameters):  # noqa: N802
        """Troca 'area.shp.xml', 'area.dbf' etc. por 'area.shp' nos parâmetros de camada vetorial."""
        p = dict(parameters)
        for nome, valor in parameters.items():
            d = self.parameterDefinition(nome)
            if d is None or d.type() not in ("vector", "source") or not isinstance(valor, str):
                continue
            caminho = valor.split("|")[0]
            for ext in self._ACOMPANHANTES_SHP:
                if caminho.lower().endswith(ext):
                    shp = caminho[: -len(ext)] + ".shp"
                    if Path(shp).exists():
                        p[nome] = shp
                    break
        return p
