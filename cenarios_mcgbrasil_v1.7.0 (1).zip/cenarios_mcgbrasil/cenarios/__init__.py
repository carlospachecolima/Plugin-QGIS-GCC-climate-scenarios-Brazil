"""Etapa C – cenários climáticos histórico e futuros (WorldClim v2.1 / CMIP6), uma imagem por vez.

Implementa o fluxo de Fontenelle, Amorim, Cruz e Lima (2025), Revista DCS 22(83),
doi:10.54899/dcs.v22i83.3456: importar o raster multibanda (12 meses) → recortar pela
máscara → separar as bandas mensais → nomes padronizados → simbologia por variável →
projeto QGIS → estatísticas (.txt) → layouts mensais → PNG, com as etapas 4 a 8 em lotes
de 12 camadas. Os rasters mensais gerados aqui são a entrada climática dos índices
(ISOC, ISDH, ISCC, ISSA) do módulo de risco.

A lógica numérica (catalogo, nomes, processamento, estatisticas, manual) não depende do
QGIS; só ``cartografia`` usa PyQGIS.
"""
