"""Etapas cartográficas do artigo com PyQGIS: simbologia (4º prompt), projeto .qgz (5º),
layouts mensais (7º) e exportação PNG (8º), em lotes de 12 camadas.
"""

from __future__ import annotations

import datetime as _dt
from pathlib import Path

from qgis.core import (Qgis, QgsColorRampLegendNodeSettings, QgsColorRampShader, QgsCoordinateReferenceSystem,
                       QgsFillSymbol, QgsLayoutExporter, QgsLayoutItemLegend, QgsLayoutItemMap, QgsLayoutItemMapGrid,
                       QgsLayoutItemPicture, QgsLayoutItemScaleBar, QgsLayoutPoint, QgsLayoutSize, QgsLegendRenderer,
                       QgsLegendStyle, QgsMapLayerLegendUtils, QgsPrintLayout, QgsProject, QgsRasterLayer,
                       QgsRasterShader, QgsScaleBarSettings, QgsSimpleLegendNode, QgsSingleBandPseudoColorRenderer,
                       QgsSingleSymbolRenderer, QgsUnitTypes, QgsVectorLayer)
from osgeo import gdal
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor

from ..comum.layouts_qgis import _fmt, _intervalo_grade, _rotulo, _seta_norte, iniciar_qgis
from . import catalogo as C

MM = QgsUnitTypes.LayoutMillimeters


def iniciar():
    return iniciar_qgis()


# ----------------------------------------------------------------------------- 4º prompt: simbologia
def _rotulo_num(v: float, dec: int, lang: str) -> str:
    t = f"{v:.{dec}f}"
    return t.replace(".", ",") if lang == "pt" else t


def aplicar_estilo(camada: QgsRasterLayer, var: str, vmin: float, vmax: float, lang: str = "pt") -> None:
    """Paleta fixa por variável e mesma faixa de valores em todos os meses, modelos, cenários e períodos."""
    info = C.VAR[var]
    cores = info["cores"]
    n = len(cores)
    fixas = info.get("classes_fixas")
    if fixas:   # classes publicadas (IA da UNEP, PCI de Oliver): legenda por classe, igual em todos os mapas
        vmin, vmax = 0.0, float(fixas[-2][0]) * 2
    fn = QgsColorRampShader(vmin, vmax)
    fn.setColorRampType(QgsColorRampShader.Discrete if fixas else QgsColorRampShader.Interpolated)
    itens = []
    if fixas:
        for lim, cor, rot_pt, rot_en in fixas:
            itens.append(QgsColorRampShader.ColorRampItem(float(lim), QColor(cor), rot_pt if lang == "pt" else rot_en))
    for i, c in enumerate([] if fixas else cores):
        v = vmin + (vmax - vmin) * i / (n - 1)
        itens.append(QgsColorRampShader.ColorRampItem(v, QColor(c), _rotulo_num(v, info["decimais"], lang)))
    fn.setColorRampItemList(itens)
    fn.setClip(False)
    leg = QgsColorRampLegendNodeSettings()
    leg.setUseContinuousLegend(False)
    fn.setLegendSettings(leg)
    sh = QgsRasterShader()
    sh.setRasterShaderFunction(fn)
    r = QgsSingleBandPseudoColorRenderer(camada.dataProvider(), 1, sh)
    r.setClassificationMin(vmin)
    r.setClassificationMax(vmax)
    camada.setRenderer(r)
    camada.triggerRepaint()


def salvar_qml(var: str, vmin: float, vmax: float, raster_exemplo: Path, destino: Path, lang: str = "pt") -> Path:
    """Grava o arquivo de estilo (.qml) da variável, reaproveitável em qualquer camada."""
    destino.parent.mkdir(parents=True, exist_ok=True)
    cam = QgsRasterLayer(str(raster_exemplo), var, "gdal")
    if not cam.isValid():
        raise RuntimeError(f"Raster inválido para o QGIS: {raster_exemplo}")
    aplicar_estilo(cam, var, vmin, vmax, lang)
    msg, ok = cam.saveNamedStyle(str(destino))
    if not ok:
        raise RuntimeError(f"Falha ao salvar o estilo {destino}: {msg}")
    return destino


def carregar_qml(camada: QgsRasterLayer, qml: Path) -> None:
    msg, ok = camada.loadNamedStyle(str(qml))
    if not ok:
        raise RuntimeError(f"Falha ao carregar o estilo {qml}: {msg}")
    camada.triggerRepaint()


# ----------------------------------------------------------------------------- 7º prompt: layouts
def camada_contorno(gpkg: Path, nome: str) -> QgsVectorLayer:
    c = QgsVectorLayer(str(gpkg), nome, "ogr")
    if not c.isValid():
        raise RuntimeError(f"Não foi possível carregar a área de estudo ({gpkg}).")
    c.setRenderer(QgsSingleSymbolRenderer(QgsFillSymbol.createSimple(
        {"color": "0,0,0,0", "outline_color": "30,30,30,255", "outline_width": "0.5"})))
    return c


def _rodape(cen, lang: str, autor: str, versao: str, nota: str = "") -> str:
    T = C.TEXTO[lang]
    if cen.historico:
        l1 = f"{T['base']}: {T['base_hist']}  ·  {T['cenario']}: {C.HISTORICO[lang]}  ·  {T['periodo']}: {C.HIST_PERIODO}"
    else:
        l1 = (f"{T['modelo']}: {cen.modelo} (CMIP6)  ·  {T['cenario']}: {C.SSP_IPCC[cen.ssp]}  ·  "
              f"{T['periodo']}: {cen.periodo}  ·  {T['base']}: {T['base_futuro']}")
    l2 = [f"{T['src']}: WGS 84 (EPSG:4326)"]
    if autor:
        l2.append(f"{T['autoria']}: {autor}")
    l2 += [("Cenários MCGBrasil" if lang == "pt" else "MCGBrasil Climate Scenarios") + f" v{versao}", _dt.date.today().isoformat(), T["metodo"]]
    return l1 + ("\n" + nota if nota else "") + "\n" + "  ·  ".join(l2)


def criar_layout(projeto: QgsProject, camada: QgsRasterLayer, contorno: QgsVectorLayer, cen, mes: int, lang: str,
                 extensao, regiao: str, autor: str, versao: str, nota: str = "") -> QgsPrintLayout:
    if isinstance(nota, dict):  # {"pt": ..., "en": ...}
        nota = nota.get(lang) or nota.get("pt", "")
    lay = QgsPrintLayout(projeto)
    lay.initializeDefaults()  # A4 paisagem
    lay.setName(cen.nome(mes, lang))
    # título que acompanha cenário, período, variável e mês da camada
    _rotulo(lay, cen.titulo(mes, lang, regiao), 10, 6, 277, 10, 15, True, Qt.AlignmentFlag.AlignHCenter)
    T = C.TEXTO[lang]
    sub = (f"{T['base']}: WorldClim v2.1 · {C.HIST_PERIODO}" if cen.historico else
           f"{T['modelo']}: {cen.modelo} · {T['cenario']}: {C.SSP_IPCC[cen.ssp]} · {T['periodo']}: {cen.periodo}")
    if nota and "Delta" in nota:   # só grupos corrigidos na Fase 2 (Tmed, ETP e ensemble também levam nota)
        sub +="  ·  " + ("corrigido (Delta INMET)" if lang == "pt" else "bias-corrected (Delta, INMET)")
    _rotulo(lay, sub, 10, 16, 277, 6, 10, False, Qt.AlignmentFlag.AlignHCenter)

    mapa = QgsLayoutItemMap(lay)
    mapa.setCrs(QgsCoordinateReferenceSystem("EPSG:4326"))
    mapa.setLayers([contorno, camada])
    mapa.setKeepLayerSet(True)
    mapa.setFrameEnabled(True)
    lay.addLayoutItem(mapa)
    mapa.attemptMove(QgsLayoutPoint(16, 26, MM))
    mapa.attemptResize(QgsLayoutSize(198, 158, MM))
    mapa.zoomToExtent(extensao)

    grade = QgsLayoutItemMapGrid("grade", mapa)
    mapa.grids().addGrid(grade)
    iv = _intervalo_grade(mapa.extent())
    grade.setIntervalX(iv)
    grade.setIntervalY(iv)
    grade.setStyle(QgsLayoutItemMapGrid.Cross)
    grade.setCrossLength(2.0)
    grade.setFrameStyle(QgsLayoutItemMapGrid.Zebra)
    grade.setFrameWidth(1.2)
    grade.setAnnotationEnabled(True)
    grade.setAnnotationFormat(QgsLayoutItemMapGrid.DegreeMinute)
    grade.setAnnotationPrecision(0)
    grade.setAnnotationTextFormat(_fmt(6.5))
    for lado in (QgsLayoutItemMapGrid.Left, QgsLayoutItemMapGrid.Right):
        grade.setAnnotationDirection(QgsLayoutItemMapGrid.Vertical, lado)
    mapa.updateBoundingRect()

    leg = QgsLayoutItemLegend(lay)
    leg.setLinkedMap(mapa)
    leg.setAutoUpdateModel(False)
    raiz = leg.model().rootGroup()
    raiz.clear()
    no = raiz.addLayer(camada)
    QgsLegendRenderer.setNodeLegendStyle(no, QgsLegendStyle.Hidden)
    nos = leg.model().layerOriginalLegendNodes(no)
    manter = [i for i, x in enumerate(nos) if not isinstance(x, QgsSimpleLegendNode)]
    if manter and len(manter) < len(nos):  # remove a linha "Band 1 (Gray)"
        QgsMapLayerLegendUtils.setLegendNodeOrder(no, manter)
        leg.model().refreshLayerLegend(no)
    leg.setTitle((C.VAR[cen.var].get("legenda") or {}).get(lang) or cen.var_rotulo(lang))   # título curto, se houver
    leg.rstyle(QgsLegendStyle.Title).setTextFormat(_fmt(10, True))
    leg.rstyle(QgsLegendStyle.SymbolLabel).setTextFormat(_fmt(8))
    leg.setSymbolHeight(4.5)
    leg.setSymbolWidth(8)
    lay.addLayoutItem(leg)
    leg.attemptMove(QgsLayoutPoint(224, 28, MM))
    leg.refresh()

    seta = _seta_norte()
    if seta:
        pic = QgsLayoutItemPicture(lay)
        pic.setPicturePath(seta)
        lay.addLayoutItem(pic)
        pic.attemptMove(QgsLayoutPoint(234, 122, MM))
        pic.attemptResize(QgsLayoutSize(14, 20, MM))
    else:
        _rotulo(lay, "N\n▲", 234, 122, 14, 20, 14, True, Qt.AlignmentFlag.AlignHCenter)

    esc = QgsLayoutItemScaleBar(lay)
    esc.setStyle("Single Box")
    esc.setLinkedMap(mapa)
    esc.setUnits(Qgis.DistanceUnit.Kilometers)
    esc.setUnitLabel("km")
    esc.setNumberOfSegmentsLeft(0)
    esc.setNumberOfSegments(2)
    esc.setSegmentSizeMode(QgsScaleBarSettings.SegmentSizeFitWidth)
    esc.setMinimumBarWidth(25)
    esc.setMaximumBarWidth(55)
    esc.setTextFormat(_fmt(7))
    lay.addLayoutItem(esc)
    esc.attemptMove(QgsLayoutPoint(224, 152, MM))
    esc.update()

    _rotulo(lay, _rodape(cen, lang, autor, versao, nota), 14, 192, 272, 16, 7)   # abaixo das coordenadas da grade
    return lay


# ----------------------------------------------------------------------------- 8º prompt: PNG
def exportar_png(layout: QgsPrintLayout, destino: Path, dpi: int) -> Path:
    destino.parent.mkdir(parents=True, exist_ok=True)
    exp = QgsLayoutExporter(layout)
    cfg = QgsLayoutExporter.ImageExportSettings()
    cfg.dpi = dpi
    cfg.exportMetadata = False
    cfg.generateWorldFile = False
    gdal.PushErrorHandler("CPLQuietErrorHandler")  # o PNG não aceita georreferência embutida
    try:
        r = exp.exportToImage(str(destino), cfg)
    finally:
        gdal.PopErrorHandler()
    if r != QgsLayoutExporter.Success:
        raise RuntimeError(f"Falha ao exportar {destino} (código {r}).")
    return destino


# ----------------------------------------------------------------------------- lote de 12 camadas
def lote(cen, rasters: dict, lang: str, contorno_gpkg: Path, estilo: dict, projeto_qgz: Path,
         pasta_png: Path, dpi: int, regiao: str, autor: str, versao: str, progresso=None,
         nota: str = "") -> list[Path]:
    """Um lote: 12 camadas mensais com o mesmo estilo, 12 layouts, 12 PNG e o projeto .qgz."""
    projeto = QgsProject()
    projeto.setCrs(QgsCoordinateReferenceSystem("EPSG:4326"))
    projeto.setEllipsoid("EPSG:7030")  # barra de escala em km numa grade geográfica
    projeto.setTitle(cen.nome_projeto(lang))
    projeto_qgz.parent.mkdir(parents=True, exist_ok=True)
    projeto.setFileName(str(projeto_qgz))
    projeto.writeEntryBool("Paths", "/Absolute", False)
    contorno = camada_contorno(contorno_gpkg, "Área de estudo" if lang == "pt" else "Study area")
    projeto.addMapLayer(contorno)
    ext = contorno.extent()
    ext.grow(max(ext.width(), ext.height()) * 0.05)
    grupo = projeto.layerTreeRoot().addGroup(cen.nome_projeto(lang))
    pngs = []
    for i, mes in enumerate(sorted(rasters)):
        cam = QgsRasterLayer(str(rasters[mes]), cen.nome(mes, lang), "gdal")
        if not cam.isValid():
            raise RuntimeError(f"Raster inválido para o QGIS: {rasters[mes]}")
        if estilo.get("qml"):
            carregar_qml(cam, Path(estilo["qml"]))
        else:
            aplicar_estilo(cam, cen.var, estilo["min"], estilo["max"], lang)
        projeto.addMapLayer(cam, False)
        grupo.addLayer(cam)
        lay = criar_layout(projeto, cam, contorno, cen, mes, lang, ext, regiao, autor, versao, nota)
        projeto.layoutManager().addLayout(lay)
        pngs.append(exportar_png(lay, pasta_png / f"{cen.nome_arquivo(mes)}.png", dpi))
        if progresso:
            progresso(i + 1)
    if not projeto.write():
        raise RuntimeError(f"Falha ao salvar o projeto {projeto_qgz}")
    projeto.clear()
    return pngs
