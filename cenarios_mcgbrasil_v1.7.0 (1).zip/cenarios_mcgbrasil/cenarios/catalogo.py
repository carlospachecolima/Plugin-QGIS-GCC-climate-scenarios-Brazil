"""Catálogo dos dados WorldClim v2.1 / CMIP6 a 30 segundos de arco e rótulos do fluxo.

Disponibilidade conferida na página https://worldclim.org/data/cmip6/cmip6_clim30s.html
(consulta de 04/11/2026): é a mesma nos quatro períodos. "tn", "tx" e "pr" na página
correspondem a tmin, tmax e prec nos nomes dos arquivos.
"""

from __future__ import annotations

VARIAVEIS = ("tmin", "tmax", "prec")
SSPS = ("ssp126", "ssp245", "ssp370", "ssp585")
PERIODOS = ("2021-2040", "2041-2060", "2061-2080", "2081-2100")
HIST = "historical"
HIST_PERIODO = "1970-2000"
HIST_MODELO = "WorldClim"
IDIOMAS = ("pt", "en")

_TODAS = {s: set(VARIAVEIS) for s in SSPS}
# modelo -> {ssp: variáveis publicadas}
DISPONIBILIDADE_30S: dict[str, dict[str, set[str]]] = {
    "ACCESS-CM2": dict(_TODAS),
    "BCC-CSM2-MR": dict(_TODAS),
    "CMCC-ESM2": dict(_TODAS),
    "EC-Earth3-Veg": dict(_TODAS),
    "FIO-ESM-2-0": {"ssp126": set(VARIAVEIS), "ssp245": set(VARIAVEIS), "ssp585": set(VARIAVEIS)},
    "GFDL-ESM4": {"ssp126": set(VARIAVEIS), "ssp370": set(VARIAVEIS), "ssp585": {"prec"}},
    "GISS-E2-1-G": dict(_TODAS),
    "HadGEM3-GC31-LL": {"ssp126": set(VARIAVEIS), "ssp245": set(VARIAVEIS), "ssp585": set(VARIAVEIS)},
    "INM-CM5-0": dict(_TODAS),
    "IPSL-CM6A-LR": dict(_TODAS),
    "MIROC6": dict(_TODAS),
    "MPI-ESM1-2-HR": dict(_TODAS),
    "MRI-ESM2-0": dict(_TODAS),
    "UKESM1-0-LL": dict(_TODAS),
}
MODELOS = tuple(DISPONIBILIDADE_30S)
ENSEMBLE = "Ensemble"   # "modelo" dos grupos com a média dos modelos marcados (cenarios/ensemble.py)


# Variáveis calculadas a partir das baixadas: Tmed = (Tmin + Tmax)/2; ETP de Thornthwaite a partir da Tmed.
# Índices (cenarios/derivadas.py): IA = P/ETP (UNEP-WCMC, 2007; Lima et al., 2026, LDD), mensal e anual;
# PCI (Oliver, 1980) e ISC = PCI × R/P (Lima et al., 2025, Revista Aracê), anuais.
DERIVADAS = {"tmed": ("tmin", "tmax"), "etp": ("tmin", "tmax"), "ia": ("tmin", "tmax", "prec"),
             "pci": ("prec",), "isc": ("prec",)}
TODAS = ("tmin", "tmax", "tmed", "prec", "etp", "ia", "pci", "isc")   # ordem da tela de seleção
ANUAL = 13                    # "mês" 13 = valor anual (rótulo Anual)
ANUAIS = ("pci", "isc")       # só o raster anual
COM_ANUAL = ("ia",)           # 12 meses + anual


def meses_de(var: str) -> tuple:
    """Rasters de um grupo completo da variável."""
    if var in ANUAIS:
        return (ANUAL,)
    return tuple(range(1, 13)) + ((ANUAL,) if var in COM_ANUAL else ())


def completo(var: str, meses) -> bool:
    return set(meses_de(var)) <= {int(m) for m in meses}


def disponivel(modelo: str, ssp: str, var: str) -> bool:
    """Combinação publicada pelo WorldClim a 30″ (modelos fora do catálogo: desconhecido → True).

    Para as derivadas (tmed, etp), exige as variáveis de origem (tmin e tmax)."""
    if var in DERIVADAS:
        return all(disponivel(modelo, ssp, v) for v in DERIVADAS[var])
    if modelo not in DISPONIBILIDADE_30S:
        return True
    return var in DISPONIBILIDADE_30S[modelo].get(ssp, set())


def base_necessaria(variaveis) -> list[str]:
    """Variáveis a baixar do WorldClim para obter as escolhidas (tmed/etp exigem tmin e tmax)."""
    s = {v for v in variaveis if v in VARIAVEIS}
    for v in variaveis:
        s |= set(DERIVADAS.get(v, ()))
    return [v for v in VARIAVEIS if v in s]


def plano(variaveis, modelos, ssps, periodos) -> tuple[list, list]:
    """(combinações disponíveis, ausências) para a tela e para o algoritmo.

    Ausências: lista de dicts {modelo, ssp, variaveis (pedidas e sem dados), periodos} — no WorldClim a 30″ a
    disponibilidade não muda com o período, então a ausência vale para todos os períodos escolhidos.
    """
    ok, faltas = [], []
    for m in modelos:
        for s in ssps:
            sem = [v for v in variaveis if not disponivel(m, s, v)]
            com = [v for v in variaveis if disponivel(m, s, v)]
            if sem:
                faltas.append({"modelo": m, "ssp": s, "variaveis": sem, "periodos": list(periodos)})
            for p in periodos:
                if com:
                    ok.append({"modelo": m, "ssp": s, "periodo": p, "variaveis": com})
    return ok, faltas


# Rótulos de SSP como no artigo (3º prompt: "SSP1 2.6, SSP2 4.5, SSP3 7.0 ou SSP5 8.5").
SSP_ARTIGO = {"ssp126": "SSP1 2.6", "ssp245": "SSP2 4.5", "ssp370": "SSP3 7.0", "ssp585": "SSP5 8.5"}
SSP_IPCC = {"ssp126": "SSP1-2.6", "ssp245": "SSP2-4.5", "ssp370": "SSP3-7.0", "ssp585": "SSP5-8.5"}
HISTORICO = {"pt": "Histórico", "en": "Historical"}

MESES = {
    "pt": ("Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez", "Anual"),
    "en": ("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Annual"),
}
MESES_EXTENSO = {
    "pt": ("janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro",
           "outubro", "novembro", "dezembro", "anual"),
    "en": ("January", "February", "March", "April", "May", "June", "July", "August", "September",
           "October", "November", "December", "annual"),
}

# ColorBrewer (Brewer, 2002). Listas do valor mais baixo ao mais alto.
_RDYLBU = ["#313695", "#4575b4", "#74add1", "#abd9e9", "#e0f3f8", "#ffffbf", "#fee090", "#fdae61",
           "#f46d43", "#d73027", "#a50026"]
_SPECTRAL = ["#5e4fa2", "#3288bd", "#66c2a5", "#abdda4", "#e6f598", "#ffffbf", "#fee08b", "#fdae61",
             "#f46d43", "#d53e4f", "#9e0142"]
# Tmin: azul → verde → amarelo → laranja, sem vermelho, para não se confundir com Tmed e Tmax.
_TMIN = ["#2166ac", "#4393c3", "#80b8d8", "#7fc8b0", "#a6d96a", "#d9ef8b", "#ffffbf", "#fee08b", "#fdc35f",
         "#fdae61", "#f46d43"]
_ISC = ["#fff5eb", "#fee6ce", "#fdd0a2", "#fdae6b", "#fd8d3c", "#f16913", "#d94801", "#a63603", "#7f2704"]
_YLORBR = ["#ffffe5", "#fff7bc", "#fee391", "#fec44f", "#fe9929", "#ec7014", "#cc4c02", "#993404", "#662506"]
_BLUES = ["#f7fbff", "#deebf7", "#c6dbef", "#9ecae1", "#6baed6", "#4292c6", "#2171b5", "#08519c", "#08306b"]

VAR = {
    "tmin": {"pt": "Temperatura mínima", "en": "Minimum temperature", "unidade": "°C",
             "slug": {"pt": "temperatura_minima", "en": "minimum_temperature"},
             "cores": _TMIN, "decimais": 1, "agregacao": "media",
             "classes": [10, 14, 18, 20, 22, 24, 26, 28]},
    "tmax": {"pt": "Temperatura máxima", "en": "Maximum temperature", "unidade": "°C",
             "slug": {"pt": "temperatura_maxima", "en": "maximum_temperature"},
             "cores": _SPECTRAL, "decimais": 1, "agregacao": "media",
             "classes": [24, 28, 30, 32, 34, 36, 38, 40]},
    "tmed": {"pt": "Temperatura média", "en": "Mean temperature", "unidade": "°C",
             "slug": {"pt": "temperatura_media", "en": "mean_temperature"},
             "cores": _RDYLBU, "decimais": 1, "agregacao": "media",
             "classes": [14, 18, 20, 22, 24, 26, 28, 30]},
    "etp": {"pt": "Evapotranspiração potencial", "en": "Potential evapotranspiration", "unidade": "mm",
            "slug": {"pt": "evapotranspiracao_potencial", "en": "potential_evapotranspiration"},
            "cores": _YLORBR, "decimais": 0, "agregacao": "soma",
            "classes": [25, 50, 75, 100, 125, 150, 200]},
    "prec": {"pt": "Precipitação", "en": "Precipitation", "unidade": "mm",
             "slug": {"pt": "precipitacao", "en": "precipitation"},
             "cores": _BLUES, "decimais": 0, "agregacao": "soma",
             "classes": [10, 30, 60, 100, 150, 200, 300]},
    # Classes fixas: legenda por classe, igual em todos os mapas (limite superior, cor, rótulo pt/en); IA: UNEP
    # (0,05 ≤ IA < 0,20 = árido etc.), por isso os limites ficam 1e-9 abaixo; PCI: Oliver (1980), limite inclusivo
    "ia": {"pt": "Índice de aridez", "en": "Aridity index", "unidade": "P/ETP", "genero": "m",
           "legenda": {"pt": "Índice de aridez (UNEP)", "en": "Aridity index (UNEP)"},
           "slug": {"pt": "indice_aridez", "en": "aridity_index"}, "decimais": 2, "agregacao": "media",
           "classes": [0.05, 0.20, 0.50, 0.65],
           "classes_fixas": [(0.05 - 1e-9, "#8c2d04", "Hiperárido (< 0,05)", "Hyper-arid (< 0.05)"),
                             (0.20 - 1e-9, "#d95f0e", "Árido (0,05–0,20)", "Arid (0.05–0.20)"),
                             (0.50 - 1e-9, "#fec44f", "Semiárido (0,20–0,50)", "Semi-arid (0.20–0.50)"),
                             (0.65 - 1e-9, "#a1d99b", "Subúmido seco (0,50–0,65)", "Dry subhumid (0.50–0.65)"),
                             (1e9, "#2c7fb8", "Úmido (≥ 0,65)", "Humid (≥ 0.65)")],
           "cores": ["#8c2d04", "#d95f0e", "#fec44f", "#a1d99b", "#2c7fb8"]},
    "pci": {"pt": "Índice de concentração de precipitação", "en": "Precipitation concentration index",
            "unidade": "PCI", "genero": "m", "legenda": {"pt": "PCI (Oliver, 1980)", "en": "PCI (Oliver, 1980)"}, "slug": {"pt": "pci", "en": "pci"}, "decimais": 1,
            "agregacao": "media", "classes": [10, 15, 20],
            "classes_fixas": [(10, "#ffffcc", "Uniforme (≤ 10)", "Uniform (≤ 10)"),
                              (15, "#a1dab4", "Moderada (10–15)", "Moderate (10–15)"),
                              (20, "#41b6c4", "Alta (15–20)", "High (15–20)"),
                              (1e9, "#225ea8", "Muito alta (> 20)", "Very high (> 20)")],
            "cores": ["#ffffcc", "#a1dab4", "#41b6c4", "#225ea8"]},
    "isc": {"pt": "Índice de severidade de chuvas", "en": "Rainfall severity index",
            "unidade": "MJ ha⁻¹ h⁻¹", "genero": "m",
            "legenda": {"pt": "ISC (MJ ha⁻¹ h⁻¹)", "en": "ISC (MJ ha⁻¹ h⁻¹)"}, "slug": {"pt": "isc", "en": "rainfall_severity_index"},
            "decimais": 0, "agregacao": "media", "classes": None, "cores": _ISC},
}

TEXTO = {
    "pt": {"modelo": "Modelo climático", "base": "Base de dados", "cenario": "Cenário", "periodo": "Período",
           "src": "SRC", "autoria": "Elaboração", "regiao": "Região",
           "base_futuro": "WorldClim v2.1 (Fick & Hijmans, 2017) – CMIP6, 30″ (~1 km²)",
           "base_hist": "WorldClim v2.1 (Fick & Hijmans, 2017) – normais 1970–2000, 30″ (~1 km²)",
           "metodo": "Fluxo de Fontenelle et al. (2025), Revista DCS, doi:10.54899/dcs.v22i83.3456",
           "projetada": "projetada", "observada": "observada", "projetado": "projetado", "observado": "observado",
           "mes_de": "mês de", "a": "a"},
    "en": {"modelo": "Climate model", "base": "Database", "cenario": "Scenario", "periodo": "Period",
           "src": "CRS", "autoria": "Prepared by", "regiao": "Region",
           "base_futuro": "WorldClim v2.1 (Fick & Hijmans, 2017) – CMIP6, 30″ (~1 km²)",
           "base_hist": "WorldClim v2.1 (Fick & Hijmans, 2017) – 1970–2000 normals, 30″ (~1 km²)",
           "metodo": "Workflow of Fontenelle et al. (2025), Revista DCS, doi:10.54899/dcs.v22i83.3456",
           "projetada": "Projected", "observada": "Observed", "projetado": "Projected", "observado": "Observed",
           "mes_de": "", "a": "to"},
}

# Pastas auxiliares dentro da pasta de resultados (os grupos de 12 rasters ficam em <var>/... ; ver nomes.py).
PASTAS = {
    "entradas": "entradas",                  # área de estudo usada em todas as execuções
    "intermediarios": "_intermediarios",     # recorte multibanda (12 bandas) das imagens CMIP6
    "simbologia": "_simbologia",             # um .qml por variável
    "originais": "_originais_worldclim",     # arquivos baixados pela etapa 1.1
}
