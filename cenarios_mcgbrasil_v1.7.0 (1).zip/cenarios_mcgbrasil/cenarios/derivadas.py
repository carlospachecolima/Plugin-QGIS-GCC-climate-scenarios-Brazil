"""Variáveis derivadas dos rasters recortados: temperatura média e evapotranspiração potencial (Thornthwaite).

Tmed (°C) = (Tmin + Tmax) / 2, mês a mês e pixel a pixel.

ETP (mm/mês) pelo método de Thornthwaite (1948), a partir das 12 Tmed do mesmo cenário:
    I = Σ (T/5)^1,514 (meses com T > 0)
    a = 6,75·10⁻⁷ I³ − 7,71·10⁻⁵ I² + 1,792·10⁻² I + 0,49239
    ETPp = 16 (10 T / I)^a                     para 0 < T < 26,5 °C
    ETPp = −415,85 + 32,24 T − 0,43 T²          para T ≥ 26,5 °C (Willmott, Rowe & Mintz, 1985)
    ETPp = 0                                    para T ≤ 0
    ETP  = ETPp · (N / 12) · (d / 30)
com N = fotoperíodo (h) no dia 15 do mês na latitude de cada linha de pixels (FAO-56, eq. 24–25 e 34) e
d = dias do mês. ETPp é a evapotranspiração padrão de um mês de 30 dias com 12 h de luz.

Índices (mantida a ETP de Thornthwaite acima):
    IA  = P / ETP, mensal (12 meses) e anual (ΣP / ΣETP) – UNEP-WCMC (2007), como em Lima et al. (2026, LDD)
    PCI = 100 · Σ p_i² / (Σ p_i)², anual – Oliver (1980)
    ISC = PCI · R / P, anual, com R = Σ EI_i e EI_i = 68,730 · (p_i² / P)^0,841 (MJ mm ha⁻¹ h⁻¹), P = Σ p_i
          – Lima et al. (2025, Revista Aracê 7(7): 39480–39503)
p_i = precipitação do mês i (mm). O valor anual fica como o "mês" 13 (rótulo Anual).

Os grupos derivados ficam na mesma organização da Fase 1 (tmed/…, etp/…, ia/…, pci/…, isc/…), com estatísticas,
layouts e PNG.
"""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np

from . import catalogo as C
from . import manual as M
from . import nomes as N
from . import processamento as P

DIA_15 = (15, 46, 74, 105, 135, 166, 196, 227, 258, 288, 319, 349)   # dia juliano do dia 15 de cada mês
DIAS_MES = (31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
METODO = {
    "tmed": {"pt": "Tmed = (Tmin + Tmax) / 2, calculada a partir dos rasters de Tmin e Tmax do mesmo cenário",
             "en": "Tmean = (Tmin + Tmax) / 2, computed from the Tmin and Tmax rasters of the same scenario"},
    "etp": {"pt": "ETP de Thornthwaite (1948) a partir da Tmed, com Willmott et al. (1985) para T ≥ 26,5 °C e "
                  "correção pelo fotoperíodo da latitude",
            "en": "Thornthwaite (1948) PET from Tmean, with Willmott et al. (1985) for T ≥ 26.5 °C and "
                  "day-length correction by latitude"},
}
METODO.update({
    "ia": {"pt": "Índice de aridez IA = P/ETP (UNEP-WCMC, 2007), mensal e anual (ΣP/ΣETP), com ETP de Thornthwaite",
           "en": "Aridity index AI = P/PET (UNEP-WCMC, 2007), monthly and annual (ΣP/ΣPET), with Thornthwaite PET"},
    "pci": {"pt": "Índice de concentração de precipitação PCI = 100·Σp²/(Σp)² (Oliver, 1980), anual",
            "en": "Precipitation concentration index PCI = 100·Σp²/(Σp)² (Oliver, 1980), annual"},
    "isc": {"pt": "Índice de severidade de chuvas ISC = PCI·R/P, R = Σ 68,730·(p²/P)^0,841 (Lima et al., 2025)",
            "en": "Rainfall severity index ISC = PCI·R/P, R = Σ 68.730·(p²/P)^0.841 (Lima et al., 2025)"},
})
NOTA = {
    "tmed": {"pt": "Calculada: (Tmin + Tmax)/2", "en": "Computed: (Tmin + Tmax)/2"},
    "etp": {"pt": "Calculada: Thornthwaite (1948) a partir da Tmed", "en": "Computed: Thornthwaite (1948) from Tmean"},
    "ia": {"pt": "Calculado: IA = P/ETP (UNEP-WCMC, 2007), ETP de Thornthwaite",
           "en": "Computed: AI = P/PET (UNEP-WCMC, 2007), Thornthwaite PET"},
    "pci": {"pt": "Calculado: PCI de Oliver (1980) a partir da precipitação mensal",
            "en": "Computed: Oliver (1980) PCI from monthly precipitation"},
    "isc": {"pt": "Calculado: ISC = PCI × R/P (Lima et al., 2025), EI de Galdino (2015)",
            "en": "Computed: ISC = PCI × R/P (Lima et al., 2025), EI after Galdino (2015)"},
}
BASE = {"tmed": ("tmin", "tmax"), "etp": ("tmin", "tmax"), "ia": ("tmin", "tmax", "prec"), "pci": ("prec",),
        "isc": ("prec",)}
ORDEM = ("tmed", "etp", "ia", "pci", "isc")


# ----------------------------------------------------------------------------- fórmulas
def fotoperiodo(lat_graus: np.ndarray, mes: int) -> np.ndarray:
    """Horas de luz no dia 15 do mês (FAO-56)."""
    phi = np.radians(lat_graus)
    dec = 0.409 * math.sin(2 * math.pi * DIA_15[mes - 1] / 365 - 1.39)
    ws = np.arccos(np.clip(-np.tan(phi) * math.tan(dec), -1.0, 1.0))
    return 24.0 / math.pi * ws


def thornthwaite(tmed: list[np.ndarray], lat: np.ndarray) -> list[np.ndarray]:
    """12 arrays de Tmed (°C, NaN fora da área) e latitude (graus, mesmo formato) → 12 arrays de ETP (mm/mês)."""
    t = np.stack(tmed)                                   # 12 × linhas × colunas
    tp = np.where(t > 0, t, 0.0)
    I = np.nansum((tp / 5.0) ** 1.514, axis=0)
    a = 6.75e-7 * I ** 3 - 7.71e-5 * I ** 2 + 1.792e-2 * I + 0.49239
    out = []
    with np.errstate(divide="ignore", invalid="ignore"):
        for m in range(12):
            tm = t[m]
            base = np.where(I > 0, 16.0 * (10.0 * tp[m] / np.where(I > 0, I, 1.0)) ** a, 0.0)
            quente = -415.85 + 32.24 * tm - 0.43 * tm ** 2
            etpp = np.where(tm >= 26.5, quente, np.where(tm > 0, base, 0.0))
            etp = etpp * (fotoperiodo(lat, m + 1) / 12.0) * (DIAS_MES[m] / 30.0)
            out.append(np.where(np.isfinite(tm), etp, np.nan))
    return out


def latitudes(gt: tuple, forma: tuple) -> np.ndarray:
    lin = gt[3] + (np.arange(forma[0]) + 0.5) * gt[5]
    return np.repeat(lin[:, None], forma[1], axis=1)


def indice_aridez(prec: list[np.ndarray], etp: list[np.ndarray]) -> dict:
    """{1..12: P/ETP mensal, 13: ΣP/ΣETP anual}; NaN onde a ETP é zero."""
    out = {}
    with np.errstate(invalid="ignore", divide="ignore"):
        for m in range(12):
            out[m + 1] = np.where(etp[m] > 0, prec[m] / etp[m], np.nan)
        sp, se = np.stack(prec).sum(axis=0), np.stack(etp).sum(axis=0)
        out[C.ANUAL] = np.where(se > 0, sp / se, np.nan)
    return out


def pci(prec: list[np.ndarray]) -> np.ndarray:
    """Oliver (1980): 100 · Σp² / (Σp)²."""
    p = np.clip(np.stack(prec), 0, None)
    tot = p.sum(axis=0)
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.where(tot > 0, 100.0 * (p ** 2).sum(axis=0) / tot ** 2, np.nan)


def fator_r(prec: list[np.ndarray]) -> np.ndarray:
    """R = Σ EI_i, EI_i = 68,730 · (p_i² / P)^0,841 (MJ mm ha⁻¹ h⁻¹ ano⁻¹)."""
    p = np.clip(np.stack(prec), 0, None)
    tot = p.sum(axis=0)
    with np.errstate(invalid="ignore", divide="ignore"):
        ei = 68.730 * np.where(tot > 0, p ** 2 / tot, np.nan) ** 0.841
    return ei.sum(axis=0)


def isc(prec: list[np.ndarray]) -> np.ndarray:
    """Lima et al. (2025): ISC = PCI · R / P."""
    tot = np.clip(np.stack(prec), 0, None).sum(axis=0)
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.where(tot > 0, pci(prec) * fator_r(prec) / tot, np.nan)


# ----------------------------------------------------------------------------- grupos
def _bases(man: dict) -> dict:
    """(modelo, ssp, período) → variáveis de origem completas (12 meses); o ensemble fica de fora (é a média das
    derivadas de cada modelo, cenarios/ensemble.py)."""
    meses: dict = {}
    for x in man["camadas"]:
        if x["var"] in ("tmin", "tmax", "prec") and x["modelo"] != C.ENSEMBLE:
            meses.setdefault((x["modelo"], x["ssp"], x["periodo"]), {}).setdefault(x["var"], set()).add(int(x["mes"]))
    return {k: {v for v, ms in d.items() if len(ms) == 12} for k, d in meses.items()}


def combinacoes(man: dict, variaveis=("tmed", "etp")) -> list[tuple]:
    """(modelo, ssp, período) com as variáveis de origem de ao menos uma derivada pedida, histórico primeiro."""
    b = _bases(man)
    ok = [k for k, tem in b.items() if any(set(BASE[v]) <= tem for v in variaveis if v in BASE)]
    return sorted(ok, key=lambda k: (k[1] != C.HIST, k))


def _raster(man: dict, var: str, modelo: str, ssp: str, periodo: str, mes: int) -> str:
    return next(x["raster"] for x in man["camadas"] if (x["var"], x["modelo"], x["ssp"], x["periodo"], int(x["mes"]))
                == (var, modelo, ssp, periodo, mes))


def existe(man: dict, var: str, modelo: str, ssp: str, periodo: str) -> bool:
    return any((x["var"], x["modelo"], x["ssp"], x["periodo"]) == (var, modelo, ssp, periodo) for x in man["camadas"])


def calcular(saida: Path, man: dict, cfg: dict, variaveis: list[str], avisos: list, prog=None,
             combos: list | None = None, nota_extra: dict | None = None, extra_manifesto: dict | None = None) -> dict:
    """Calcula as derivadas pedidas para cada combinação com Tmin e Tmax e registra no manifesto.

    ``man`` é o manifesto já carregado da pasta ``saida`` (atualizado no lugar). Retorna contagens.
    """
    variaveis = [v for v in ORDEM if v in variaveis]
    combos = combos if combos is not None else combinacoes(man, variaveis)
    bases = _bases(man)
    mascara = saida / C.PASTAS["entradas"] / "area_estudo.gpkg"
    feitos, png, pulados = 0, 0, 0
    total = max(1, len(combos) * len(variaveis))
    k = 0
    for modelo, ssp, periodo in combos:
        tem = bases.get((modelo, ssp, periodo), set())
        possiveis = [v for v in variaveis if set(BASE[v]) <= tem]
        pendentes = [v for v in possiveis if not existe(man, v, modelo, ssp, periodo)]
        pulados += len(possiveis) - len(pendentes)
        if not pendentes:
            continue
        arrays: dict = {}
        usados: list[Path] = []
        tmed = etp = prec = None
        if set(pendentes) & {"tmed", "etp", "ia"}:
            tmed = []
            for mes in range(1, 13):
                f1 = saida / _raster(man, "tmin", modelo, ssp, periodo, mes)
                f2 = saida / _raster(man, "tmax", modelo, ssp, periodo, mes)
                a, gt = P.ler(f1)
                b, _ = P.ler(f2)
                tmed.append((a + b) / 2.0)
                usados += [f1, f2]
            arrays["tmed"] = dict(enumerate(tmed, start=1))
            if set(pendentes) & {"etp", "ia"}:
                etp = thornthwaite(tmed, latitudes(gt, tmed[0].shape))
                arrays["etp"] = dict(enumerate(etp, start=1))
        if set(pendentes) & {"ia", "pci", "isc"}:
            prec = []
            for mes in range(1, 13):
                f = saida / _raster(man, "prec", modelo, ssp, periodo, mes)
                prec.append(P.ler(f)[0])
                usados.append(f)
            if "ia" in pendentes:
                arrays["ia"] = indice_aridez(prec, etp)
            if "pci" in pendentes:
                arrays["pci"] = {C.ANUAL: pci(prec)}
            if "isc" in pendentes:
                arrays["isc"] = {C.ANUAL: isc(prec)}
        ref_raster = usados[0]
        for var in pendentes:
            k += 1
            c = N.Cenario(var, modelo, ssp, periodo)
            if prog:
                prog(100.0 * k / total, f"{var} {c.chave}")
            destino = M.pastas_do_grupo(saida, c)["grupo"]
            mensais = {}
            for mes in sorted(arrays[var]):
                mensais[mes] = P.gravar_como(ref_raster, arrays[var][mes],
                                             destino / f"{c.nome_arquivo(mes)}.tif", c.nome(mes, "pt"),
                                             {"variavel": var, "modelo": modelo, "ssp": ssp, "periodo": periodo,
                                              "mes": mes, "metodo": METODO[var]["en"]})
            if var == "etp":
                neg = sum(int((np.asarray(a) < 0).sum()) for a in arrays["etp"].values())
                if neg:
                    avisos.append(f"ETP {c.chave}: {neg} pixel(s)-mês negativos (T muito alta na fórmula de "
                                  "Willmott); confira a área.")
            criados = list(mensais.values())
            nota = {l: NOTA[var][l] + ((" · " + nota_extra[l]) if nota_extra else "") for l in ("pt", "en")}
            av: list[str] = []
            r = M.finalizar_grupo(saida, c, mensais, cfg, man, mascara, av, lambda *_: None, criados, nota=nota)
            avisos += [a for a in av if not a.startswith("Escala de cores de")]
            M.registrar_grupo(saida, man, c, mensais, cfg, r, [METODO[var]["pt"]], av, criados,
                              arquivos=[Path(x).name for x in usados],
                              extra={**(extra_manifesto or {}), "variaveis_derivadas": {
                                  v: METODO[v] for v in ORDEM}})
            feitos += 1
            png += r["mapas"].get("n_png", 0)
    return {"grupos": feitos, "png": png, "ja_existiam": pulados}
