"""Ensemble de modelos: média, pixel a pixel e mês a mês, dos modelos CMIP6 marcados pelo usuário.

Para cada variável × SSP × período, entram os modelos marcados que têm os 12 meses no projeto (modelos sem
dados naquele cenário, como GFDL-ESM4 no SSP2 4.5, ficam de fora e são informados). Pesos iguais:

    Ensemble(x, m) = (1/n) Σ_i X_i(x, m)

Tmed e ETP do ensemble são a média das Tmed e ETP de cada modelo (não recalculadas da Tmin/Tmax média), para
que a ETP do ensemble seja a média das ETP, como nas demais variáveis.

O grupo do ensemble fica como um "modelo" chamado Ensemble (<var>/<período>/Ensemble/<SSPxxx>), com
estatísticas, layouts e PNG, e é lido pelas fases seguintes e pelo AdaptaHorts como qualquer modelo. Na
subpasta ``incerteza`` do grupo ficam, por mês, o desvio-padrão entre os modelos (n − 1) e a amplitude
(máximo − mínimo), além da lista dos modelos usados.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np

from . import catalogo as C
from . import manual as M
from . import nomes as N
from . import processamento as P

ENSEMBLE = C.ENSEMBLE
MIN_MODELOS = 2
METODO = {"pt": "Ensemble: média aritmética, pixel a pixel e mês a mês, dos modelos marcados (pesos iguais); "
                "desvio-padrão (n − 1) e amplitude entre modelos na subpasta incerteza",
          "en": "Ensemble: arithmetic mean, pixel by pixel and month by month, of the selected models (equal "
                "weights); between-model standard deviation (n − 1) and range in the incerteza subfolder"}


def _meses(man: dict) -> dict:
    out: dict = {}
    for x in man["camadas"]:
        if x["ssp"] != C.HIST and x["modelo"] != ENSEMBLE:
            out.setdefault((x["var"], x["modelo"], x["ssp"], x["periodo"]), {})[int(x["mes"])] = x["raster"]
    return out


def planejar(man: dict, modelos, variaveis=None, ssps=None, periodos=None) -> tuple[list[dict], list[dict]]:
    """(alvos, ausências). Alvo: {var, ssp, periodo, membros}; ausência: alvo com os modelos marcados sem dados."""
    meses = _meses(man)
    modelos = [m for m in modelos if m != ENSEMBLE]
    chaves = sorted({(v, s, p) for (v, _m, s, p) in meses
                     if (not variaveis or v in variaveis) and (not ssps or s in ssps) and (not periodos or p in periodos)},
                    key=lambda k: (C.TODAS.index(k[0]) if k[0] in C.TODAS else 9, k[2], k[1]))
    alvos, faltas = [], []
    for v, s, p in chaves:
        membros = [m for m in modelos if C.completo(v, meses.get((v, m, s, p), {}))]
        sem = [m for m in modelos if m not in membros]
        alvos.append({"var": v, "ssp": s, "periodo": p, "membros": membros})
        if sem:
            faltas.append({"var": v, "ssp": s, "periodo": p, "modelos": sem})
    return alvos, faltas


def _registro(man: dict) -> dict:
    return dict(man.get("ensemble") or {"metodo": METODO, "grupos": {}})


def calcular(saida: Path, man: dict, cfg: dict, alvos: list[dict], avisos: list, prog=None,
             min_modelos: int = MIN_MODELOS, nota_extra: dict | None = None, extra_manifesto: dict | None = None) -> dict:
    """Calcula os grupos do ensemble pedidos em ``alvos`` e registra no manifesto (``man`` atualizado no lugar).

    Um grupo já existente com os mesmos modelos é mantido; com outros modelos, é refeito.
    """
    saida = Path(saida)
    meses = _meses(man)
    mascara = saida / C.PASTAS["entradas"] / "area_estudo.gpkg"
    mcfg = {**cfg, "classes": cfg.get("classes") or {}, "qml": cfg.get("qml")}
    feitos = png = mantidos = 0
    pulados: list[str] = []
    for k, a in enumerate(alvos):
        var, ssp, per, membros = a["var"], a["ssp"], a["periodo"], list(a["membros"])
        c = N.Cenario(var, ENSEMBLE, ssp, per)
        rot = f"{var} {per} {C.SSP_ARTIGO.get(ssp, ssp)}"
        membros = [m for m in membros if C.completo(var, meses.get((var, m, ssp, per), {}))]
        if len(membros) < min_modelos:
            pulados.append(f"{rot}: {len(membros)} modelo(s) com dados (mínimo {min_modelos})")
            continue
        reg = _registro(man)
        existe = any((x["var"], x["modelo"], x["ssp"], x["periodo"]) == (var, ENSEMBLE, ssp, per) for x in man["camadas"])
        if existe and reg["grupos"].get(c.chave) == membros:
            mantidos += 1
            continue
        if existe:
            M._remover_cenario(saida, c, man)
        if prog:
            prog(100.0 * k / max(1, len(alvos)), f"Ensemble {rot} ({len(membros)} modelos)")
        pilha, ref = [], None
        mensais, incert = {}, []
        destino = M.pastas_do_grupo(saida, c)["grupo"]
        for mes in C.meses_de(var):
            arrs = []
            for m in membros:
                f = saida / meses[(var, m, ssp, per)][mes]
                x, _ = P.ler(f)
                arrs.append(x)
                ref = ref or f
            pilha = np.stack(arrs)
            validos = np.isfinite(pilha).all(axis=0)          # pixel válido em todos os modelos
            with np.errstate(invalid="ignore"):
                media = np.where(validos, pilha.mean(axis=0), np.nan)
                dp = np.where(validos, pilha.std(axis=0, ddof=1), np.nan)
                amp = np.where(validos, pilha.max(axis=0) - pilha.min(axis=0), np.nan)
            tags = {"variavel": var, "modelo": ENSEMBLE, "ssp": ssp, "periodo": per, "mes": mes,
                    "n_modelos": len(membros), "modelos": ",".join(membros), "metodo": METODO["en"]}
            mensais[mes] = P.gravar_como(ref, media, destino / f"{c.nome_arquivo(mes)}.tif", c.nome(mes, "pt"), tags)
            for sufixo, arr, desc in (("dp", dp, "desvio-padrão entre modelos"), ("amplitude", amp, "amplitude entre modelos")):
                incert.append(P.gravar_como(ref, arr, destino / "incerteza" / f"{c.nome_arquivo(mes)}_{sufixo}.tif",
                                            f"{c.nome(mes, 'pt')} – {desc}", {**tags, "estatistica": sufixo}))
        lista = destino / "incerteza" / "modelos_do_ensemble.txt"
        lista.write_text(f"Ensemble {rot}\n{len(membros)} modelos (pesos iguais):\n" + "\n".join(membros) + "\n"
                         + (("\nModelos marcados sem dados neste cenário: " + ", ".join(a["sem"]) + "\n")
                            if a.get("sem") else ""), encoding="utf-8")
        n = len(membros)
        txt_pt = f"Ensemble de {n} modelos CMIP6" + (f" ({', '.join(membros)})" if n <= 4 else "")
        txt_en = f"Ensemble of {n} CMIP6 models" + (f" ({', '.join(membros)})" if n <= 4 else "")
        nota = {"pt": txt_pt + ((" · " + nota_extra["pt"]) if nota_extra else ""),
                "en": txt_en + ((" · " + nota_extra["en"]) if nota_extra else "")}
        criados = list(mensais.values()) + incert + [lista]
        av: list[str] = []
        r = M.finalizar_grupo(saida, c, mensais, mcfg, man, mascara, av, lambda *_: None, criados, nota=nota)
        avisos += [x for x in av if not x.startswith("Escala de cores de")]
        reg["grupos"][c.chave] = membros
        M.registrar_grupo(saida, man, c, mensais, mcfg, r, [METODO["pt"]], av, criados,
                          arquivos=[meses[(var, m, ssp, per)][mes] for m in membros for mes in C.meses_de(var)],
                          extra={**(extra_manifesto or {}), "ensemble": reg})
        feitos += 1
        png += r["mapas"].get("n_png", 0)
    if pulados:
        avisos.append("Ensemble não calculado (poucos modelos): " + "; ".join(pulados) + ".")
    return {"grupos": feitos, "png": png, "mantidos": mantidos, "pulados": len(pulados)}


def rotulo_faltas(faltas: list[dict], lang: str = "pt") -> list[str]:
    """Agrupa por SSP os modelos marcados que ficam fora do ensemble por não terem dados."""
    por: dict = {}
    for f in faltas:
        por.setdefault((f["ssp"], tuple(f["modelos"])), set()).add(f["var"])
    out = []
    for (ssp, mods), vs in sorted(por.items()):
        v = ", ".join(sorted(vs, key=lambda x: C.TODAS.index(x) if x in C.TODAS else 9))
        if lang == "en":
            out.append(f"{C.SSP_ARTIGO.get(ssp, ssp)} ({v}): without {', '.join(mods)}")
        else:
            out.append(f"{C.SSP_ARTIGO.get(ssp, ssp)} ({v}): sem {', '.join(mods)}")
    return out
