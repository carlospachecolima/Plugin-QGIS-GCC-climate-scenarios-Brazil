"""6º prompt do artigo: estatísticas básicas por camada mensal, exportadas em .txt.

Média, mediana, desvio-padrão, intervalo de confiança de 95% da média e área ocupada por
classes de valor predefinidas. A área de cada pixel é a área real na superfície terrestre
(em grade geográfica, ela diminui com a latitude).
"""

from __future__ import annotations

import math

import numpy as np

from . import catalogo as C

RAIO_TERRA_KM = 6371.0088
CAMPOS = ("n_pixels", "area_km2", "minimo", "maximo", "media", "mediana", "desvio_padrao", "ic95_inf", "ic95_sup")


def areas_pixel_km2(gt: tuple, forma: tuple) -> np.ndarray:
    _x0, dx, _rx, y0, _ry, dy = gt
    bordas = np.radians(y0 + dy * np.arange(forma[0] + 1))
    faixa = np.abs(np.sin(bordas[:-1]) - np.sin(bordas[1:]))
    linhas = RAIO_TERRA_KM ** 2 * abs(math.radians(dx)) * faixa
    return np.repeat(linhas[:, None], forma[1], axis=1)


def rotulos_classes(limites: list[float], unidade: str) -> list[str]:
    r = [f"< {limites[0]:g} {unidade}"]
    r += [f"{a:g}–{b:g} {unidade}" for a, b in zip(limites[:-1], limites[1:])]
    return r + [f"≥ {limites[-1]:g} {unidade}"]


def calcular(arr: np.ndarray, areas: np.ndarray, limites: list[float] | None, unidade: str) -> dict:
    ok = np.isfinite(arr)
    v, w = arr[ok], areas[ok]
    n = int(v.size)
    if n == 0:
        raise ValueError("camada sem pixels válidos")
    media = float(v.mean())
    dp = float(v.std(ddof=1)) if n > 1 else 0.0
    meia = 1.96 * dp / math.sqrt(n)
    s = {"n_pixels": n, "area_km2": float(w.sum()), "minimo": float(v.min()), "maximo": float(v.max()),
         "media": media, "mediana": float(np.median(v)), "desvio_padrao": dp,
         "ic95_inf": media - meia, "ic95_sup": media + meia, "classes": []}
    if limites:
        idx = np.digitize(v, limites)
        for i, rot in enumerate(rotulos_classes(limites, unidade)):
            a = float(w[idx == i].sum())
            s["classes"].append({"classe": rot, "area_km2": a, "pct": 100.0 * a / s["area_km2"]})
    return s


_NOMES = {
    "pt": {"n_pixels": "Pixels válidos", "area_km2": "Área total (km²)", "minimo": "Mínimo", "maximo": "Máximo",
           "media": "Média", "mediana": "Mediana", "desvio_padrao": "Desvio-padrão (amostral)",
           "ic95_inf": "IC 95% da média – limite inferior", "ic95_sup": "IC 95% da média – limite superior",
           "classes": "Área ocupada por classe", "titulo": "Estatísticas da camada", "camada": "Camada",
           "arquivo": "Raster", "nota": "IC 95% = média ± 1,96·DP/√n. Área de cada pixel calculada na superfície "
                                          "terrestre (raio médio 6371,0088 km)."},
    "en": {"n_pixels": "Valid pixels", "area_km2": "Total area (km²)", "minimo": "Minimum", "maximo": "Maximum",
           "media": "Mean", "mediana": "Median", "desvio_padrao": "Standard deviation (sample)",
           "ic95_inf": "Mean 95% CI – lower bound", "ic95_sup": "Mean 95% CI – upper bound",
           "classes": "Area occupied by class", "titulo": "Layer statistics", "camada": "Layer",
           "arquivo": "Raster", "nota": "95% CI = mean ± 1.96·SD/√n. Pixel area computed on the Earth's surface "
                                          "(mean radius 6371.0088 km)."},
}


def _num(x: float, lang: str, d: int = 3) -> str:
    t = f"{x:,.{d}f}"
    if lang == "pt":
        t = t.replace(",", "§").replace(".", ",").replace("§", ".")
    return t


def texto(s: dict, cenario, mes: int, lang: str, raster: str, regiao: str = "") -> str:
    N, T = _NOMES[lang], C.TEXTO[lang]
    un = C.VAR[cenario.var]["unidade"]
    L = [f"{N['titulo']}: {cenario.nome(mes, lang)}", "",
         f"{N['camada']}: {cenario.nome(mes, lang)}",
         f"{T['modelo']}: {'—' if cenario.historico else cenario.modelo + ' (CMIP6)'}",
         f"{T['cenario']}: {cenario.ssp_rotulo(lang)}",
         f"{T['periodo']}: {C.HIST_PERIODO if cenario.historico else cenario.periodo}",
         f"{T['base']}: {T['base_hist'] if cenario.historico else T['base_futuro']}"]
    if regiao:
        L.append(f"{T['regiao']}: {regiao}")
    L += [f"{N['arquivo']}: {raster}", ""]
    for k in CAMPOS:
        v = s[k]
        if k == "n_pixels":
            L.append(f"{N[k]}: {v}")
        elif k == "area_km2":
            L.append(f"{N[k]}: {_num(v, lang, 2)}")
        else:
            L.append(f"{N[k]} ({un}): {_num(v, lang)}")
    if s["classes"]:
        L += ["", f"{N['classes']}:"]
        for c in s["classes"]:
            L.append(f"  {c['classe']}: {_num(c['area_km2'], lang, 2)} km² ({_num(c['pct'], lang, 1)}%)")
    L += ["", N["nota"], T["metodo"]]
    return "\n".join(L) + "\n"


def linha_csv(s: dict, cenario, mes: int, lang: str, raster: str) -> dict:
    cab = {"pt": ("variavel", "modelo", "ssp", "periodo", "mes", "camada", "raster"),
           "en": ("variable", "model", "ssp", "period", "month", "layer", "raster")}[lang]
    vals = (cenario.var, cenario.modelo if not cenario.historico else C.HIST_MODELO,
            cenario.ssp_rotulo(lang), cenario.periodo, mes, cenario.nome(mes, lang), raster)
    linha = dict(zip(cab, vals))
    nomes_en = {"n_pixels": "n_pixels", "area_km2": "area_km2", "minimo": "min", "maximo": "max", "media": "mean",
                "mediana": "median", "desvio_padrao": "sd", "ic95_inf": "ci95_low", "ic95_sup": "ci95_high"}
    for k in CAMPOS:
        linha[k if lang == "pt" else nomes_en[k]] = s[k]
    for c in s["classes"]:
        linha[("area_km2 " if lang == "pt" else "area_km2 ") + c["classe"]] = c["area_km2"]
    return linha
