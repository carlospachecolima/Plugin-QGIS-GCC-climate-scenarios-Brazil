"""Cenários climáticos com uma imagem WorldClim por vez, informada pelo usuário.

Cada execução processa um único conjunto de 12 meses:

* futuro – um GeoTIFF CMIP6 de 12 bandas (uma variável × modelo × SSP × período), como baixado do
  WorldClim (ex.: wc2.1_30s_tmin_ACCESS-CM2_ssp585_2081-2100.tif). Etapas do artigo (Fontenelle et al.,
  2025): importar o multibanda → recortar pela máscara → separar as 12 bandas → renomear.
* histórico – uma variável de 1970–2000: o .zip do WorldClim (ex.: wc2.1_30s_tmin.zip) ou os 12 GeoTIFFs
  mensais. Cada arquivo mensal é recortado diretamente pela máscara, sem empilhar, e renomeado.

Depois, em lote de 12: simbologia da variável (.qml), projeto .qgz e, por último, estatísticas (.txt),
layouts e PNG em português e inglês.

A pasta de resultados é cumulativa: as execuções seguintes (outros meses do histórico, outras variáveis,
modelos, SSPs e períodos) são acrescentadas à mesma pasta, com a mesma área, a mesma grade e a mesma
escala de cores por variável. O manifesto_cenarios.json lista tudo o que a pasta contém e é a entrada
dos índices de risco.
"""

from __future__ import annotations

import csv
import json
import math
import os
import re
import shutil
import tempfile
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
from osgeo import gdal, osr

from ..comum import geo
from ..comum.config import ErroValidacao
from ..comum.util import sha256
from ..comum.util import _csv, _Progresso, _versoes
from . import catalogo as C
from . import estatisticas as E
from . import nomes as N
from . import processamento as P

MANIFESTO = "manifesto_cenarios.json"
ESTRUTURA = 2  # <var>/historico/WorldClim e <var>/<período>/<modelo>/<SSPxxx>, um grupo de 12 rasters por pasta
_MES = re.compile(r"_(\d{2})\.tiff?$", re.I)


def faixa_redonda(vmin: float, vmax: float) -> tuple[float, float]:
    if vmax <= vmin:
        return vmin - 1, vmax + 1
    span = vmax - vmin
    mag = 10 ** math.floor(math.log10(span))
    passo = mag / 2 if span / mag < 3 else mag
    return round(math.floor(vmin / passo) * passo, 10), round(math.ceil(vmax / passo) * passo, 10)


def _epsg4326(wkt: str) -> bool:
    if not wkt:
        return False
    s = osr.SpatialReference(wkt=wkt)
    if geo.epsg_de(s) == 4326:
        return True
    datum = (s.GetAttrValue("DATUM") or "").upper()
    return bool(s.IsGeographic()) and "WGS" in datum and "84" in datum


# ----------------------------------------------------------------------------- identificação da imagem
def _membros_zip(caminho: str) -> list[str]:
    base = f"/vsizip/{caminho}"
    nomes = gdal.ReadDirRecursive(base) or []
    return [f"{base}/{n}" for n in nomes if n.lower().endswith((".tif", ".tiff"))]


def identificar(cfg: dict) -> tuple:
    """(Cenario, {mês: fonte} no histórico ou [fonte] no futuro)."""
    arqs = [a for a in (cfg.get("arquivos") or []) if a]
    if not arqs:
        raise ErroValidacao(["Informe a imagem do WorldClim."])
    for a in arqs:
        if not a.startswith("/vsi") and not Path(a).exists():
            raise ErroValidacao([f"Arquivo não encontrado: {a}"])
    if cfg["tipo"] == "futuro":
        if len(arqs) != 1:
            raise ErroValidacao(["Projeção: informe uma única imagem CMIP6 (GeoTIFF de 12 bandas)."])
        r = N.reconhecer(arqs[0])
        nome = r[0] if r and r[1] is None else None
        var = cfg.get("variavel") or (nome.var if nome else None)
        modelo = cfg.get("modelo") or (nome.modelo if nome else None)
        ssp = cfg.get("ssp") or (nome.ssp if nome else None)
        periodo = cfg.get("periodo") or (nome.periodo if nome else None)
        faltam = [k for k, v in (("variável", var), ("modelo", modelo), ("SSP", ssp), ("período", periodo)) if not v]
        if faltam:
            raise ErroValidacao([f"Não foi possível ler {', '.join(faltam)} do nome '{os.path.basename(arqs[0])}' "
                                 "(padrão do WorldClim: wc2.1_30s_<tmin|tmax|prec>_<MODELO>_<sspXYZ>_<AAAA-AAAA>.tif). "
                                 "Preencha esses campos no formulário."])
        erros = []
        if var not in C.VARIAVEIS:
            erros.append(f"Variável inválida: {var}.")
        if ssp not in C.SSPS:
            erros.append(f"SSP inválido: {ssp}.")
        if periodo not in C.PERIODOS:
            erros.append(f"Período inválido: {periodo}.")
        if erros:
            raise ErroValidacao(erros)
        if nome and (nome.var, nome.modelo, nome.ssp, nome.periodo) != (var, modelo, ssp, periodo):
            cfg.setdefault("_avisos", []).append(
                f"O nome do arquivo indica {nome.var} {nome.modelo} {nome.ssp} {nome.periodo}, mas foi informado "
                f"{var} {modelo} {ssp} {periodo}; usado o informado.")
        return N.Cenario(var, modelo, ssp, periodo, nome.res if nome else "30s"), [arqs[0]]

    # histórico
    fontes = []
    for a in arqs:
        fontes += _membros_zip(a) if a.lower().endswith(".zip") else [a]
    meses: dict[int, str] = {}
    variaveis = set()
    erros = []
    for f in fontes:
        r = N.reconhecer(os.path.basename(f))
        if r and r[1] is not None:
            variaveis.add(r[0].var)
            mes = r[1]
        else:
            m = _MES.search(os.path.basename(f))
            if not m:
                erros.append(f"'{os.path.basename(f)}': não identifiquei o mês pelo nome (padrão wc2.1_30s_<var>_<MM>.tif).")
                continue
            mes = int(m.group(1))
        if not 1 <= mes <= 12:
            erros.append(f"'{os.path.basename(f)}': mês {mes} inválido.")
        elif mes in meses:
            erros.append(f"Mês {mes} repetido: {os.path.basename(meses[mes])} e {os.path.basename(f)}.")
        else:
            meses[mes] = f
    if len(variaveis) > 1:
        erros.append(f"Os arquivos misturam variáveis ({', '.join(sorted(variaveis))}); informe uma variável por vez.")
    faltam = [m for m in range(1, 13) if m not in meses]
    if faltam:
        erros.append(f"Histórico incompleto: faltam os meses {faltam}. São necessários os 12 arquivos mensais "
                     "(ou o .zip do WorldClim, que os contém).")
    var = cfg.get("variavel") or (next(iter(variaveis)) if len(variaveis) == 1 else None)
    if not var:
        erros.append("Não identifiquei a variável pelo nome dos arquivos; escolha-a no formulário.")
    elif variaveis and var not in variaveis:
        cfg.setdefault("_avisos", []).append(f"Os nomes indicam {next(iter(variaveis))}, mas foi informado {var}; "
                                             "usado o informado.")
    if erros:
        raise ErroValidacao(erros)
    return N.historico(var), {m: meses[m] for m in range(1, 13)}


# ----------------------------------------------------------------------------- execução
def _ler_manifesto(saida: Path) -> dict | None:
    f = saida / MANIFESTO
    if not f.exists():
        return None
    man = json.loads(f.read_text(encoding="utf-8"))
    if man.get("modo") != "manual" or man.get("estrutura") != ESTRUTURA:
        raise ErroValidacao([f"A pasta '{saida}' foi gerada por uma versão anterior do complemento, com outra "
                             "organização de pastas; use uma pasta nova."])
    return man


def pastas_do_grupo(saida: Path, c: N.Cenario) -> dict:
    """Tudo o que pertence a um grupo de 12 rasters fica na pasta dele."""
    grupo = saida.joinpath(*c.grupo())
    return {"grupo": grupo,
            "intermediario": saida.joinpath(C.PASTAS["intermediarios"], *c.grupo()),
            "estatisticas": {lang: grupo / f"estatisticas_{lang}" for lang in C.IDIOMAS},
            "mapas": {lang: grupo / f"mapas_{lang}" for lang in C.IDIOMAS},
            "projeto": {lang: grupo / f"{c.nome_projeto(lang)}.qgz" for lang in C.IDIOMAS}}


def _remover_cenario(saida: Path, c: N.Cenario, man: dict) -> None:
    pg = pastas_do_grupo(saida, c)
    for d in (pg["grupo"], pg["intermediario"]):
        if d.exists():
            shutil.rmtree(d)
    man["camadas"] = [x for x in man["camadas"]
                      if (x["var"], x["modelo"], x["ssp"], x["periodo"]) != (c.var, c.modelo, c.ssp, c.periodo)]
    (man.get("notas_mapas") or {}).pop(c.chave, None)


def executar(cfg: dict, progresso=None, cancelado=None) -> dict:
    padrao = {"tipo": "futuro", "idiomas": ["pt", "en"], "gerar_mapas": True, "dpi": 300,
              "regiao": "", "autor": "", "simbologia": {}, "classes": {}, "qml": None, "substituir": False,
              "versao": ""}
    cfg = {**padrao, **{k: v for k, v in cfg.items() if v is not None}}
    prog = _Progresso(progresso, cancelado)
    prog(0, "Identificando a imagem")
    if cfg["tipo"] not in ("futuro", "historico"):
        raise ErroValidacao([f"Tipo inválido: {cfg['tipo']}."])
    if not cfg["idiomas"] or any(l not in C.IDIOMAS for l in cfg["idiomas"]):
        raise ErroValidacao(["Escolha português e/ou inglês."])
    c, fontes = identificar(cfg)
    avisos = list(cfg.pop("_avisos", []))
    if cfg.get("_escala"):  # escala e classes informadas no formulário valem para a variável desta imagem
        cfg["simbologia"] = {c.var: cfg.pop("_escala")}
    if cfg.get("_classes"):
        cfg["classes"] = {c.var: cfg.pop("_classes")}
    saida = Path(cfg["saida"])
    saida.mkdir(parents=True, exist_ok=True)
    man = _ler_manifesto(saida) or {"modo": "manual", "estrutura": ESTRUTURA, "camadas": [], "simbologia": {}, "grade": None,
                                    "execucoes": [], "saidas_sha256": {}}
    existe = any((x["var"], x["modelo"], x["ssp"], x["periodo"]) == (c.var, c.modelo, c.ssp, c.periodo)
                 for x in man["camadas"])
    if existe and not cfg["substituir"]:
        raise ErroValidacao([f"A pasta já contém {c.chave}. Marque 'Substituir se já existir' para refazer."])

    # validação das fontes
    lista = list(fontes.values()) if c.historico else fontes
    erros = []
    for f in lista:
        try:
            d = P.info(f)
        except RuntimeError as exc:
            erros.append(str(exc))
            continue
        if not _epsg4326(d["wkt"]):
            erros.append(f"{os.path.basename(f)}: SRC diferente de EPSG:4326 (WGS 84), o do WorldClim.")
        esperado = 1 if c.historico else 12
        if d["bandas"] != esperado:
            erros.append(f"{os.path.basename(f)}: {d['bandas']} banda(s); esperado {esperado}"
                         + (" (um mês)." if c.historico else " (meses). Verifique se escolheu a imagem CMIP6."))
    area, e = geo.ler_vetor_area(Path(cfg["area"]))
    erros += e
    if area is not None:
        avisos += area.avisos
    if erros:
        raise ErroValidacao(erros)

    pasta = {k: saida / v for k, v in C.PASTAS.items()}
    pg = pastas_do_grupo(saida, c)
    pasta["entradas"].mkdir(parents=True, exist_ok=True)
    mascara = pasta["entradas"] / "area_estudo.gpkg"
    if mascara.exists():
        anterior, _ = geo.ler_vetor_area(mascara)
        if anterior is None or anterior.geom.SymDifference(area.geom).Area() > 1e-6 * max(area.geom.Area(), 1e-12):
            raise ErroValidacao(["A área de estudo é diferente da usada nas execuções anteriores desta pasta. Use a "
                                 "mesma área ou uma pasta de resultados nova."])
    else:
        area.salvar_gpkg(mascara)
    if existe:  # só depois de todas as verificações
        _remover_cenario(saida, c, man)
        avisos.append(f"{c.chave} já existia na pasta e foi refeito.")
    destino = pg["grupo"]
    meta = {"variavel": c.var, "modelo": c.modelo, "ssp": c.ssp, "periodo": c.periodo,
            "fonte": "WorldClim v2.1" + ("" if c.historico else " CMIP6")}
    mensais: dict[int, Path] = {}
    criados: list[Path] = []
    try:
        # ------------------------------------------------------------ recorte, bandas e nomes
        if c.historico:
            for mes, f in fontes.items():
                prog(2 + 3 * mes, f"Recorte pela máscara: mês {mes}")
                orig = destino / os.path.basename(f)
                P.recortar(f, str(mascara), area.limites, orig, nbandas=1, descricao=c.nome(mes, "pt"),
                           metadados={**meta, "mes": mes, "arquivo_original": os.path.basename(f)})
                final = destino / f"{c.nome_arquivo(mes)}.tif"
                os.replace(orig, final)
                mensais[mes] = final
            etapas = ["1. recorte pela máscara de cada um dos 12 GeoTIFFs mensais originais (sem empilhar)",
                      "2. nomes padronizados"]
        else:
            with tempfile.TemporaryDirectory(prefix="adaptahorts_") as td:
                prog(2, "1. Importar o multibanda")
                fonte = P.importar_multibanda(fontes, Path(td), "imagem")
                prog(5, "2. Recorte pela máscara")
                rec = P.recortar(fonte, str(mascara), area.limites, pg["intermediario"] /
                                 f"{c.var}_{c.periodo}_{c.modelo}_{c.ssp_pasta}_recorte_12_bandas.tif")
                criados.append(rec)
            for mes in range(1, 13):
                prog(15 + 2 * mes, f"3. Separar banda {mes}")
                abrev = destino / f"{C.MESES['pt'][mes - 1]}.tif"
                P.separar_banda(rec, mes, abrev, c.nome(mes, "pt"), {**meta, "mes": mes})
                final = destino / f"{c.nome_arquivo(mes)}.tif"
                os.replace(abrev, final)
                mensais[mes] = final
            etapas = ["1. importar multibanda (12 bandas)", "2. recorte pela máscara", "3. separar 12 bandas",
                      "4. nomes padronizados"]
        criados += list(mensais.values())
        r = finalizar_grupo(saida, c, mensais, cfg, man, mascara, avisos, prog, criados)
    except BaseException:
        for f in criados:
            if Path(f).exists():
                Path(f).unlink()
        if destino.exists() and not any(destino.iterdir()):
            destino.rmdir()
        raise
    prog(97, "Tabelas gerais e manifesto")
    registrar_grupo(saida, man, c, mensais, cfg, r, etapas, avisos, criados,
                    arquivos=[os.path.basename(f) for f in lista])
    prog(100, "Concluído")
    return {"situacao": "concluído com avisos" if avisos else "concluído", "saida": str(saida), "cenario": c.chave,
            "pasta_grupo": str(destino), "avisos": avisos, "n_rasters": len(mensais), "n_txt": r["n_txt"],
            "mapas": r["mapas"], "estilo": r["estilo"], "etapas": etapas, "manifesto": man}


def finalizar_grupo(saida: Path, c: N.Cenario, mensais: dict, cfg: dict, man: dict, mascara: Path, avisos: list,
                    prog, criados: list, nota: str = "") -> dict:
    """Etapas finais de um grupo de 12 rasters já recortados: grade, simbologia, estatísticas, layouts e PNG.

    Usada pelas etapas da Fase 1, pelas variáveis derivadas e pela correção de viés (rasters corrigidos). ``nota`` entra no subtítulo e no rodapé.
    """
    pasta = {k: saida / v for k, v in C.PASTAS.items()}
    pg = pastas_do_grupo(saida, c)
    notas = man.setdefault("notas_mapas", {})   # para refazer os mapas depois (cenarios/mapas.py)
    if nota:
        notas[c.chave] = nota
    else:
        notas.pop(c.chave, None)
    primeiro = mensais[min(mensais)]
    g = P.info(primeiro)
    grade = {"geotransform": [round(x, 10) for x in g["gt"]], "largura": g["largura"], "altura": g["altura"]}
    if man.get("grade") and man["grade"] != grade:
        raise ErroValidacao(["A imagem recortada não ficou na mesma grade das execuções anteriores desta pasta "
                             "(resolução ou alinhamento diferente). Use imagens WorldClim da mesma resolução."])

    # ------------------------------------------------------------ simbologia da variável
    prog(42, "Simbologia")
    lo, hi = np.inf, -np.inf
    for f in mensais.values():
        a, _ = P.ler(f)
        if np.isfinite(a).any():
            lo, hi = min(lo, float(np.nanmin(a))), max(hi, float(np.nanmax(a)))
    if not np.isfinite(lo):
        raise ErroValidacao(["Nenhum pixel válido dentro da área de estudo. Confira se a imagem cobre a área."])
    fixo = (cfg["simbologia"] or {}).get(c.var) or {}
    antigo = man["simbologia"].get(c.var)
    if fixo.get("min") is not None and fixo.get("max") is not None:
        estilo = {"min": float(fixo["min"]), "max": float(fixo["max"]), "origem": "fixa (informada)"}
        if antigo and (antigo["min"], antigo["max"]) != (estilo["min"], estilo["max"]):
            avisos.append(f"Escala de {c.var} mudou de {antigo['min']:g}–{antigo['max']:g} para "
                          f"{estilo['min']:g}–{estilo['max']:g}; mapas anteriores desta pasta usam a escala antiga.")
    elif antigo:
        estilo = {k: antigo[k] for k in ("min", "max", "origem")}
    else:
        vmin, vmax = faixa_redonda(lo, hi)
        estilo = {"min": vmin, "max": vmax, "origem": f"mín.–máx. de {c.chave} (primeira imagem desta variável)"}
        if cfg["gerar_mapas"]:
            avisos.append(f"Escala de cores de {c.var} definida por esta imagem ({vmin:g} a {vmax:g}) e reutilizada nas "
                          f"próximas. Para comparar histórico e cenários com folga, informe uma escala fixa "
                          f"(ex.: {c.var}={vmin:g}:{vmax + (vmax - vmin) * 0.3:g}).")
    if cfg["gerar_mapas"] and (lo < estilo["min"] or hi > estilo["max"]):
        avisos.append(f"{c.chave}: valores de {lo:.1f} a {hi:.1f} saem da escala de {c.var} ({estilo['min']:g} a "
                      f"{estilo['max']:g}); as cores dos extremos ficam saturadas.")
    estilo["qml"] = cfg["qml"] or None
    man["simbologia"][c.var] = {k: estilo[k] for k in ("min", "max", "origem")}

    cart = None
    mapas = {"gerados": False, "motivo": "desativado", "n_png": 0}
    if cfg["gerar_mapas"]:
        try:
            from . import cartografia as cart
            cart.iniciar()
            if not estilo["qml"]:
                q = cart.salvar_qml(c.var, estilo["min"], estilo["max"], primeiro,
                                    pasta["simbologia"] / f"{c.var}.qml", "pt")
                criados.append(q)
            mapas = {"gerados": True, "n_png": 0, "n_projetos": 0, "dpi": cfg["dpi"]}
        except ImportError as exc:
            cart = None
            mapas = {"gerados": False, "motivo": f"PyQGIS indisponível: {exc}", "n_png": 0}
            avisos.append("Layouts, projetos e PNG não gerados: PyQGIS indisponível neste ambiente.")

    # ------------------------------------------------------------ lote de 12: estatísticas, layouts, PNG
    limites = (cfg["classes"] or {}).get(c.var) or C.VAR[c.var]["classes"]
    stats = {}
    for mes, f in mensais.items():
        a, gt = P.ler(f)
        stats[mes] = E.calcular(a, E.areas_pixel_km2(gt, a.shape), limites, C.VAR[c.var]["unidade"])
    n_txt = 0
    for k, lang in enumerate(cfg["idiomas"]):
        pt = pg["estatisticas"][lang]
        pt.mkdir(parents=True, exist_ok=True)
        linhas = []
        for mes in sorted(mensais):
            rel = str(mensais[mes].relative_to(saida))
            txt = pt / f"{c.nome_arquivo(mes)}.txt"
            txt.write_text(E.texto(stats[mes], c, mes, lang, rel, cfg["regiao"]), encoding="utf-8")
            linhas.append(E.linha_csv(stats[mes], c, mes, lang, rel))
            criados.append(txt)
            n_txt += 1
        tab = pt / f"tabela_{lang}.csv"
        _csv(tab, linhas)
        criados.append(tab)
        if cart is not None:
            base = 50 + 45 * k / len(cfg["idiomas"])
            qgz = pg["projeto"][lang]
            pngs = cart.lote(c, mensais, lang, mascara, estilo, qgz, pg["mapas"][lang],
                             int(cfg["dpi"]), cfg["regiao"], cfg["autor"], cfg["versao"], nota=nota,
                             progresso=lambda j, b=base, l=lang: prog(b + 45 / len(cfg["idiomas"]) * j / 12,
                                                                      f"Layout {j}/12 ({l})"))
            criados += pngs + [qgz]
            mapas["n_png"] += len(pngs)
            mapas["n_projetos"] += 1
    return {"grade": grade, "estilo": estilo, "n_txt": n_txt, "mapas": mapas}


def registrar_grupo(saida: Path, man: dict, c: N.Cenario, mensais: dict, cfg: dict, r: dict, etapas: list,
                    avisos: list, criados: list, arquivos: list, extra: dict | None = None) -> None:
    """Tabelas gerais e manifesto da pasta (acumulativo)."""
    grade, mapas, n_txt = r["grade"], r["mapas"], r["n_txt"]
    lista = arquivos
    for lang, nome in (("pt", "estatisticas_pt.csv"), ("en", "statistics_en.csv")):
        partes = sorted(p for p in saida.rglob(f"tabela_{lang}.csv") if not p.relative_to(saida).parts[0].startswith("_"))
        if not partes:
            continue
        todas = []
        for p in partes:
            with p.open(encoding="utf-8-sig", newline="") as fh:
                todas += list(csv.DictReader(fh))
        geral = saida / nome
        _csv(geral, todas)
        criados.append(geral)

    man["camadas"] += [{"var": c.var, "modelo": c.modelo, "ssp": c.ssp, "periodo": c.periodo, "mes": m,
                        "raster": str(f.relative_to(saida)), "nome": c.nome_arquivo(m)} for m, f in sorted(mensais.items())]
    man["camadas"].sort(key=lambda x: (x["ssp"] != "historical", x["modelo"], x["var"], x["ssp"], x["periodo"], x["mes"]))
    combos: dict = {}
    for x in man["camadas"]:
        if x["ssp"] != "historical":
            combos.setdefault((x["modelo"], x["ssp"], x["periodo"]), set()).add(x["var"])
    hist_vars = sorted({x["var"] for x in man["camadas"] if x["ssp"] == "historical"})
    agora = datetime.now(timezone.utc).isoformat()
    man["execucoes"].append({"utc": agora, "cenario": c.chave, "arquivos": lista,
                             "etapas": etapas, "avisos": avisos, "mapas": mapas, "n_txt": n_txt})
    for f in criados:
        if Path(f).exists():
            man["saidas_sha256"][str(Path(f).relative_to(saida))] = sha256(Path(f))
    man["saidas_sha256"] = {k: v for k, v in man["saidas_sha256"].items() if (saida / k).exists()}
    man.update({
        "etapa": "Cenários climáticos (Cenários MCGBrasil, Fase 1)",
        "metodo": "Fontenelle, Amorim, Cruz & Lima (2025). Revista DCS 22(83). doi:10.54899/dcs.v22i83.3456",
        "fonte_dados": {"base": "WorldClim v2.1", "referencia": "Fick & Hijmans (2017), Int. J. Climatol. 37(12): "
                        "4302–4315, doi:10.1002/joc.5086", "termos_cmip6":
                        "https://pcmdi.llnl.gov/CMIP6/TermsOfUse/TermsOfUse6-1.html"},
        "versao": cfg["versao"], "versoes_bibliotecas": _versoes(),
        "organizacao": "<var>/historico/WorldClim e <var>/<período>/<modelo>/<SSPxxx>: 12 rasters "
                       "<var>_<período>_<modelo>_<SSPxxx>_<Mês>.tif, estatisticas_pt|en, mapas_pt|en e projetos .qgz",
        "grade": grade, "crs": "EPSG:4326", "reamostragem": "nenhuma",
        "historico_variaveis": hist_vars,
        "combinacoes_futuras": [{"modelo": m, "ssp": s, "periodo": p, "variaveis": sorted(v)}
                                for (m, s, p), v in sorted(combos.items())],
        "cenarios": sorted({f"{x['var']}|{x['modelo']}|{x['ssp']}|{x['periodo']}" for x in man["camadas"]}),
        "atualizado_utc": agora,
        "nota_integridade": "SHA-256 garante integridade dos arquivos, não autoria.",
    })
    if extra:
        man.update(extra)
    (saida / MANIFESTO).write_text(json.dumps(man, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
