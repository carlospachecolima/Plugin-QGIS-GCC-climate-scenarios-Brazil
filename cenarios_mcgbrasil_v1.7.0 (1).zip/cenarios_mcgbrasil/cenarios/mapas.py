"""Mapas por último, com escala de cores única por variável.

Os layouts e PNG são gerados depois que todos os rasters da pasta existem (baixados, derivados, ensemble ou
corrigidos). A escala de cada variável vai do mínimo ao máximo, arredondados, de todos os grupos da pasta (histórico e
todas as projeções), salvo escala fixa informada pelo usuário. Assim, nenhum cenário futuro satura a paleta e todos
os mapas de uma variável são comparáveis entre si.

Um grupo só é redesenhado quando a escala da variável mudou, quando faltam PNG ou quando se pede (``forcar``).
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from . import catalogo as C
from . import manual as M
from . import nomes as N
from . import processamento as P


def faixas(saida: Path, man: dict, fixas: dict | None = None, outras: list | None = None) -> dict:
    """Escala por variável: a fixa informada ou o mín.–máx. arredondado de todos os rasters da variável.

    ``outras`` = [(pasta, manifesto), …] de outras fases do mesmo projeto (Fase 1 sem correção e Fase 2 corrigida):
    a amplitude é a maior entre todas, para que a mesma variável tenha a mesma escala em todos os mapas.
    """
    por_var: dict = {}
    for base, m in [(Path(saida), man)] + [(Path(b), m) for b, m in (outras or [])]:
        for x in m.get("camadas", []):
            if (base / x["raster"]).exists():
                por_var.setdefault(x["var"], []).append(base / x["raster"])
    out = {}
    for var, rasters in por_var.items():
        if not any(x["var"] == var for x in man.get("camadas", [])):
            continue
        f = (fixas or {}).get(var) or {}
        if f.get("min") is not None and f.get("max") is not None:
            out[var] = {"min": float(f["min"]), "max": float(f["max"]), "origem": "fixa (informada)"}
            continue
        lo, hi = np.inf, -np.inf
        for r in rasters:
            a, _ = P.ler(r)
            if np.isfinite(a).any():
                lo, hi = min(lo, float(np.nanmin(a))), max(hi, float(np.nanmax(a)))
        if np.isfinite(lo):
            vmin, vmax = M.faixa_redonda(lo, hi)
            n = len({str(r).rsplit("_", 1)[0] for r in rasters})
            out[var] = {"min": vmin, "max": vmax,
                        "origem": f"mín.–máx. de todos os {n} grupos de {var} (histórico e projeções"
                                  + (", Fases 1 e 2)" if outras else ")")}
    return out


def _grupos(saida: Path, man: dict) -> dict:
    g: dict = {}
    for x in man.get("camadas", []):
        g.setdefault((x["var"], x["modelo"], x["ssp"], x["periodo"]), {})[int(x["mes"])] = Path(saida) / x["raster"]
    return {k: v for k, v in g.items() if C.completo(k[0], v)}


def _nota_padrao(man: dict, c) -> dict | str:
    """Nota do grupo para projetos anteriores à v1.5.0, que não a guardavam: reconstruída do manifesto."""
    partes = {"pt": [], "en": []}
    if c.modelo == C.ENSEMBLE:
        membros = ((man.get("ensemble") or {}).get("grupos") or {}).get(c.chave) or []
        n = len(membros)
        lista = f" ({', '.join(membros)})" if 0 < n <= 4 else ""
        partes["pt"].append(f"Ensemble de {n} modelos CMIP6{lista}")
        partes["en"].append(f"Ensemble of {n} CMIP6 models{lista}")
    from .derivadas import NOTA
    if c.var in NOTA:
        for l in partes:
            partes[l].append(NOTA[c.var][l])
    cv = man.get("correcao_vies")
    if cv:
        n_est, (a0, a1) = len(cv.get("estacoes") or []), (cv.get("periodo") or ["?", "?"])
        partes["pt"].append(f"Corrigido pelo método Delta regional com {n_est} estação(ões) do INMET ({a0}–{a1}; "
                            "Lima et al., 2026)")
        partes["en"].append(f"Bias-corrected by the regional Delta method with {n_est} INMET station(s) ({a0}–{a1}; "
                            "Lima et al., 2026)")
    return {l: " · ".join(v) for l, v in partes.items()} if partes["pt"] else ""


def periodos_faltantes(man: dict) -> dict:
    """Por variável, o que falta para a escala cobrir do histórico a 2081–2100."""
    out = {}
    for var in {x["var"] for x in man.get("camadas", [])}:
        tem = {x["periodo"] for x in man["camadas"] if x["var"] == var}
        falta = ([] if any(x["ssp"] == C.HIST for x in man["camadas"] if x["var"] == var) else ["1970-2000"]) + \
            [p for p in C.PERIODOS if p not in tem]
        if falta:
            out[var] = falta
    return out


def gerar(saida, man: dict, cfg: dict, prog=None, cancelado=None, forcar: bool = False, outras: list | None = None) -> dict:
    """Gera (ou refaz) os layouts, projetos .qgz e PNG de todos os grupos da pasta, com escala única."""
    from . import cartografia as cart
    cart.iniciar()
    saida = Path(saida)
    mascara = saida / C.PASTAS["entradas"] / "area_estudo.gpkg"
    antigas = man.get("simbologia") or {}
    novas = faixas(saida, man, cfg.get("simbologia"), outras)
    langs = list(cfg.get("idiomas") or ["pt"])
    notas = man.get("notas_mapas") or {}
    grupos = sorted(_grupos(saida, man).items(),
                    key=lambda kv: (C.TODAS.index(kv[0][0]) if kv[0][0] in C.TODAS else 9, kv[0][2] != C.HIST, kv[0]))
    criados: list[Path] = []
    feitos = n_png = 0
    qml_feito: set = set()
    for i, ((var, modelo, ssp, periodo), mensais) in enumerate(grupos):
        if cancelado and cancelado():
            break
        if var not in novas:
            continue
        c = N.Cenario(var, modelo, ssp, periodo)
        est = novas[var]
        pg = M.pastas_do_grupo(saida, c)
        completo = all(len(list(pg["mapas"][l].glob("*.png"))) >= len(mensais) for l in langs if pg["mapas"][l].exists()) and \
            all(pg["mapas"][l].exists() for l in langs)
        mesma = (antigas.get(var) or {}).get("min") == est["min"] and (antigas.get(var) or {}).get("max") == est["max"]
        if completo and mesma and not forcar and man.get("mapas_escala_unica"):
            continue
        if var not in qml_feito:
            q = cart.salvar_qml(var, est["min"], est["max"], mensais[min(mensais)],
                                saida / C.PASTAS["simbologia"] / f"{var}.qml", "pt")
            criados.append(q)
            qml_feito.add(var)
        nota = notas.get(c.chave) or _nota_padrao(man, c)
        for k, lang in enumerate(langs):
            if prog:
                prog(100.0 * (i + k / len(langs)) / max(len(grupos), 1),
                     f"Mapas {c.chave} ({lang}) – {i + 1}/{len(grupos)}")
            pngs = cart.lote(c, mensais, lang, mascara, {**est, "qml": cfg.get("qml")}, pg["projeto"][lang],
                             pg["mapas"][lang], int(cfg.get("dpi") or 300), cfg.get("regiao", ""),
                             cfg.get("autor", ""), cfg.get("versao", ""), nota=nota)
            criados += pngs + [pg["projeto"][lang]]
            n_png += len(pngs)
        feitos += 1
    man["simbologia"] = {v: {k: e[k] for k in ("min", "max", "origem")} for v, e in novas.items()}
    man["mapas_escala_unica"] = {"utc": datetime.now(timezone.utc).isoformat(), "idiomas": langs,
                                 "dpi": int(cfg.get("dpi") or 300),
                                 "regra": "mapas gerados por último; escala por variável = mín.–máx. de todos os "
                                          "grupos da pasta, salvo escala fixa informada"}
    sha = man.setdefault("saidas_sha256", {})
    for f in criados:
        f = Path(f)
        if f.exists():
            sha[str(f.relative_to(saida))] = M.sha256(f)
    (saida / M.MANIFESTO).write_text(json.dumps(man, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    return {"grupos": feitos, "png": n_png, "escalas": novas, "faltam": periodos_faltantes(man)}
