"""Reconhecimento dos arquivos do WorldClim e nomenclatura padronizada do artigo.

3º prompt (Fontenelle et al., 2025): ``Period_SSP_climate variable (Unity)_MonthAbbrev``,
com Period = Histórico, 2021-2040, 2041-2060, 2061-2080 ou 2081-2100; SSP = Histórico,
SSP1 2.6, SSP2 4.5, SSP3 7.0 ou SSP5 8.5; MonthAbbrev = três primeiras letras do mês.
Exemplo: ``2081-2100_SSP5 8.5_Precipitação (mm)_Mar``.

O artigo usou um só modelo (ACCESS-CM2). Para vários modelos, os nomes do artigo são
mantidos e o modelo vai no nome da pasta, para que nenhum arquivo seja sobrescrito.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass

from . import catalogo as C

_FUT = re.compile(r"^wc2\.1_(?P<res>30s|2\.5m|5m|10m)_(?P<var>tmin|tmax|prec)_(?P<modelo>.+?)_"
                  r"(?P<ssp>ssp\d{3})_(?P<periodo>\d{4}-\d{4})\.tiff?$", re.I)
_HIST = re.compile(r"^wc2\.1_(?P<res>30s|2\.5m|5m|10m)_(?P<var>tmin|tmax|prec)_(?P<mes>\d{2})\.tiff?$", re.I)


@dataclass(frozen=True, order=True)
class Cenario:
    var: str
    modelo: str
    ssp: str
    periodo: str
    res: str = "30s"

    @property
    def historico(self) -> bool:
        return self.ssp == C.HIST

    # ---- rótulos do artigo
    def periodo_rotulo(self, lang: str) -> str:
        return C.HISTORICO[lang] if self.historico else self.periodo

    def ssp_rotulo(self, lang: str) -> str:
        return C.HISTORICO[lang] if self.historico else C.SSP_ARTIGO[self.ssp]

    def var_rotulo(self, lang: str) -> str:
        return f"{C.VAR[self.var][lang]} ({C.VAR[self.var]['unidade']})"

    def nome(self, mes: int, lang: str) -> str:
        """Period_SSP_climate variable (Unity)_MonthAbbrev (3º, 6º e 8º prompts)."""
        return f"{self.periodo_rotulo(lang)}_{self.ssp_rotulo(lang)}_{self.var_rotulo(lang)}_{C.MESES[lang][mes - 1]}"

    def nome_projeto(self, lang: str) -> str:
        """climate variable_period_SSP (5º prompt), ex.: precipitation_2021_2040_SSP126."""
        per = self.periodo.replace("-", "_")
        ssp = C.HISTORICO[lang] if self.historico else self.ssp.upper()
        return f"{C.VAR[self.var]['slug'][lang]}_{per}_{ssp}"

    # ---- organização em pastas: um grupo de 12 rasters por pasta
    @property
    def ssp_pasta(self) -> str:
        """ssp126 → SSP126."""
        return self.ssp.upper()

    def grupo(self) -> tuple[str, ...]:
        """<var>/historico/WorldClim ou <var>/<período>/<modelo>/<SSPxxx> (ex.: prec/2021-2040/ACCESS-CM2/SSP126)."""
        if self.historico:
            return (self.var, "historico", C.HIST_MODELO)
        return (self.var, self.periodo, self.modelo, self.ssp_pasta)

    def nome_arquivo(self, mes: int) -> str:
        """<var>_<período>_<modelo>_<SSPxxx>_<Mês> (ex.: prec_2021-2040_ACCESS-CM2_SSP126_Jan)."""
        m = C.MESES["pt"][mes - 1]
        if self.historico:
            return f"{self.var}_historico_{C.HIST_MODELO}_{m}"
        return f"{self.var}_{self.periodo}_{self.modelo}_{self.ssp_pasta}_{m}"

    # ---- pastas (seguras, sem espaços)
    @property
    def pasta_modelo(self) -> str:
        return f"{C.HIST_MODELO}_historico_{C.HIST_PERIODO}" if self.historico else self.modelo

    @property
    def pasta_cenario(self) -> str:
        return f"{self.periodo}_{'historico' if self.historico else self.ssp}"

    @property
    def chave(self) -> str:
        return f"{self.var}|{self.modelo}|{self.ssp}|{self.periodo}"

    # ---- título dos layouts (7º prompt)
    def titulo(self, mes: int, lang: str, regiao: str = "") -> str:
        T = C.TEXTO[lang]
        a, b = (C.HIST_PERIODO if self.historico else self.periodo).split("-")
        m = C.VAR[self.var].get("genero") == "m"
        tipo = T["observado" if m else "observada"] if self.historico else T["projetado" if m else "projetada"]
        var = C.VAR[self.var][lang]
        mes_ext = C.MESES_EXTENSO[lang][mes - 1]
        cen = C.HISTORICO[lang] if self.historico else C.SSP_IPCC[self.ssp]
        if lang == "pt":
            quando = mes_ext if mes == C.ANUAL else f"{T['mes_de']} {mes_ext}"
            t = f"{var} {tipo} ({a} {T['a']} {b}) – {cen} – {quando}"
        else:
            t = f"{tipo} {var.lower()} ({a} {T['a']} {b}) – {cen} – {mes_ext}"
        return t + (f" – {regiao}" if regiao else "")


def historico(var: str, res: str = "30s") -> Cenario:
    return Cenario(var, C.HIST_MODELO, C.HIST, C.HIST_PERIODO, res)


def reconhecer(nome_arquivo: str):
    """(Cenario, mês) para histórico mensal; (Cenario, None) para futuro de 12 bandas; None se desconhecido."""
    base = os.path.basename(nome_arquivo)
    m = _FUT.match(base)
    if m:
        d = m.groupdict()
        return Cenario(d["var"].lower(), d["modelo"], d["ssp"].lower(), d["periodo"], d["res"]), None
    m = _HIST.match(base)
    if m:
        d = m.groupdict()
        return historico(d["var"].lower(), d["res"]), int(d["mes"])
    return None


def varrer_pasta(pasta: str) -> tuple[dict, list[str]]:
    """Encontra os dados WorldClim (recursivo). Retorna ({Cenario: [arquivos]}, avisos).

    Futuro: 1 arquivo de 12 bandas. Histórico: 12 arquivos mensais (todos obrigatórios).
    """
    achados: dict[Cenario, list[str]] = {}
    mensais: dict[Cenario, dict[int, str]] = {}
    avisos: list[str] = []
    for raiz, _d, arqs in os.walk(pasta):
        for a in sorted(arqs):
            r = reconhecer(a)
            if r is None:
                continue
            cen, mes = r
            caminho = os.path.join(raiz, a)
            if mes is None:
                if cen in achados:
                    avisos.append(f"Arquivo repetido para {cen.chave}; usado {achados[cen][0]}.")
                    continue
                achados[cen] = [caminho]
            else:
                mensais.setdefault(cen, {}).setdefault(mes, caminho)
    for cen, meses in mensais.items():
        faltam = [m for m in range(1, 13) if m not in meses]
        if faltam:
            avisos.append(f"Histórico de {cen.var} incompleto (faltam os meses {faltam}); ignorado.")
            continue
        achados[cen] = [meses[m] for m in range(1, 13)]
    return achados, avisos


def ordem(c: Cenario):
    """Histórico primeiro; depois variável, modelo, SSP e período."""
    return (0 if c.historico else 1, c.modelo, c.var, c.ssp, c.periodo)
