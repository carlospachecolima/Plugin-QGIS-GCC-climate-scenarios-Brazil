"""Etapas 1 a 3 do artigo com GDAL: importar o multibanda, recortar pela máscara e separar as bandas.

Não altera o modo de exceções do GDAL (global, afetaria o QGIS e outros complementos):
os retornos são verificados aqui.
"""

from __future__ import annotations

import math
import os
from contextlib import contextmanager
from pathlib import Path

import numpy as np
from osgeo import gdal

NODATA = -9999.0
_CRIACAO_BASE = ["COMPRESS=DEFLATE", "TILED=YES", "BIGTIFF=IF_SAFER"]


def criacao(tipo=gdal.GDT_Float32) -> list[str]:
    """Opções de gravação GeoTIFF adequadas ao tipo do dado.

    PREDICTOR=3 (ponto flutuante) só vale para Float32/Float64; para inteiros (a precipitação do WorldClim é
    Int16) usa-se PREDICTOR=2. Aplicar o 3 a um inteiro faz o GDAL recusar a gravação.
    """
    nome = gdal.GetDataTypeName(tipo) or ""
    if nome.startswith("Float"):
        return _CRIACAO_BASE + ["PREDICTOR=3"]
    if nome.startswith(("Int", "UInt", "Byte")):
        return _CRIACAO_BASE + ["PREDICTOR=2"]
    return list(_CRIACAO_BASE)


CRIACAO = criacao(gdal.GDT_Float32)  # rasters gerados pelo complemento são sempre Float32


@contextmanager
def _config(**opcoes):
    antes = {k: gdal.GetConfigOption(k) for k in opcoes}
    for k, v in opcoes.items():
        gdal.SetConfigOption(k, v)
    try:
        yield
    finally:
        for k, v in antes.items():
            gdal.SetConfigOption(k, v)


def _abrir(caminho):
    try:
        ds = gdal.Open(str(caminho))
    except RuntimeError as exc:
        raise RuntimeError(f"não foi possível abrir {caminho}: {exc}")
    if ds is None:
        raise RuntimeError(f"não foi possível abrir {caminho}: {gdal.GetLastErrorMsg()}")
    return ds


def _chamar(funcao, oque: str, *args, **kw):
    try:
        r = funcao(*args, **kw)
    except RuntimeError as exc:
        raise RuntimeError(f"{oque}: {exc}")
    if r is None:
        raise RuntimeError(f"{oque}: {gdal.GetLastErrorMsg() or 'falha do GDAL'}")
    return r


def info(caminho) -> dict:
    ds = _abrir(caminho)
    b = ds.GetRasterBand(1)
    d = {"bandas": ds.RasterCount, "gt": ds.GetGeoTransform(), "wkt": ds.GetProjection(),
         "largura": ds.RasterXSize, "altura": ds.RasterYSize, "nodata": b.GetNoDataValue()}
    ds = None
    return d


# ----------------------------------------------------------------------------- etapa 1
def importar_multibanda(arquivos: list[str], pasta_temp: Path, nome: str) -> str:
    """1. Importar o raster multibanda com 12 bandas (uma por mês).

    Futuro: o próprio GeoTIFF do WorldClim (12 bandas). Histórico: o WorldClim publica um
    GeoTIFF por mês; eles são empilhados num VRT de 12 bandas (sem cópia dos dados).
    """
    if len(arquivos) == 1:
        fonte = arquivos[0]
    else:
        fonte = str(Path(pasta_temp) / f"{nome}.vrt")
        ds = _chamar(gdal.BuildVRT, f"empilhar {nome}", fonte, list(arquivos), separate=True)
        ds = None
    d = info(fonte)
    if d["bandas"] != 12:
        raise RuntimeError(f"{os.path.basename(arquivos[0])}: esperado 12 bandas (meses); encontradas {d['bandas']}.")
    return fonte


# ----------------------------------------------------------------------------- etapa 2
def recortar(fonte: str, mascara_gpkg: str, envelope: tuple, saida: Path, nbandas: int = 12,
             descricao: str = "", metadados: dict | None = None) -> Path:
    """Recorte espacial pela camada de máscara, preservando as bandas (12 no futuro, 1 em cada mês do histórico).

    Equivale ao ``gdal:cliprasterbymasklayer`` da Tabela 2 do artigo (CROP_TO_CUTLINE e
    KEEP_RESOLUTION): extensão da máscara ajustada à grade original, sem reamostragem,
    pixels com centro fora do polígono = NoData. A extensão é alinhada à grade de 30″ do
    WorldClim, de modo que histórico e projeções saem exatamente na mesma grade.
    """
    d = info(fonte)
    x0, dx, _, y0, _, dy = d["gt"]
    minx, miny, maxx, maxy = envelope
    eps = 1e-9
    c0 = math.floor((minx - x0) / dx + eps)
    c1 = math.ceil((maxx - x0) / dx - eps)
    r0 = math.floor((maxy - y0) / dy + eps)
    r1 = math.ceil((miny - y0) / dy - eps)
    limites = (x0 + c0 * dx, y0 + r1 * dy, x0 + c1 * dx, y0 + r0 * dy)
    saida = Path(saida)
    saida.parent.mkdir(parents=True, exist_ok=True)
    opc = gdal.WarpOptions(format="GTiff", cutlineDSName=str(mascara_gpkg), cropToCutline=False,
                           outputBounds=limites, xRes=abs(dx), yRes=abs(dy), resampleAlg="near",
                           srcNodata=d["nodata"], dstNodata=NODATA, outputType=gdal.GDT_Float32,
                           creationOptions=CRIACAO, multithread=True)
    with _config(GDAL_PAM_ENABLED="NO"):
        ds = _chamar(gdal.Warp, f"recortar {os.path.basename(fonte)}", str(saida), fonte, options=opc)
        if ds.RasterCount != nbandas:
            raise RuntimeError(f"Recorte de {fonte}: {ds.RasterCount} bandas; esperado {nbandas}.")
        if nbandas == 12:
            for i in range(12):
                ds.GetRasterBand(i + 1).SetDescription(f"{i + 1:02d}")
        else:
            ds.GetRasterBand(1).SetDescription(descricao)
            ds.SetMetadata({str(k): str(v) for k, v in (metadados or {}).items()})
            ds.GetRasterBand(1).ComputeStatistics(False)
        validos = int(np.isfinite(_ler_banda(ds.GetRasterBand(1))).sum())
        ds = None
    if validos == 0:
        raise RuntimeError(f"Recorte de {os.path.basename(fonte)}: nenhum pixel válido dentro da área de estudo.")
    return saida


# ----------------------------------------------------------------------------- etapa 3
def separar_banda(recorte: Path, banda: int, saida: Path, descricao: str, metadados: dict) -> Path:
    """3. Separar uma banda mensal num raster de banda única (mesma grade, sem reamostragem)."""
    saida = Path(saida)
    saida.parent.mkdir(parents=True, exist_ok=True)
    opc = gdal.TranslateOptions(format="GTiff", bandList=[banda], outputType=gdal.GDT_Float32,
                                creationOptions=CRIACAO)
    with _config(GDAL_PAM_ENABLED="NO"):
        ds = _chamar(gdal.Translate, f"separar banda {banda}", str(saida), str(recorte), options=opc)
        b = ds.GetRasterBand(1)
        b.SetDescription(descricao)
        b.SetNoDataValue(NODATA)
        ds.SetMetadata({str(k): str(v) for k, v in metadados.items()})
        b.ComputeStatistics(False)
        ds = None
    aux = Path(str(saida) + ".aux.xml")
    if aux.exists():
        aux.unlink()
    return saida


def _ler_banda(b) -> np.ndarray:
    nativo = b.ReadAsArray()
    a = nativo.astype("float64")
    nd = b.GetNoDataValue()
    if nd is not None and not np.isnan(nd):
        a[nativo == np.array(nd).astype(nativo.dtype)] = np.nan
    return a


def ler(caminho) -> tuple[np.ndarray, tuple]:
    """Banda 1 como float64 (NaN fora da área) e geotransform."""
    ds = _abrir(caminho)
    a = _ler_banda(ds.GetRasterBand(1))
    gt = ds.GetGeoTransform()
    ds = None
    return a, gt


# ----------------------------------------------------------------------------- download (opcional)
def existe(caminho: str) -> bool:
    if caminho.startswith("/vsi"):
        try:
            return gdal.VSIStatL(caminho) is not None
        except RuntimeError:
            return False
    return os.path.exists(caminho)


def configurar_http(opcoes: dict) -> None:
    for k, v in opcoes.items():
        gdal.SetConfigOption(k, v)


def _tipo(fonte: str):
    ds = _abrir(fonte)
    t = ds.GetRasterBand(1).DataType
    ds = None
    return t


def subconjunto(fonte: str, destino: Path, envelope: tuple, margem_graus: float = 0.05) -> Path:
    """Copia só o retângulo que envolve a área (com margem), no tipo de dado original, sem recortar pelo polígono.

    Evita baixar arquivos globais de vários GB; o recorte pela máscara fica para o C1/C2.
    """
    d = info(fonte)
    x0, dx, _, y0, _, dy = d["gt"]
    minx, miny, maxx, maxy = envelope
    minx, miny, maxx, maxy = minx - margem_graus, miny - margem_graus, maxx + margem_graus, maxy + margem_graus
    c0 = max(0, math.floor((minx - x0) / dx))
    c1 = min(d["largura"], math.ceil((maxx - x0) / dx))
    r0 = max(0, math.floor((maxy - y0) / dy))
    r1 = min(d["altura"], math.ceil((miny - y0) / dy))
    if c1 <= c0 or r1 <= r0:
        raise RuntimeError(f"{os.path.basename(fonte)}: a área de estudo está fora da imagem.")
    return _gravar_copia(fonte, destino, [c0, r0, c1 - c0, r1 - r0])


def copiar(fonte: str, destino: Path) -> Path:
    return _gravar_copia(fonte, destino, None)


def _gravar_copia(fonte: str, destino: Path, janela) -> Path:
    destino = Path(destino)
    destino.parent.mkdir(parents=True, exist_ok=True)
    parcial = destino.with_name(destino.name + ".parcial")
    opc = gdal.TranslateOptions(format="GTiff", srcWin=janela, creationOptions=criacao(_tipo(fonte)))
    try:
        with _config(GDAL_PAM_ENABLED="NO"):
            ds = _chamar(gdal.Translate, f"obter {os.path.basename(destino)}", str(parcial), fonte, options=opc)
            ds = None
        os.replace(parcial, destino)  # só vira o arquivo final se a cópia terminou
    finally:
        if parcial.exists():
            parcial.unlink()
    return destino



def gravar_como(referencia: Path, arr: np.ndarray, destino: Path, descricao: str = "", metadados: dict | None = None) -> Path:
    """Grava ``arr`` (NaN = NoData) como Float32 na mesma grade e SRC de ``referencia``."""
    ref = _abrir(referencia)
    destino = Path(destino)
    destino.parent.mkdir(parents=True, exist_ok=True)
    with _config(GDAL_PAM_ENABLED="NO"):
        ds = gdal.GetDriverByName("GTiff").Create(str(destino), ref.RasterXSize, ref.RasterYSize, 1, gdal.GDT_Float32,
                                                  options=CRIACAO)
        if ds is None:
            raise RuntimeError(f"não foi possível criar {destino}: {gdal.GetLastErrorMsg()}")
        ds.SetGeoTransform(ref.GetGeoTransform())
        ds.SetProjection(ref.GetProjection())
        b = ds.GetRasterBand(1)
        b.SetNoDataValue(NODATA)
        b.WriteArray(np.where(np.isfinite(arr), arr, NODATA).astype("float32"))
        if descricao:
            b.SetDescription(descricao)
        if metadados:
            ds.SetMetadata({str(k): str(v) for k, v in metadados.items()})
        b.ComputeStatistics(False)
        ds = None
    ref = None
    return destino
