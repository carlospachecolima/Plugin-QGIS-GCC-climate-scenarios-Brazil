"""Endereços dos arquivos do WorldClim v2.1 (histórico 1970–2000 e CMIP6), para o download opcional.

* futuro 30″ : https://geodata.ucdavis.edu/cmip6/30s/<GCM>/<ssp>/wc2.1_30s_<var>_<GCM>_<ssp>_<período>.tif
               (um GeoTIFF de 12 bandas, uma por mês)
* histórico  : https://geodata.ucdavis.edu/climate/worldclim/2_1/base/wc2.1_30s_<var>.zip
               (12 GeoTIFFs, wc2.1_30s_<var>_01.tif … _12.tif)

Os caminhos /vsicurl/ e /vsizip/ deixam o GDAL ler só os blocos que cobrem a área.
"""

from __future__ import annotations

HOST = "https://geodata.ucdavis.edu"

OPCOES_HTTP = {
    "GDAL_DISABLE_READDIR_ON_OPEN": "EMPTY_DIR",
    "CPL_VSIL_CURL_ALLOWED_EXTENSIONS": ".tif,.zip",
    "GDAL_HTTP_MULTIRANGE": "YES",
    "GDAL_HTTP_MERGE_CONSECUTIVE_RANGES": "YES",
    "VSI_CACHE": "TRUE",
    "GDAL_HTTP_MAX_RETRY": "4",
    "GDAL_HTTP_RETRY_DELAY": "2",
    "GDAL_HTTP_TIMEOUT": "120",
}


def nome_futuro(var: str, modelo: str, ssp: str, periodo: str, res: str = "30s") -> str:
    return f"wc2.1_{res}_{var}_{modelo}_{ssp}_{periodo}.tif"


def urls_futuro(var: str, modelo: str, ssp: str, periodo: str, res: str = "30s") -> list[str]:
    nome = nome_futuro(var, modelo, ssp, periodo, res)
    return [f"{HOST}/cmip6/{res}/{modelo}/{ssp}/{nome}",
            f"{HOST}/climate/worldclim/2_1/cmip6/{res}/{modelo}/{ssp}/{nome}"]


def fontes_futuro(var: str, modelo: str, ssp: str, periodo: str, res: str = "30s") -> list[str]:
    """Caminhos GDAL (/vsicurl/) candidatos; o primeiro que existir é usado."""
    return ["/vsicurl/" + u for u in urls_futuro(var, modelo, ssp, periodo, res)]


def nome_historico(var: str, mes: int, res: str = "30s") -> str:
    return f"wc2.1_{res}_{var}_{mes:02d}.tif"


def url_zip_historico(var: str, res: str = "30s") -> str:
    return f"{HOST}/climate/worldclim/2_1/base/wc2.1_{res}_{var}.zip"


def vsi_historico(var: str, mes: int, res: str = "30s") -> str:
    return f"/vsizip//vsicurl/{url_zip_historico(var, res)}/{nome_historico(var, mes, res)}"


def vsi_elevacao(res: str = "30s") -> str:
    """Elevação (m) usada pelo próprio WorldClim v2.1 na interpolação (derivada do SRTM), na mesma grade de 30″."""
    return f"/vsizip//vsicurl/{HOST}/climate/worldclim/2_1/base/wc2.1_{res}_elev.zip/wc2.1_{res}_elev.tif"
