"""Funções comuns (geometria, leitura de rasters, layouts) usadas pelas fases do Cenários MCGBrasil."""
__version__ = "1.2.2"
