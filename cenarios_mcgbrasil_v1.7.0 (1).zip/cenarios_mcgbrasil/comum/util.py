"""Utilitários: hash, CSV, progresso com cancelamento e versões do ambiente."""

from __future__ import annotations

import csv
import hashlib
import platform
from pathlib import Path

import numpy as np

from .config import Cancelado


def sha256(path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for bloco in iter(lambda: f.read(1024 * 1024), b""):
            h.update(bloco)
    return h.hexdigest()


def _csv(caminho: Path, linhas: list[dict]) -> None:
    campos: list[str] = []
    for l in linhas:
        for k in l:
            if k not in campos:
                campos.append(k)

    def fmt(v):
        if v is None:
            return ""
        if isinstance(v, bool):
            return "True" if v else "False"
        if isinstance(v, float):
            return "" if not np.isfinite(v) else f"{v:.6f}"
        return v

    Path(caminho).parent.mkdir(parents=True, exist_ok=True)
    with Path(caminho).open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=campos, lineterminator="\n")
        w.writeheader()
        for l in linhas:
            w.writerow({k: fmt(l.get(k)) for k in campos})


def _versoes() -> dict:
    from osgeo import gdal
    v = {"python": platform.python_version(), "numpy": np.__version__, "gdal": gdal.__version__}
    try:
        from qgis.core import Qgis
        v["qgis"] = Qgis.QGIS_VERSION
    except Exception:  # noqa: BLE001
        v["qgis"] = None
    return v


class _Progresso:
    """Encaminha progresso (0–100) e verifica cancelamento entre etapas."""

    def __init__(self, progresso=None, cancelado=None, ini: float = 0.0, fim: float = 100.0):
        self._p, self._c, self._ini, self._fim = progresso, cancelado, ini, fim

    def __call__(self, pct: float, msg: str = "") -> None:
        if self._c is not None and self._c():
            raise Cancelado("Processamento cancelado pelo usuário.")
        if self._p is not None:
            v = self._ini + (self._fim - self._ini) * max(0.0, min(100.0, float(pct))) / 100.0
            self._p(v, msg)

    def faixa(self, ini: float, fim: float) -> "_Progresso":
        a = self._ini + (self._fim - self._ini) * ini / 100.0
        b = self._ini + (self._fim - self._ini) * fim / 100.0
        return _Progresso(self._p, self._c, a, b)
