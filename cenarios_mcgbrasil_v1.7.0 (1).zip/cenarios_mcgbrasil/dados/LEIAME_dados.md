# Dados de referência embutidos

| Arquivo | Conteúdo | Fonte | Licença |
|---|---|---|---|
| `municipios_ibge.csv` | 5.571 municípios: código IBGE, nome, UF e coordenadas da sede | IBGE, via [kelvins/municipios-brasileiros](https://github.com/kelvins/municipios-brasileiros) | MIT (© 2016 Kelvin S. do Prado) |
| `ufs_ibge.gpkg` | Limites das 27 UFs (SIRGAS 2000), obtidos pela dissolução da malha municipal do IBGE e simplificados com tolerância de 0,005° (~500 m) | IBGE, via [tbrugz/geodata-br](https://github.com/tbrugz/geodata-br) | CC0 1.0 (domínio público) |

Usos: localizar um município pelo nome e atribuir a UF de cada estação do INMET (o cabeçalho do BDMEP não traz a UF).
Estações a até ~500 m de uma divisa ou no mar recebem a UF do polígono mais próximo; a Ilha da Trindade (A650) é
atribuída ao ES por regra explícita.

## Normais climatológicas do INMET

- `normais_inmet.csv` e `estacoes_normais.csv`: Normais Climatológicas do Brasil 1961–1990, 1981–2010 e 1991–2020
  (INMET, https://portal.inmet.gov.br/servicos/normais-climatológicas), de Tmax, Tmin, temperatura média compensada,
  precipitação acumulada e evapotranspiração potencial (esta só em 1981–2010 e 1991–2020), por estação e mês, com as
  coordenadas das listas de estações das três normais. Montados pela ferramenta `montar_normais.py` a partir das
  planilhas oficiais, sem alterar os valores ("-" = sem dado). Dados públicos do INMET; cite a fonte.

## Banco mensal do INMET (BDMEP)

- `bdmep/bdmep_mensal_convencionais.zip` (565 estações) e `bdmep/bdmep_mensal_automaticas.zip` (598 estações):
  séries mensais exportadas do Banco de Dados Meteorológicos do INMET (BDMEP, https://bdmep.inmet.gov.br) em
  6/11/2026, de 1970 a 2020, com Tmax, Tmin, temperatura média compensada, precipitação, evapotranspiração potencial
  e real do balanço hídrico, evaporação, insolação, umidade, nebulosidade, vento e pressão. Arquivos CSV originais,
  sem alteração, só reempacotados. Usados pela Fase 2 (correção de viés) quando o usuário não informa outro banco.
  Dados públicos do INMET; cite a fonte.
