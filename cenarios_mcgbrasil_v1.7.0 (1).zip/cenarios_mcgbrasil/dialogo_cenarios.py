"""Tela de seleção da Fase 1: variáveis, períodos, cenários e modelos, com aviso das combinações sem dados."""

from __future__ import annotations

from pathlib import Path

from qgis.core import QgsProcessingFeedback, QgsSettings
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (QCheckBox, QDialog, QFileDialog, QFrame, QGridLayout, QGroupBox, QHBoxLayout, QLabel,
                                 QLineEdit, QMessageBox, QPlainTextEdit, QProgressBar, QPushButton, QScrollArea, QSpinBox,
                                 QToolButton, QVBoxLayout, QWidget)

from . import projeto as PJ
from .algoritmos_cenarios import SIGLA, rotulo_ausencias
from .base import NOME, PROVEDOR_ID
from .cenarios import catalogo as C
from .idioma import IDIOMA, T

L = "en" if IDIOMA == "en" else "pt"
CHAVE = "mcgbrasil/pasta_projeto"
VAR_CURTO = {
    "tmin": "Tmin", "tmax": "Tmax",
    "tmed": T("Tmed (cálculo da média entre Tmin e Tmax)", "Tmean (mean of Tmin and Tmax)"),
    "prec": "Prec",
    "etp": T("Evapotranspiração (método de Thornthwaite)", "Evapotranspiration (Thornthwaite method)"),
    "ia": T("Índice de aridez (P/ETP, mensal e anual)", "Aridity index (P/PET, monthly and annual)"),
    "pci": T("PCI – concentração de chuvas (anual)", "PCI – rainfall concentration (annual)"),
    "isc": T("ISC – severidade de chuvas (anual)", "ISC – rainfall severity (annual)"),
}


class _Feedback(QgsProcessingFeedback):
    """Encaminha o registro e o progresso do algoritmo para a própria tela."""

    def __init__(self, log: QPlainTextEdit, barra: QProgressBar, rotulo: QLabel):
        super().__init__()
        self.log, self.barra, self.rotulo = log, barra, rotulo
        self.progressChanged.connect(lambda p: self.barra.setValue(int(p)))

    def setProgressText(self, texto):  # noqa: N802
        super().setProgressText(texto)
        self.rotulo.setText(texto)

    def pushInfo(self, texto):  # noqa: N802
        super().pushInfo(texto)
        self.log.appendPlainText(texto)

    def pushWarning(self, texto):  # noqa: N802
        super().pushWarning(texto)
        self.log.appendPlainText("⚠ " + texto)

    def reportError(self, texto, fatal=False):  # noqa: N802
        super().reportError(texto, fatal)
        self.log.appendPlainText("✖ " + texto)


class DialogoCenarios(QDialog):
    def __init__(self, parent=None, pasta: str = ""):
        super().__init__(parent)
        self.setWindowTitle(f"{NOME} – " + T("Fase 1: elaborar cenários climáticos", "Phase 1: build climate scenarios"))
        self.feedback = None
        externo = QVBoxLayout(self)
        rolagem = QScrollArea()
        rolagem.setWidgetResizable(True)
        rolagem.setFrameShape(QFrame.Shape.NoFrame)
        rolagem.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        interno = QWidget()
        lay = QVBoxLayout(interno)
        rolagem.setWidget(interno)
        externo.addWidget(rolagem, 1)

        # ------------------------------------------------------------ escolhas (como no desenho)
        self.cb_var = self._linha(lay, T("Marque quais variáveis você pretende avaliar.",
                                         "Tick the variables you want to assess."),
                                  [(v, VAR_CURTO[v]) for v in C.TODAS], marcados=C.TODAS, colunas=2)
        self.cb_hist = QCheckBox(T("Histórico 1970–2000 (necessário para a correção de viés e para os índices)",
                                   "Historical 1970–2000 (needed for bias correction and for the indices)"))
        self.cb_hist.setChecked(True)
        self.cb_per = self._linha(lay, T("Quais os períodos quer avaliar?", "Which periods do you want to assess?"),
                                  [(p, p) for p in C.PERIODOS], marcados=C.PERIODOS, extra=self.cb_hist)
        self.cb_ssp = self._linha(lay, T("Com quais cenários você trabalhará?", "Which scenarios will you work with?"),
                                  [(s, C.SSP_ARTIGO[s]) for s in C.SSPS], marcados=C.SSPS)

        lay.addWidget(self._titulo(T("Quais os modelos serão utilizados?", "Which models will be used?")))
        grade = QGridLayout()
        self.cb_mod = {}
        for i, m in enumerate(C.MODELOS):
            cb = QCheckBox(m)
            cb.setChecked(True)
            cb.toggled.connect(self.atualizar)
            self.cb_mod[m] = cb
            grade.addWidget(cb, i // 5, i % 5)
        lay.addLayout(grade)
        botoes = QHBoxLayout()
        for texto, val in ((T("Todos", "All"), True), (T("Nenhum", "None"), False)):
            b = QPushButton(texto)
            b.clicked.connect(lambda _=False, v=val: self._todos_modelos(v))
            botoes.addWidget(b)
        botoes.addStretch(1)
        lay.addLayout(botoes)

        # ------------------------------------------------------------ ensemble de modelos
        self.gb_ens = QGroupBox(T("Gerar ensemble de modelos (média dos modelos marcados)",
                                  "Build model ensemble (mean of the selected models)"))
        self.gb_ens.setCheckable(True)
        self.gb_ens.setChecked(False)
        self.gb_ens.toggled.connect(self.atualizar)
        ge = QGridLayout(self.gb_ens)
        self.cb_ens = {}
        for i, m in enumerate(C.MODELOS):
            cb = QCheckBox(m)
            cb.setChecked(True)
            cb.toggled.connect(self.atualizar)
            self.cb_ens[m] = cb
            ge.addWidget(cb, i // 5, i % 5)
        be = QHBoxLayout()
        for texto, modo in ((T("Mesmos do download", "Same as download"), "download"), (T("Todos", "All"), True),
                            (T("Nenhum", "None"), False)):
            b = QPushButton(texto)
            b.clicked.connect(lambda _=False, v=modo: self._ensemble_modelos(v))
            be.addWidget(b)
        be.addStretch(1)
        ge.addLayout(be, 3, 0, 1, 5)
        lay.addWidget(self.gb_ens)

        # ------------------------------------------------------------ aviso de disponibilidade
        self.aviso = QLabel()
        self.aviso.setWordWrap(True)
        self.aviso.setTextFormat(Qt.TextFormat.RichText)
        self.aviso.setFrameShape(QFrame.Shape.StyledPanel)
        self.aviso.setStyleSheet("padding: 6px;")
        self.aviso.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)
        rol = QScrollArea()
        rol.setWidgetResizable(True)
        rol.setWidget(self.aviso)
        rol.setMinimumHeight(170)
        lay.addWidget(rol)

        # ------------------------------------------------------------ área, projeto e saídas
        caixa = QGroupBox(T("Área, pasta do projeto e mapas", "Area, project folder and maps"))
        g = QGridLayout(caixa)
        from qgis.gui import QgsMapLayerComboBox
        self.area = QgsMapLayerComboBox()
        try:
            from qgis.core import Qgis
            self.area.setFilters(Qgis.LayerFilter.PolygonLayer)
        except (AttributeError, TypeError):
            from qgis.core import QgsMapLayerProxyModel
            self.area.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        self.area.setAllowEmptyLayer(True)
        try:
            self.area.setAllowEmptyLayer(True, T("(usar a área já gravada no projeto)",
                                                 "(use the area already saved in the project)"))
        except TypeError:
            pass
        g.addWidget(QLabel(T("Área de estudo (polígono)", "Study area (polygon)")), 0, 0)
        g.addWidget(self.area, 0, 1, 1, 2)
        self.ed_pasta = QLineEdit(pasta or QgsSettings().value(CHAVE, "", type=str))
        b = QToolButton()
        b.setText("…")
        b.clicked.connect(self._escolher_pasta)
        g.addWidget(QLabel(T("Pasta do projeto", "Project folder")), 1, 0)
        g.addWidget(self.ed_pasta, 1, 1)
        g.addWidget(b, 1, 2)
        self.ed_regiao = QLineEdit()
        self.ed_regiao.setPlaceholderText(T("ex.: Baixo São Francisco", "e.g., Lower São Francisco"))
        g.addWidget(QLabel(T("Região (títulos)", "Region (titles)")), 2, 0)
        g.addWidget(self.ed_regiao, 2, 1, 1, 2)
        linha = QHBoxLayout()
        self.cb_pt = QCheckBox("Português")
        self.cb_en = QCheckBox("English")
        self.cb_pt.setChecked(True)
        self.cb_en.setChecked(True)
        self.cb_mapas = QCheckBox(T("Gerar layouts e PNG", "Create layouts and PNG"))
        self.cb_mapas.setChecked(True)
        self.dpi = QSpinBox()
        self.dpi.setRange(150, 1200)
        self.dpi.setValue(300)
        self.dpi.setSuffix(" dpi")
        for w in (self.cb_pt, self.cb_en, self.cb_mapas, self.dpi):
            linha.addWidget(w)
        linha.addStretch(1)
        g.addWidget(QLabel(T("Relatórios e mapas", "Reports and maps")), 3, 0)
        g.addLayout(linha, 3, 1, 1, 2)
        self.ed_escalas = QLineEdit()
        self.ed_escalas.setPlaceholderText(T("Escalas de cores fixas (opcional): tmin=10:30; tmax=20:42; prec=0:400; "
                                             "etp=0:200", "Fixed color scales (optional): tmin=10:30; tmax=20:42; "
                                             "prec=0:400; etp=0:200"))
        g.addWidget(QLabel(T("Escalas", "Scales")), 4, 0)
        g.addWidget(self.ed_escalas, 4, 1, 1, 2)
        lay.addWidget(caixa)

        # ------------------------------------------------------------ execução
        self.rotulo = QLabel()
        self.barra = QProgressBar()
        self.barra.setRange(0, 100)
        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setMaximumBlockCount(5000)
        lay.addWidget(self.rotulo)
        lay.addWidget(self.barra)
        lay.addWidget(self.log, 1)
        for w in (self.rotulo, self.barra, self.log):
            w.setVisible(False)
        fim = QHBoxLayout()
        fim.addStretch(1)
        self.b_exec = QPushButton(T("Executar", "Run"))
        self.b_exec.setDefault(True)
        self.b_exec.clicked.connect(self.executar)
        self.b_cancel = QPushButton(T("Cancelar", "Cancel"))
        self.b_cancel.setEnabled(False)
        self.b_cancel.clicked.connect(self._cancelar)
        b_fechar = QPushButton(T("Fechar", "Close"))
        b_fechar.clicked.connect(self.close)
        for w in (self.b_exec, self.b_cancel, b_fechar):
            fim.addWidget(w)
        externo.addLayout(fim)
        tela = self.screen().availableGeometry() if hasattr(self, "screen") and self.screen() else None
        self.resize(1040, min(1000, int(tela.height() * 0.9)) if tela else 900)
        self.atualizar()

    # ------------------------------------------------------------------ montagem
    @staticmethod
    def _titulo(texto: str) -> QLabel:
        r = QLabel(f"<b>{texto}</b>")
        r.setStyleSheet("margin-top: 6px;")
        return r

    def _linha(self, lay, titulo, itens, marcados=(), extra: QWidget | None = None, colunas: int = 0) -> dict:
        lay.addWidget(self._titulo(titulo))
        h = QGridLayout() if colunas else QHBoxLayout()
        out = {}
        if extra is not None:
            extra.toggled.connect(self.atualizar)
        for i, (chave, texto) in enumerate(itens):
            cb = QCheckBox(texto)
            cb.setChecked(chave in marcados)
            cb.toggled.connect(self.atualizar)
            out[chave] = cb
            if colunas:
                h.addWidget(cb, i // colunas, i % colunas)
            else:
                h.addWidget(cb)
        if not colunas:
            h.addStretch(1)
        lay.addLayout(h)
        if extra is not None:
            lay.addWidget(extra)
        return out

    def _todos_modelos(self, valor: bool):
        for cb in self.cb_mod.values():
            cb.blockSignals(True)
            cb.setChecked(valor)
            cb.blockSignals(False)
        self.atualizar()

    def _ensemble_modelos(self, modo):
        for m, cb in self.cb_ens.items():
            cb.blockSignals(True)
            cb.setChecked(self.cb_mod[m].isChecked() if modo == "download" else modo)
            cb.blockSignals(False)
        self.atualizar()

    def _escolher_pasta(self):
        p = QFileDialog.getExistingDirectory(self, T("Pasta do projeto", "Project folder"), self.ed_pasta.text())
        if p:
            self.ed_pasta.setText(p)

    # ------------------------------------------------------------------ seleção e disponibilidade
    def escolhas(self) -> dict:
        sel = lambda d: [k for k, cb in d.items() if cb.isChecked()]  # noqa: E731
        return {"variaveis": sel(self.cb_var), "periodos": sel(self.cb_per), "ssps": sel(self.cb_ssp),
                "modelos": sel(self.cb_mod), "historico": self.cb_hist.isChecked(),
                "ensemble": self.gb_ens.isChecked(), "modelos_ensemble": sel(self.cb_ens)}

    def atualizar(self):
        e = self.escolhas()
        partes = []
        base = C.base_necessaria(e["variaveis"])
        extra = [v for v in base if v not in e["variaveis"]]
        if extra:
            nomes = " e ".join(SIGLA[L][v] for v in extra) if L == "pt" else " and ".join(SIGLA[L][v] for v in extra)
            partes.append("ℹ " + T(f"{nomes} também será(ão) baixada(s) e mapeada(s), pois Tmed e ETP são calculadas "
                                   "a partir de Tmin e Tmax.", f"{nomes} will also be downloaded and mapped, because "
                                   "Tmean and PET are computed from Tmin and Tmax."))
        ok, faltas = C.plano(e["variaveis"], e["modelos"], e["ssps"], e["periodos"])
        n_fut = sum(1 for v in base for m in e["modelos"] for s in e["ssps"] for _ in e["periodos"]
                    if C.disponivel(m, s, v))
        n_hist = len(base) * 12 if e["historico"] else 0
        if not e["variaveis"]:
            partes.append("<span style='color:#cf222e'>" + T("Marque ao menos uma variável.",
                                                             "Tick at least one variable.") + "</span>")
        elif not e["historico"] and not ok:
            partes.append("<span style='color:#cf222e'>" + T("Marque o histórico ou ao menos um período, um cenário e "
                                                             "um modelo.", "Tick the historical data or at least one "
                                                             "period, scenario and model.") + "</span>")
        if faltas:
            itens = "".join(f"<li>{t}</li>" for t in rotulo_ausencias(faltas, L))
            partes.append("<span style='color:#9a6700'><b>⚠ " + T("Sem dados no WorldClim para:", "No WorldClim data "
                          "for:") + f"</b></span><ul style='margin:2px 0 2px 16px'>{itens}</ul>"
                          + T("Essas combinações serão puladas; as demais seguem normalmente.",
                              "These combinations will be skipped; the others run normally."))
        elif e["modelos"] and e["ssps"] and e["periodos"]:
            partes.append("<span style='color:#1a7f37'>✔ " + T("Todas as combinações escolhidas têm dados no WorldClim.",
                          "Every selected combination has WorldClim data.") + "</span>")
        if e["ensemble"]:
            partes.append(self._aviso_ensemble(e))
        partes.append(T(f"A baixar: {n_hist} arquivos mensais do histórico e {n_fut} imagens CMIP6 de 12 bandas "
                        f"({len(ok)} combinações de modelo × cenário × período).",
                        f"To download: {n_hist} monthly historical files and {n_fut} 12-band CMIP6 images "
                        f"({len(ok)} model × scenario × period combinations)."))
        self.aviso.setText("<br>".join(partes))
        ens_ok = not e["ensemble"] or len(e["modelos_ensemble"]) >= 2
        self.b_exec.setEnabled(bool(e["variaveis"]) and (e["historico"] or bool(ok)) and ens_ok and self.feedback is None)

    def _aviso_ensemble(self, e) -> str:
        """Quantos modelos entram no ensemble em cada cenário e quais ficam de fora."""
        me = e["modelos_ensemble"]
        if len(me) < 2:
            return "<span style='color:#cf222e'>" + T("Ensemble: marque ao menos dois modelos.",
                                                      "Ensemble: tick at least two models.") + "</span>"
        linhas = []
        fora_download = [m for m in me if m not in e["modelos"]]
        if fora_download:
            linhas.append(T(f"{', '.join(fora_download)} não será(ão) baixado(s) agora; entra(m) no ensemble só se já "
                            "estiver(em) no projeto.", f"{', '.join(fora_download)} will not be downloaded now; "
                            "used in the ensemble only if already in the project."))
        for s in e["ssps"]:
            com = {v: [m for m in me if m in e["modelos"] and C.disponivel(m, s, v)] for v in e["variaveis"]}
            ns = sorted({len(x) for x in com.values()})
            sem = sorted({m for v in e["variaveis"] for m in me if m in e["modelos"] and not C.disponivel(m, s, v)})
            n = (f"{ns[0]}–{ns[-1]}" if ns[0] != ns[-1] else str(ns[0])) if ns else "0"
            cor = "#cf222e" if ns and ns[0] < 2 else "#1a7f37"
            txt = T(f"{C.SSP_ARTIGO[s]}: {n} modelo(s)", f"{C.SSP_ARTIGO[s]}: {n} model(s)")
            if sem:
                txt += T(f" (sem dados: {', '.join(sem)})", f" (no data: {', '.join(sem)})")
            linhas.append(f"<span style='color:{cor}'>{txt}</span>")
        return ("<b>" + T(f"Ensemble de {len(me)} modelo(s) marcado(s):", f"Ensemble of {len(me)} selected "
                          "model(s):") + "</b><ul style='margin:2px 0 2px 16px'>"
                + "".join(f"<li>{x}</li>" for x in linhas) + "</ul>")

    # ------------------------------------------------------------------ execução
    def parametros(self) -> dict:
        e = self.escolhas()
        lyr = self.area.currentLayer()
        return {"VARIAVEIS": [C.TODAS.index(v) for v in e["variaveis"]],
                "PERIODOS": [C.PERIODOS.index(p) for p in e["periodos"]],
                "SSPS": [C.SSPS.index(s) for s in e["ssps"]],
                "MODELOS": [C.MODELOS.index(m) for m in e["modelos"]],
                "HISTORICO": e["historico"], "ENSEMBLE": e["ensemble"],
                "MODELOS_ENSEMBLE": [C.MODELOS.index(m) for m in e["modelos_ensemble"]], "AREA": lyr if lyr is not None else None,
                "PASTA": self.ed_pasta.text().strip(), "REGIAO": self.ed_regiao.text().strip(),
                "IDIOMAS": [i for i, cb in enumerate((self.cb_pt, self.cb_en)) if cb.isChecked()] or [0],
                "GERAR_MAPAS": self.cb_mapas.isChecked(), "DPI": self.dpi.value(),
                "ESCALAS": self.ed_escalas.text().strip()}

    def executar(self):
        import processing
        p = self.parametros()
        if not p["PASTA"]:
            QMessageBox.warning(self, NOME, T("Escolha a pasta do projeto.", "Choose the project folder."))
            return
        if p["AREA"] is None and PJ.area_do_projeto(p["PASTA"]) is None:
            QMessageBox.warning(self, NOME, T("Escolha a área de estudo (o projeto ainda não tem uma).",
                                              "Choose the study area (the project does not have one yet)."))
            return
        Path(p["PASTA"]).mkdir(parents=True, exist_ok=True)
        QgsSettings().setValue(CHAVE, p["PASTA"])
        self.log.clear()
        for w in (self.rotulo, self.barra, self.log):
            w.setVisible(True)
        self.feedback = _Feedback(self.log, self.barra, self.rotulo)
        self.b_exec.setEnabled(False)
        self.b_cancel.setEnabled(True)
        try:
            r = processing.run(f"{PROVEDOR_ID}:elaborar_cenarios", p, feedback=self.feedback)
            QMessageBox.information(self, NOME, T(
                f"Concluído.\n{r['N_PROCESSADOS']} grupos de 12 rasters mapeados, {r['N_DERIVADOS']} de Tmed/ETP, "
                f"{r['N_ENSEMBLE']} do ensemble, "
                f"{r['N_PNG']} PNG; {r['N_AUSENTES']} combinação(ões) sem dados no WorldClim.\n{r['PASTA']}",
                f"Done.\n{r['N_PROCESSADOS']} groups of 12 rasters mapped, {r['N_DERIVADOS']} of Tmean/PET, "
                f"{r['N_ENSEMBLE']} ensemble, "
                f"{r['N_PNG']} PNG; {r['N_AUSENTES']} combination(s) with no WorldClim data.\n{r['PASTA']}"))
        except Exception as exc:  # noqa: BLE001
            self.log.appendPlainText("✖ " + str(exc))
            QMessageBox.critical(self, NOME, str(exc))
        finally:
            self.feedback = None
            self.b_cancel.setEnabled(False)
            self.atualizar()

    def _cancelar(self):
        if self.feedback is not None:
            self.feedback.cancel()
            self.rotulo.setText(T("Cancelando…", "Canceling…"))
