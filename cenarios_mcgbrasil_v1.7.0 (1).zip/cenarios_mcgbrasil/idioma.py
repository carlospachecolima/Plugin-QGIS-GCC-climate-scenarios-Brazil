"""Idioma da interface deste pacote. O script de empacotamento grava "pt" (Cenários MCGBrasil) ou
"en" (MCGBrasil Climate Scenarios); o código é o mesmo nas duas versões."""
IDIOMA = "pt"


def T(pt: str, en: str) -> str:
    """Texto da interface no idioma deste pacote."""
    return en if IDIOMA == "en" else pt
