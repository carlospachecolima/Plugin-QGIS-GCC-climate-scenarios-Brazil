"""Painel lateral do Cenários MCGBrasil: pasta do projeto, situação de cada fase e um botão por etapa."""

from __future__ import annotations

from pathlib import Path

from qgis.core import QgsSettings
from qgis.PyQt.QtCore import Qt, QUrl
from qgis.PyQt.QtGui import QDesktopServices
from qgis.PyQt.QtWidgets import (QDockWidget, QFileDialog, QFrame, QGroupBox, QHBoxLayout, QLabel, QLineEdit,
                                 QPushButton, QScrollArea, QSizePolicy, QToolButton, QVBoxLayout, QWidget)

from . import projeto as PJ
from .base import NOME, PROVEDOR_ID
from .idioma import T

CHAVE = "mcgbrasil/pasta_projeto"
TELA = "tela"   # etapa que abre a tela de seleção (não um formulário do Processamento)

# fase -> [(rótulo, id do algoritmo, parâmetro que recebe a pasta do projeto)]
ETAPAS = {
    1: [(T("1.1 Elaborar cenários (tela de seleção)", "1.1 Build scenarios (selection screen)"), TELA, None),
        (T("1.2 Histórico com arquivo já baixado", "1.2 Historical from a downloaded file"),
         f"{PROVEDOR_ID}:cenario_historico", "SAIDA"),
        (T("1.3 Projeção com imagem já baixada", "1.3 Projection from a downloaded image"),
         f"{PROVEDOR_ID}:cenario_futuro", "SAIDA"),
        (T("1.4 Calcular Tmed e ETP", "1.4 Compute Tmean and PET"), f"{PROVEDOR_ID}:calcular_derivadas", "PASTA"),
        (T("1.5 Ensemble de modelos", "1.5 Model ensemble"), f"{PROVEDOR_ID}:ensemble_modelos", "PASTA"),
        (T("1.6 Refazer os mapas (escala única)", "1.6 Redo maps (single scale)"), f"{PROVEDOR_ID}:refazer_mapas", "PASTA")],
    2: [(T("2.1 Delta e correlação (INMET)", "2.1 Delta and correlation (INMET)"),
         f"{PROVEDOR_ID}:vies_delta_inmet", "SAIDA")],
    3: [(T("3.1 Taxas das normais × projetadas", "3.1 Normals × projected rates"),
         f"{PROVEDOR_ID}:tendencia_normais", "PROJETO")],
    4: [(T("4.1 Correlação WorldClim × Eta × INMET", "4.1 WorldClim × Eta × INMET correlation"), None, None)],
}
ESTADOS = {"opcional": T("Opcional", "Optional"), "concluída": T("Concluída", "Done"), "em andamento": T("Em andamento", "In progress"),
           "pendente": T("Pendente", "Pending"), "em desenvolvimento": T("Em desenvolvimento", "Under development")}
CORES = {"opcional": "#57606a", "concluída": "#1a7f37", "em andamento": "#9a6700", "pendente": "#57606a", "em desenvolvimento": "#8250df"}
SIMBOLO = {"opcional": "◇", "concluída": "✔", "em andamento": "◐", "pendente": "○", "em desenvolvimento": "⚙"}


class PainelFases(QDockWidget):
    def __init__(self, iface, parent=None):
        super().__init__(f"{NOME} – " + T("fluxo por fases", "phase workflow"), parent)
        self.iface = iface
        self.setObjectName("MCGBrasilPainelFases")
        self.setAllowedAreas(Qt.DockWidgetArea.LeftDockWidgetArea | Qt.DockWidgetArea.RightDockWidgetArea)
        corpo = QWidget()
        lay = QVBoxLayout(corpo)
        lay.setContentsMargins(8, 8, 8, 8)
        lay.setSpacing(8)

        intro = QLabel(T("Siga as fases em ordem, com <b>a mesma pasta do projeto</b>; cada fase grava na sua subpasta. "
                         "Na Fase 2, informe o <b>.zip</b> que você fez da pasta <i>1_cenarios_climaticos</i>.",
                         "Follow the phases in order, with <b>the same project folder</b>; each phase writes to its own "
                         "subfolder. In Phase 2, give the <b>.zip</b> you made of the <i>1_cenarios_climaticos</i> folder."))
        intro.setWordWrap(True)
        lay.addWidget(intro)

        linha = QHBoxLayout()
        self.ed_pasta = QLineEdit()
        self.ed_pasta.setPlaceholderText(T("Pasta do projeto", "Project folder"))
        self.ed_pasta.setText(QgsSettings().value(CHAVE, "", type=str))
        self.ed_pasta.editingFinished.connect(self._mudou_pasta)
        self.ed_pasta.setMinimumWidth(80)
        linha.addWidget(self.ed_pasta, 1)
        b = QToolButton()
        b.setText("…")
        b.setToolTip(T("Escolher ou criar a pasta do projeto", "Choose or create the project folder"))
        b.clicked.connect(self._escolher)
        linha.addWidget(b)
        lay.addLayout(linha)
        linha2 = QHBoxLayout()
        for texto, fn in ((T("Abrir pasta", "Open folder"), self._abrir_pasta), (T("Atualizar", "Refresh"), self.atualizar)):
            bt = QPushButton(texto)
            bt.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Fixed)
            bt.clicked.connect(fn)
            linha2.addWidget(bt)
        lay.addLayout(linha2)

        self.caixas = {}
        for f in PJ.FASES:
            self.caixas[f["n"]] = self._caixa_fase(f, lay)
        lay.addStretch(1)
        rodape = QLabel(T("Para o risco climático das hortaliças, use o complemento AdaptaHorts com esta mesma pasta "
                          "do projeto.", "For vegetable climate risk, use the AdaptaHorts plugin with this same "
                          "project folder."))
        rodape.setWordWrap(True)
        rodape.setStyleSheet("color: #57606a;")
        lay.addWidget(rodape)

        rolagem = QScrollArea()
        rolagem.setWidgetResizable(True)
        rolagem.setFrameShape(QFrame.Shape.NoFrame)
        rolagem.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        rolagem.setWidget(corpo)
        self.setWidget(rolagem)
        self.atualizar()

    # ------------------------------------------------------------------ montagem
    def _caixa_fase(self, f: dict, lay) -> dict:
        box = QGroupBox(T("Fase", "Phase") + f" {f['n']}" + (T(" (opcional)", " (optional)") if f.get("opcional") else ""))
        v = QVBoxLayout(box)
        v.setSpacing(4)
        tit = QLabel(f"<b>{f['titulo']}</b>")
        tit.setWordWrap(True)
        v.addWidget(tit)
        estado = QLabel()
        estado.setWordWrap(True)
        estado.setTextFormat(Qt.TextFormat.RichText)
        v.addWidget(estado)
        desc = QLabel(f"{f['descricao']}<br><span style='color:#57606a'>" + T("Dados", "Data") + f": {f['dados']}<br>"
                      + T("Método", "Method") + f": <a href='{f['doi']}'>{f['artigo']}</a></span>")
        desc.setWordWrap(True)
        desc.setTextFormat(Qt.TextFormat.RichText)
        desc.setOpenExternalLinks(True)
        v.addWidget(desc)
        botoes = []
        for rot, alg, par in ETAPAS[f["n"]]:
            bt = QPushButton(rot)
            bt.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Fixed)  # encolhe com o painel
            bt.setStyleSheet("text-align: left; padding: 4px 8px;")
            if alg:
                bt.clicked.connect(lambda _=False, a=alg, p=par: self._executar(a, p))
            botoes.append((bt, alg))
            v.addWidget(bt)
        extra = QHBoxLayout()
        b_pasta = QPushButton(T("Abrir resultados", "Open results"))
        b_rel = QPushButton(T("Abrir relatório", "Open report"))
        for bx in (b_pasta, b_rel):
            bx.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Fixed)
        extra.addWidget(b_pasta)
        extra.addWidget(b_rel)
        v.addLayout(extra)
        lay.addWidget(box)
        return {"box": box, "estado": estado, "botoes": botoes, "b_pasta": b_pasta, "b_rel": b_rel}

    # ------------------------------------------------------------------ ações
    def pasta(self) -> Path | None:
        t = self.ed_pasta.text().strip()
        return Path(t) if t else None

    def _mudou_pasta(self):
        QgsSettings().setValue(CHAVE, self.ed_pasta.text().strip())
        self.atualizar()

    def _escolher(self):
        p = QFileDialog.getExistingDirectory(self, T("Pasta do projeto", "Project folder"), self.ed_pasta.text().strip())
        if p:
            self.ed_pasta.setText(p)
            self._mudou_pasta()

    def _abrir_pasta(self):
        p = self.pasta()
        if p and p.exists():
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(p)))

    def _executar(self, alg_id: str, par: str):
        import processing
        p = self.pasta()
        if p is None:
            self._escolher()
            p = self.pasta()
            if p is None:
                return
        p.mkdir(parents=True, exist_ok=True)
        if alg_id == TELA:
            from .dialogo_cenarios import DialogoCenarios
            DialogoCenarios(self.iface.mainWindow() if self.iface else self, str(p)).exec()
        else:
            # Fase 2: o usuário escolhe o .zip da Fase 1; a saída sugerida é a subpasta da Fase 2 do projeto
            valor = PJ.pasta_fase(p, 2) if par == "SAIDA" else p
            processing.execAlgorithmDialog(alg_id, {par: str(valor)})
        self.atualizar()

    def atualizar(self):
        p = self.pasta()
        st = PJ.status(p)
        for d in st:
            c = self.caixas[d["n"]]
            cor = CORES[d["estado"]]
            c["estado"].setText(f"<b style='color:{cor}'>{SIMBOLO[d['estado']]} {ESTADOS[d['estado']]}</b>"
                                + (f" — {d['resumo']}" if d["resumo"] else ""))
            liberada = PJ.pode_iniciar(st, d["n"]) and p is not None
            for bt, alg in c["botoes"]:
                bt.setEnabled(bool(alg) and liberada)
                if not alg:
                    bt.setToolTip(T("Em desenvolvimento: ", "Under development: ") + PJ.fase(d["n"])["dados"])
                elif not liberada:
                    bt.setToolTip(T("Conclua antes a fase anterior.", "Finish the previous phase first.") if p else
                                  T("Escolha a pasta do projeto.", "Choose the project folder."))
                else:
                    bt.setToolTip(bt.text())
            pf = d.get("pasta")
            c["b_pasta"].setEnabled(bool(pf and Path(pf).exists()))
            self._ligar(c["b_pasta"], pf)
            c["b_rel"].setVisible(d["n"] in (2, 3))
            c["b_rel"].setEnabled(bool(d.get("relatorio")))
            self._ligar(c["b_rel"], d.get("relatorio"))

    @staticmethod
    def _ligar(botao, alvo):
        try:
            botao.clicked.disconnect()
        except (TypeError, RuntimeError):
            pass
        if alvo:
            botao.clicked.connect(lambda _=False, a=str(alvo): QDesktopServices.openUrl(QUrl.fromLocalFile(a)))
