"""Integração com a interface do QGIS: provedor de Processamento, tela de seleção, painel por fases e menu."""

from __future__ import annotations

from qgis.core import QgsApplication, QgsSettings
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QMenu, QMessageBox

from . import projeto as PJ
from .base import ICONE, NOME, PROVEDOR_ID, VERSAO_COMPLEMENTO
from .idioma import T
from .painel import CHAVE, ETAPAS, TELA
from .provedor import ProvedorMCGBrasil

AVISO = T("Os cenários são projeções de modelos, com incertezas; use o conjunto de modelos e confira os resultados "
          "com dados locais antes de apoiar decisões. Os autores e a Embrapa não se responsabilizam pelo uso dos "
          "resultados.", "Scenarios are model projections and carry uncertainty; use the model ensemble and check the "
          "results against local data before supporting decisions. The authors and Embrapa are not responsible for "
          "how the results are used.")


class MCGBrasilPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.provedor = None
        self.menu = None
        self.painel = None
        self.acao_painel = None
        self.acao_tela = None

    def initProcessing(self):  # noqa: N802
        self.provedor = ProvedorMCGBrasil()
        QgsApplication.processingRegistry().addProvider(self.provedor)

    def initGui(self):  # noqa: N802
        self.initProcessing()
        janela = self.iface.mainWindow()
        self.menu = QMenu(NOME, janela)
        self.menu.setIcon(QIcon(ICONE))
        self.acao_painel = QAction(QIcon(ICONE), T("Painel do fluxo por fases", "Phase workflow panel"), janela)
        self.acao_painel.setCheckable(True)
        self.acao_painel.triggered.connect(self._alternar_painel)
        self.menu.addAction(self.acao_painel)
        self.acao_tela = QAction(QIcon(ICONE), T("Elaborar cenários climáticos…", "Build climate scenarios…"), janela)
        self.acao_tela.triggered.connect(lambda: self._abrir(TELA, None))
        self.menu.addAction(self.acao_tela)
        self.menu.addSeparator()
        for f in PJ.FASES:
            titulo = T("Fase", "Phase") + f" {f['n']} – {f['titulo']}"
            if f.get("opcional"):
                titulo += T(" (opcional)", " (optional)")
            if not f["pronta"]:
                titulo += T(" (em desenvolvimento)", " (under development)")
            sub = self.menu.addMenu(titulo)
            for texto, alg, par in ETAPAS[f["n"]]:
                a = sub.addAction(texto + ("…" if alg else ""))
                if alg:
                    a.triggered.connect(lambda _=False, al=alg, p=par: self._abrir(al, p))
                else:
                    a.setEnabled(False)
        self.menu.addSeparator()
        self.menu.addAction(T("Sobre e aviso de responsabilidade", "About and disclaimer"), self._sobre)
        self.iface.pluginMenu().addMenu(self.menu)
        self.iface.addToolBarIcon(self.acao_painel)

    def unload(self):
        if self.painel is not None:
            self.iface.removeDockWidget(self.painel)
            self.painel.deleteLater()
            self.painel = None
        if self.acao_painel is not None:
            self.iface.removeToolBarIcon(self.acao_painel)
        if self.menu is not None:
            self.iface.pluginMenu().removeAction(self.menu.menuAction())
            self.menu.deleteLater()
            self.menu = None
        if self.provedor is not None:
            QgsApplication.processingRegistry().removeProvider(self.provedor)
            self.provedor = None

    def _alternar_painel(self, ligado: bool) -> None:
        if self.painel is None:
            from .painel import PainelFases
            self.painel = PainelFases(self.iface, self.iface.mainWindow())
            self.painel.visibilityChanged.connect(self.acao_painel.setChecked)
            self.iface.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.painel)
        self.painel.setVisible(ligado)
        if ligado:
            self.painel.atualizar()

    def _abrir(self, alg_id: str, par: str | None) -> None:
        pasta = QgsSettings().value(CHAVE, "", type=str)
        if alg_id == TELA:
            from .dialogo_cenarios import DialogoCenarios
            DialogoCenarios(self.iface.mainWindow(), pasta).exec()
        else:
            import processing
            processing.execAlgorithmDialog(alg_id, {par: pasta} if (par and pasta) else {})
        if self.painel is not None:
            self.painel.atualizar()

    def _sobre(self) -> None:
        fases = "".join(f"<li><b>{T('Fase', 'Phase')} {f['n']} – {f['titulo']}</b>"
                        f"{T(' (opcional)', ' (optional)') if f.get('opcional') else ''}"
                        f"{'' if f['pronta'] else T(' (em desenvolvimento)', ' (under development)')}: "
                        f"{f['descricao']} <i>{f['artigo']}</i>.</li>" for f in PJ.FASES)
        texto = (f"<p><b>{NOME} v{VERSAO_COMPLEMENTO}</b> – " + T(
            "cenários climáticos dos Modelos de Circulação Geral (CMIP6) para o Brasil, Embrapa Hortaliças.",
            "climate scenarios from General Circulation Models (CMIP6) for Brazil, Embrapa Vegetables.")
            + "</p><ol>" + fases + "</ol><p><b>" + T("Responsabilidade.", "Disclaimer.") + f"</b> {AVISO}</p>"
            + f"<p style='color:#57606a'>Processing: {PROVEDOR_ID}</p>")
        QMessageBox.information(self.iface.mainWindow(), f"{NOME} v{VERSAO_COMPLEMENTO}", texto)
