"""Pasta do projeto Cenários MCGBrasil organizada por fases (sem dependência do QGIS).

<projeto>/
    projeto_mcgbrasil.json
    1_cenarios_climaticos/   Fase 1 – Cenários climáticos (Fontenelle et al., 2025)          – subcomplemento 1
    2_correcao_delta/        Fase 2 – Correção de viés pelo método Delta (Lima et al., 2026)  – subcomplemento 2
    3_tendencia_normais/     Fase 3 – Avaliação de tendência com as normais do INMET          – subcomplemento 3
    4_comparacao_eta/        Fase 4 – Comparação WorldClim × Eta-HadGEM2-ES históricos        – subcomplemento 4

Cada fase lê a anterior dentro do mesmo projeto. Pastas de cenários de versões anteriores (com o
manifesto_cenarios.json na raiz) continuam aceitas como pasta da Fase 1.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from .idioma import IDIOMA, T

ORDEM = ("tmin", "tmax", "tmed", "prec", "etp")
SIGLA = {"tmin": "Tmin", "tmax": "Tmax", "tmed": T("Tmed", "Tmean"), "prec": "Prec", "etp": T("ETP", "PET")}


def _criterio(txt: str) -> str:
    if IDIOMA != "en":
        return txt
    for a, b in (("mesma UF", "same state"), (" ou ", " or "), (" e ", " and "), ("até ", "within "), ("somente ", "only ")):
        txt = txt.replace(a, b)
    return txt

MARCADOR = "projeto_mcgbrasil.json"
MARCADORES = (MARCADOR, "projeto_adaptahorts.json")   # aceita projetos da versão AdaptaHorts 0.12
MANIFESTO_CENARIOS = "manifesto_cenarios.json"
DOI_DCS = "https://doi.org/10.54899/dcs.v22i83.3456"
DOI_LDD = "https://doi.org/10.1002/ldr.70808"

FASES = [
    {"n": 1, "pasta": "1_cenarios_climaticos", "titulo": T("Cenários climáticos", "Climate scenarios"),
     "titulo_en": "Climate scenarios",
     "artigo": "Fontenelle et al. (2025), Revista DCS", "doi": DOI_DCS,
     "descricao": T("WorldClim v2.1 (30″) recortado pela área: histórico 1970–2000 e projeções CMIP6 (14 modelos, "
                    "SSP1 2.6 a SSP5 8.5, 2021–2100) de Tmin, Tmax, Tmed, Prec e ETP (Thornthwaite), com "
                    "estatísticas, layouts e PNG em português e inglês.",
                    "WorldClim v2.1 (30″) clipped to the area: 1970–2000 historical data and CMIP6 projections "
                    "(14 models, SSP1 2.6 to SSP5 8.5, 2021–2100) of Tmin, Tmax, Tmean, Prec and PET "
                    "(Thornthwaite), with statistics, layouts and PNG in Portuguese and English."),
     "dados": T("WorldClim v2.1 (baixado pelo complemento ou arquivos já baixados)",
               "WorldClim v2.1 (downloaded by the plugin or files already downloaded)"), "pronta": True},
    {"n": 2, "pasta": "2_correcao_delta", "titulo": T("Correção de viés pelo método Delta", "Delta-method bias correction"),
     "titulo_en": "Delta-method bias correction",
     "artigo": T("Lima et al. (2026), Land Degrad. Dev., seção 2.6", "Lima et al. (2026), Land Degrad. Dev., section 2.6"), "doi": DOI_LDD,
     "descricao": T("Seleção automática das estações do INMET (mesma UF e/ou raio), médias regionais 1970–2000, "
                    "delta mensal e r de Pearson de Tmin, Tmax e Prec; aplicação do delta a todos os cenários da "
                    "Fase 1 (Tmed e ETP recalculadas).",
                    "Automatic selection of INMET stations (same state and/or radius), 1970–2000 regional means, "
                    "monthly delta and Pearson r of Tmin, Tmax and Prec; delta applied to every Phase 1 scenario "
                    "(Tmean and PET recomputed)."),
     "dados": T(".zip dos rasters da Fase 1 (compactado pelo usuário) e banco mensal BDMEP/INMET (incluído no "
               "complemento: 565 estações convencionais e 598 automáticas, 1970–2020)", ".zip of the Phase 1 rasters "
               "(compressed by the user) and INMET BDMEP monthly database (bundled with the plugin: 565 conventional "
               "and 598 automatic stations, 1970–2020)"), "pronta": True},
    {"n": 3, "pasta": "3_tendencia_normais", "titulo": T("Avaliação de tendência do cenário", "Scenario trend assessment"),
     "titulo_en": "Scenario trend assessment",
     "artigo": T("Lima et al. (2026), Land Degrad. Dev., seção 2.7", "Lima et al. (2026), Land Degrad. Dev., section 2.7"), "doi": DOI_LDD,
     "descricao": T("Taxas de aumento ou diminuição por ano de Tmax, Tmin, Tmed, Prec e ETP nas normais do INMET "
                    "(1961–1990 → 1991–2020) comparadas às taxas projetadas 2021–2100 de cada modelo e SSP.",
                    "Yearly rates of increase or decrease of Tmax, Tmin, Tmean, Prec and PET in the INMET normals "
                    "(1961–1990 → 1991–2020) compared with the 2021–2100 projected rates of each model and SSP."),
     "dados": T("Normais climatológicas do INMET 1961–1990, 1981–2010 e 1991–2020 (incluídas no complemento)",
               "INMET climatological normals 1961–1990, 1981–2010 and 1991–2020 (bundled with the plugin)"),
     "pronta": True},
    {"n": 4, "pasta": "4_comparacao_eta", "titulo": T("Comparação WorldClim × Eta histórico", "WorldClim × historical Eta comparison"),
     "titulo_en": "WorldClim × Eta historical comparison",
     "artigo": T("Lima et al. (2026), Land Degrad. Dev., seção 2.8", "Lima et al. (2026), Land Degrad. Dev., section 2.8"), "doi": DOI_LDD,
     "descricao": T("Correlação de Pearson entre as médias mensais do Eta-HadGEM2-ES histórico, do WorldClim e das "
                    "estações do INMET na área.",
                    "Pearson correlation among the monthly means of historical Eta-HadGEM2-ES, WorldClim and the "
                    "INMET stations in the area."),
     "dados": T("Rasters mensais históricos do Eta-HadGEM2-ES para o Brasil",
               "Historical monthly Eta-HadGEM2-ES rasters for Brazil"), "pronta": False, "opcional": True},
]


def fase(n: int) -> dict:
    return FASES[n - 1]


def eh_legado(pasta: Path) -> bool:
    """Pasta de cenários de versão anterior (manifesto na raiz, sem o marcador de projeto)."""
    pasta = Path(pasta)
    return (pasta / MANIFESTO_CENARIOS).exists() and not any((pasta / m).exists() for m in MARCADORES)


def raiz(pasta) -> Path:
    """Raiz do projeto a partir da raiz ou de uma subpasta de fase."""
    pasta = Path(pasta).resolve()
    for f in FASES:
        if pasta.name == f["pasta"] and any((pasta.parent / m).exists() for m in MARCADORES):
            return pasta.parent
    return pasta


def pasta_fase(projeto, n: int) -> Path:
    projeto = Path(projeto)
    if n == 1 and eh_legado(projeto):
        return projeto
    return raiz(projeto) / fase(n)["pasta"]


def registrar(projeto, **info) -> Path:
    """Cria ou atualiza o marcador do projeto (não para pastas de versões anteriores)."""
    projeto = raiz(projeto)
    projeto.mkdir(parents=True, exist_ok=True)
    antigo = projeto / MARCADORES[1]
    p = projeto / MARCADOR
    fonte = p if p.exists() else (antigo if antigo.exists() else None)
    dados = json.loads(fonte.read_text(encoding="utf-8")) if fonte else {
        "tipo": "projeto Cenários MCGBrasil", "criado_utc": datetime.now(timezone.utc).isoformat(),
        "fases": {f["n"]: f["pasta"] for f in FASES}}
    dados.update({k: v for k, v in info.items() if v not in (None, "")})
    dados["atualizado_utc"] = datetime.now(timezone.utc).isoformat()
    p.write_text(json.dumps(dados, ensure_ascii=False, indent=2), encoding="utf-8")
    return p


def saida_fase1(pasta) -> Path:
    """Pasta onde a Fase 1 grava (a própria pasta, se for de versão anterior)."""
    pasta = Path(pasta).resolve()
    if eh_legado(pasta):
        return pasta
    if pasta.name == fase(1)["pasta"]:
        return pasta
    registrar(pasta)
    return pasta / fase(1)["pasta"]


def saida_fase2(pasta) -> Path:
    pasta = Path(pasta).resolve()
    if eh_legado(pasta):  # pasta antiga de cenários: a corrigida fica ao lado
        return pasta.parent / f"{pasta.name}_{fase(2)['pasta']}"
    registrar(pasta)
    return raiz(pasta) / fase(2)["pasta"]


def area_do_projeto(pasta) -> Path | None:
    a = pasta_fase(pasta, 1) / "entradas" / "area_estudo.gpkg"
    return a if a.exists() else None


def _manifesto(p: Path) -> dict | None:
    m = p / MANIFESTO_CENARIOS
    if not m.exists():
        return None
    try:
        return json.loads(m.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def cenarios_do_projeto(pasta, preferir_corrigido: bool = True) -> tuple[Path, str]:
    """Pasta de cenários a usar nos índices: a corrigida (Fase 2), se existir, senão a da Fase 1.

    Aceita também a própria pasta de uma fase ou uma pasta de cenários de versão anterior.
    Retorna (pasta, origem) com origem em {"fase2", "fase1", "pasta"}.
    """
    pasta = Path(pasta).resolve()
    if _manifesto(pasta) is not None:
        return pasta, "pasta"
    if preferir_corrigido and _manifesto(pasta_fase(pasta, 2)) is not None:
        return pasta_fase(pasta, 2), "fase2"
    if _manifesto(pasta_fase(pasta, 1)) is not None:
        return pasta_fase(pasta, 1), "fase1"
    return pasta, "pasta"


def status(pasta) -> list[dict]:
    """Situação de cada fase para o painel: estado, resumo e se a fase seguinte pode começar."""
    pasta = Path(pasta).resolve() if pasta else None
    out = []
    for f in FASES:
        d = {"n": f["n"], "estado": "pendente", "resumo": "", "pasta": None, "relatorio": None}
        if not f["pronta"]:
            d.update(estado="em desenvolvimento", resumo=T("Aguarda: ", "Awaiting: ") + f"{f['dados']}.")
            out.append(d)
            continue
        if pasta is None or not pasta.exists():
            d["resumo"] = T("Escolha a pasta do projeto.", "Choose the project folder.")
            out.append(d)
            continue
        p = pasta_fase(pasta, f["n"])
        d["pasta"] = p
        m = _manifesto(p)
        if f["n"] == 1:
            if m:
                hist = [v for v in ORDEM if v in m.get("historico_variaveis", [])]
                comb = m.get("combinacoes_futuras", [])
                n_png = sum(len(list(p.rglob(f"mapas_{l}/*.png"))) for l in ("pt", "en"))
                completo = set(hist) >= {"tmin", "tmax", "prec"}
                d.update(estado="concluída" if completo else "em andamento",
                         resumo=(T("Histórico: ", "Historical: ") + f"{', '.join(SIGLA[v] for v in hist) or '—'}" + ("" if completo else T(" (faltam ", " (missing ")
                                 + ", ".join(sorted({'tmin', 'tmax', 'prec'} - set(hist))) + ")")
                                 + T(" · projeções: ", " · projections: ") + f"{len(comb)} · {len(m.get('camadas', []))} rasters"
                                 + f" · {n_png} PNG"))
            else:
                d["resumo"] = T("Comece pela etapa 1.1 (Elaborar cenários).", "Start with step 1.1 (Build scenarios).")
        elif f["n"] == 2:
            tab = p / "correcao_vies" / "correcao_vies.json"
            if tab.exists():
                try:
                    cv = json.loads(tab.read_text(encoding="utf-8"))
                    r = "; ".join(f"{v} r={a['pearson']:.3f}" for v, a in cv["ajustes"].items()
                                  if a.get("pearson") is not None)
                    sufixo = (T(" · cenários corrigidos", " · corrected scenarios") if m else
                              T(" · só tabelas (delta não aplicado)", " · tables only (delta not applied)"))
                    d.update(estado="concluída", resumo=f"{len(cv.get('estacoes', []))} "
                             + T("estações INMET", "INMET stations") + f" ({_criterio(cv.get('criterio', ''))}) · {r}" + sufixo)
                    rel = p / "correcao_vies" / T("relatorio_correcao_vies_pt.md", "relatorio_correcao_vies_en.md")
                    rel = rel if rel.exists() else p / "correcao_vies" / "relatorio_correcao_vies_pt.md"
                    d["relatorio"] = rel if rel.exists() else None
                except (OSError, ValueError, KeyError):
                    d.update(estado="em andamento", resumo=T("Resultados incompletos; rode de novo com Refazer.", "Incomplete results; run again with Redo."))
            else:
                f1 = out[0]
                d["resumo"] = (T("Pronta para começar.", "Ready to start.") if f1["estado"] == "concluída" else
                               T("Requer a Fase 1 com o histórico de tmin, tmax e prec.", "Needs Phase 1 with the tmin, tmax and prec historical data."))
        if f["n"] == 3:
            tj = p / "tendencia.json"
            if tj.exists():
                try:
                    tv = json.loads(tj.read_text(encoding="utf-8"))
                    ob = tv.get("observadas", {})
                    txt = "; ".join(f"{SIGLA[v]} {o['taxa_ano']:+.3f}" for v, o in ob.items()
                                    if o.get("taxa_ano") is not None)
                    d.update(estado="concluída", resumo=f"{len(tv.get('estacoes', []))} "
                             + T("estações · taxas/ano: ", "stations · rates/yr: ") + txt
                             + (T(f" · {len(tv.get('projetadas', []))} taxas projetadas",
                                  f" · {len(tv.get('projetadas', []))} projected rates") if tv.get("projetadas") else ""))
                    rel = p / T("relatorio_tendencia_pt.md", "relatorio_tendencia_en.md")
                    d["relatorio"] = rel if rel.exists() else None
                except (OSError, ValueError, KeyError, TypeError):
                    d.update(estado="em andamento", resumo=T("Resultados incompletos; rode de novo com Refazer.",
                                                             "Incomplete results; run again with Redo."))
            else:
                d["resumo"] = T("Pronta: usa as normais incluídas; com a Fase 1, compara com as projeções.",
                                "Ready: uses the bundled normals; with Phase 1, compares with the projections.")
        out.append(d)
    return out


def pode_iniciar(st: list[dict], n: int) -> bool:
    if not fase(n)["pronta"]:
        return False
    if n in (1, 3):
        return True
    return st[0]["estado"] == "concluída"


def ler_marcador(pasta) -> dict:
    p = next((raiz(pasta) / m for m in MARCADORES if (raiz(pasta) / m).exists()), None)
    try:
        return json.loads(p.read_text(encoding="utf-8")) if p else {}
    except (OSError, ValueError):
        return {}


def limpar_fase(pasta_da_fase: Path, n: int) -> None:
    """Apaga a pasta de uma fase para refazê-la (só se for mesmo a pasta dessa fase)."""
    import shutil
    pasta_da_fase = Path(pasta_da_fase)
    nome_ok = pasta_da_fase.name == fase(n)["pasta"] or pasta_da_fase.name.endswith("_" + fase(n)["pasta"])
    if not nome_ok:
        raise ValueError(f"{pasta_da_fase} não é a pasta da Fase {n}.")
    shutil.rmtree(pasta_da_fase)
