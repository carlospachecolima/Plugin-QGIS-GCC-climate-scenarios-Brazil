from __future__ import annotations

from qgis.core import QgsProcessingProvider
from qgis.PyQt.QtGui import QIcon

from .algoritmos_cenarios import AlgCenarioFuturo, AlgCenarioHistorico, AlgDerivadas, AlgElaborar, AlgEnsemble, AlgMapas
from .algoritmos_tendencia import AlgTendencia
from .algoritmos_vies import AlgDeltaINMET
from .base import ICONE, NOME, PROVEDOR_ID, VERSAO_COMPLEMENTO


class ProvedorMCGBrasil(QgsProcessingProvider):
    def id(self):
        return PROVEDOR_ID

    def name(self):
        return NOME

    def longName(self):  # noqa: N802
        return f"{NOME} (v{VERSAO_COMPLEMENTO})"

    def icon(self):
        return QIcon(ICONE)

    def versionInfo(self):  # noqa: N802
        return VERSAO_COMPLEMENTO

    def loadAlgorithms(self):  # noqa: N802
        for alg in (AlgElaborar(), AlgCenarioHistorico(), AlgCenarioFuturo(), AlgDerivadas(), AlgEnsemble(), AlgMapas(), AlgDeltaINMET(), AlgTendencia()):
            self.addAlgorithm(alg)
