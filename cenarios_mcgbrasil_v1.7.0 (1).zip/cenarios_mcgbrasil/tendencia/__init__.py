"""Fase 3 – avaliação de tendência com as normais climatológicas do INMET."""
