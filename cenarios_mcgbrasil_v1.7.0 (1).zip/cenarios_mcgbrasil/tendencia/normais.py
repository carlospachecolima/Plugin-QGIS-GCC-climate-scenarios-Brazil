"""Fase 3 – Avaliação de tendência do cenário com as normais climatológicas do INMET (Lima et al., 2026, seção 2.7).

Banco: normais oficiais do INMET 1961–1990, 1981–2010 e 1991–2020 (dados/normais_inmet.csv e
dados/estacoes_normais.csv, montados das planilhas do portal do INMET). A ETP não tem normal 1961–1990.

Taxa de aumento ou diminuição, em unidades da variável por ano, do último ano em relação ao primeiro ano da série:

    taxa = (valor do último período − valor do primeiro período) / (último ano do último período −
                                                                     primeiro ano do primeiro período)

Normais: 1961–1990 → 1991–2020 = 59 anos (ETP: 1981–2010 → 1991–2020 = 39 anos). Projeções CMIP6: 2021–2040 →
2081–2100 = 79 anos (ou os períodos escolhidos). Calculada mês a mês e para o ano (média das 12 temperaturas;
soma de precipitação e ETP). As taxas observadas e projetadas são comparadas pela razão e pelo r de Pearson entre
as 12 taxas mensais.

Médias regionais: média das normais das estações selecionadas. Por padrão só entram, em cada mês, as estações com
normal no primeiro e no último período (pareadas), para que a taxa não mude por troca de estações.
"""

from __future__ import annotations

import csv
import json
import math
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from ..cenarios import catalogo as C
from ..cenarios import processamento as P
from ..comum import geo
from ..comum.config import ErroValidacao
from ..comum.util import _Progresso, _versoes
from ..vies import banco as B
from ..vies import selecao as S

DADOS = Path(__file__).resolve().parent.parent / "dados"
PERIODOS = {"1961-1990": (1961, 1990), "1981-2010": (1981, 2010), "1991-2020": (1991, 2020)}
VARIAVEIS = ("tmax", "tmin", "tmed", "prec", "etp")
SOMA = {"prec", "etp"}
TMED_TX = "tmed_tx"   # (Tmax + Tmin)/2 das normais, comparável à Tmed dos rasters
TMED_FONTES = {"media_tmax_tmin": TMED_TX, "compensada": "tmed"}
UNID = {"tmax": "°C", "tmin": "°C", "tmed": "°C", "prec": "mm", "etp": "mm"}
NOME = {"pt": {"tmax": "Tmax", "tmin": "Tmin", "tmed": "Tmed", "prec": "Prec", "etp": "ETP"},
        "en": {"tmax": "Tmax", "tmin": "Tmin", "tmed": "Tmean", "prec": "Prec", "etp": "PET"}}
MESES = {"pt": ("Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"),
         "en": ("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")}
METODO = "Lima et al. (2026), Land Degradation & Development, doi:10.1002/ldr.70808, seção 2.7"
FONTE = "INMET – Normais Climatológicas do Brasil 1961–1990, 1981–2010 e 1991–2020"
PASTA = "3_tendencia_normais"


# ----------------------------------------------------------------------------- banco
def _f(t: str):
    t = (t or "").strip()
    return float(t) if t else None


def carregar() -> list[B.Estacao]:
    """Estações com normais (Estacao.normais[var][período] = 12 valores ou None)."""
    est = {}
    with (DADOS / "estacoes_normais.csv").open(encoding="utf-8") as fh:
        for r in csv.DictReader(fh):
            e = B.Estacao(r["codigo"], r["nome"], float(r["latitude"]), float(r["longitude"]), _f(r["altitude"]),
                          "", "", "", "INMET normais", r["uf"])
            e.normais = {}
            est[e.codigo] = e
    with (DADOS / "normais_inmet.csv").open(encoding="utf-8") as fh:
        for r in csv.DictReader(fh):
            e = est.get(r["codigo"])
            if e is None:
                continue
            vals = [_f(r[f"m{m:02d}"]) for m in range(1, 13)]
            e.normais.setdefault(r["var"], {})[r["periodo"]] = vals
            a0 = PERIODOS[r["periodo"]][0]
            for m, v in enumerate(vals, start=1):   # para a seleção (meses com dado por variável)
                if v is not None:
                    e.dados.setdefault(r["var"], {})[(a0, m)] = v
    for e in est.values():   # Tmed como no raster: (Tmax + Tmin)/2 das normais do mesmo período
        tx, tn = e.normais.get("tmax", {}), e.normais.get("tmin", {})
        for per in set(tx) & set(tn):
            e.normais.setdefault(TMED_TX, {})[per] = [None if a is None or b is None else (a + b) / 2
                                                       for a, b in zip(tx[per], tn[per])]
    return list(est.values())


def anual(vals: list, var: str):
    if any(v is None for v in vals):
        return None
    return float(sum(vals)) if var in SOMA else float(np.mean(vals))


def taxa(v0, v1, anos: int):
    if v0 is None or v1 is None or anos <= 0:
        return None
    return (v1 - v0) / anos


def pearson(a: list, b: list):
    x = np.array([np.nan if v is None else v for v in a], float)
    y = np.array([np.nan if v is None else v for v in b], float)
    ok = np.isfinite(x) & np.isfinite(y)
    if ok.sum() < 3 or x[ok].std() == 0 or y[ok].std() == 0:
        return None
    return float(np.corrcoef(x[ok], y[ok])[0, 1])


def periodos_extremos(estacoes: list, var: str) -> tuple[str, str] | None:
    pers = sorted({p for e in estacoes for p in e.normais.get(var, {})})
    return (pers[0], pers[-1]) if len(pers) >= 2 else None


def _regional_par(estacoes: list, var: str, pareadas: bool, p0: str, p1: str) -> dict:
    anos = PERIODOS[p1][1] - PERIODOS[p0][0]
    out = {"periodo_inicial": p0, "periodo_final": p1, "anos": anos, "normais": {}, "n": {}}
    for per in sorted(PERIODOS):
        meses, n = [], []
        for m in range(12):
            vs = []
            for e in estacoes:
                d = e.normais.get(var, {})
                v = (d.get(per) or [None] * 12)[m]
                if v is None:
                    continue
                if pareadas and per in (p0, p1) and any((d.get(q) or [None] * 12)[m] is None for q in (p0, p1)):
                    continue
                vs.append(v)
            meses.append(float(np.mean(vs)) if vs else None)
            n.append(len(vs))
        if any(v is not None for v in meses):
            out["normais"][per] = meses
            out["n"][per] = n
    v0, v1 = out["normais"].get(p0), out["normais"].get(p1)
    out["completo"] = bool(v0 and v1 and all(x is not None for x in v0 + v1))
    out["meses_ok"] = sum(1 for a, b in zip(v0 or [], v1 or []) if a is not None and b is not None)
    if v0 and v1:
        out["taxa"] = [taxa(a, b, anos) for a, b in zip(v0, v1)]
        out["taxa_ano"] = taxa(anual(v0, var), anual(v1, var), anos)
    return out


def regional(estacoes: list, var: str, pareadas: bool) -> dict | None:
    """Normais regionais por período (12 meses + ano), estações usadas e a taxa mensal e anual.

    Usa o par de períodos mais longo da série (primeiro → último). Se, com estações pareadas, algum mês fica sem
    estação nesse par, passa ao par seguinte mais longo que fecha os 12 meses (ex.: 1961–1990 → 1981–2010), e o
    resultado registra a troca ("par_substituto"). Sem nenhum par completo, fica o que tiver mais meses.
    """
    pers = sorted({p for e in estacoes for p in e.normais.get(var, {})})
    if len(pers) < 2:
        return None
    pares = sorted(((a, b) for i, a in enumerate(pers) for b in pers[i + 1:]),
                   key=lambda ab: -(PERIODOS[ab[1]][1] - PERIODOS[ab[0]][0]))
    melhor = None
    for p0, p1 in pares:
        r = _regional_par(estacoes, var, pareadas, p0, p1)
        if r["completo"]:
            melhor = r
            break
        if r["meses_ok"] and (melhor is None or r["meses_ok"] > melhor["meses_ok"]):
            melhor = r
    if melhor is None or "taxa" not in melhor:
        return None
    melhor["par_substituto"] = (melhor["periodo_inicial"], melhor["periodo_final"]) != pares[0]
    melhor["par_extremo"] = pares[0]
    return melhor


def n_pareadas(r: dict) -> int:
    """Menor número mensal de estações no primeiro período do par (pareadas, se for o caso)."""
    return min(r["n"].get(r["periodo_inicial"], [0])) if r else 0


def regional_adaptativo(estacoes: list, local, criterio: str, raio_km: float, var: str, pareadas: bool,
                        raio_max: float | None, passo: float = 100.0, cache: dict | None = None,
                        min_pareadas: int = 3):
    """Taxa regional da variável, ampliando o raio em passos até raio_max enquanto:

    - nenhum par de períodos fecha os 12 meses, ou
    - o par usado não é o mais longo da série (primeiro → último), ou
    - algum mês tem menos de ``min_pareadas`` estações.

    Fica o primeiro raio que atende a tudo; se nenhum atender até raio_max, o melhor resultado encontrado (12 meses
    completos, par mais longo, mais estações, menor raio). Retorna (resultado ou None, estações usadas, raio).
    """
    cache = {} if cache is None else cache
    raio, melhor = float(raio_km), None

    def nota(r):
        return (bool(r and r.get("completo")), bool(r and not r.get("par_substituto")),
                min(n_pareadas(r), min_pareadas) if r else 0)

    while True:
        if raio not in cache:
            ls = S.selecionar(estacoes, local, criterio if raio == raio_km else
                              ("uf_ou_raio" if criterio in ("uf_ou_raio", "uf") else criterio), raio, 1961, 2020)
            cache[raio] = [l["estacao"] for l in ls if l["selecionada"]]
        sel = cache[raio]
        r = regional(sel, var, pareadas) if sel else None
        if r is not None:
            r["raio_km"], r["ampliado"] = raio, raio > raio_km
            if melhor is None or nota(r) > nota(melhor[0]):
                melhor = (r, sel, raio)
        if nota(r) == (True, True, min_pareadas) or not raio_max or raio >= raio_max:
            break
        raio = min(raio + passo, raio_max)
    if melhor is None:
        return None, cache[raio], raio
    return melhor


def taxas_estacao(e, var: str) -> dict | None:
    d = e.normais.get(var, {})
    pers = sorted(d)
    if len(pers) < 2:
        return None
    p0, p1 = pers[0], pers[-1]
    anos = PERIODOS[p1][1] - PERIODOS[p0][0]
    return {"periodo_inicial": p0, "periodo_final": p1, "anos": anos,
            "taxa": [taxa(a, b, anos) for a, b in zip(d[p0], d[p1])],
            "taxa_ano": taxa(anual(d[p0], var), anual(d[p1], var), anos)}


# ----------------------------------------------------------------------------- projeções
def media_raster(pasta: Path, camadas: list, var: str, modelo: str, ssp: str, periodo: str) -> list | None:
    vals = []
    for mes in range(1, 13):
        cam = next((c for c in camadas if (c["var"], c["modelo"], c["ssp"], c["periodo"], int(c["mes"])) ==
                    (var, modelo, ssp, periodo, mes)), None)
        if cam is None:
            return None
        a, _ = P.ler(pasta / cam["raster"])
        vals.append(float(np.nanmean(a)) if np.isfinite(a).any() else None)
    return vals


def projecoes(pasta: Path, man: dict, variaveis: list, periodos: list | None, prog) -> list[dict]:
    """Taxas projetadas por modelo × SSP (e média do conjunto por SSP), do primeiro ao último período escolhido."""
    camadas = man["camadas"]
    disp = sorted({c["periodo"] for c in camadas if c["ssp"] != C.HIST})
    pers = [p for p in (periodos or disp) if p in disp]
    if len(pers) < 2:
        return []
    p0, p1 = pers[0], pers[-1]
    a0, a1 = int(p0[:4]), int(p1[-4:])
    combos = sorted({(c["modelo"], c["ssp"]) for c in camadas if c["ssp"] != C.HIST})
    out, k = [], 0
    for var in variaveis:
        for mod, ssp in combos:
            k += 1
            prog(100.0 * k / max(1, len(variaveis) * len(combos)), f"{var} {mod} {ssp}")
            v0 = media_raster(pasta, camadas, var, mod, ssp, p0)
            v1 = media_raster(pasta, camadas, var, mod, ssp, p1)
            if v0 is None or v1 is None:
                continue
            anos = a1 - a0
            out.append({"var": var, "modelo": mod, "ssp": ssp, "periodo_inicial": p0, "periodo_final": p1,
                        "anos": anos, "inicial": v0, "final": v1,
                        "taxa": [taxa(x, y, anos) for x, y in zip(v0, v1)],
                        "taxa_ano": taxa(anual(v0, var), anual(v1, var), anos)})
    for var in variaveis:  # média do conjunto de modelos por SSP
        for ssp in sorted({r["ssp"] for r in out if r["var"] == var}):
            rs = [r for r in out if r["var"] == var and r["ssp"] == ssp and r["modelo"] not in ("Conjunto", C.ENSEMBLE)]
            if len(rs) < 2:
                continue
            tx = [float(np.mean([r["taxa"][m] for r in rs])) for m in range(12)]
            out.append({"var": var, "modelo": "Conjunto", "ssp": ssp, "periodo_inicial": p0, "periodo_final": p1,
                        "anos": a1 - a0, "n_modelos": len(rs), "taxa": tx,
                        "taxa_ano": float(np.mean([r["taxa_ano"] for r in rs if r["taxa_ano"] is not None]))})
    return out


def _hist(pasta: Path, man: dict, var: str) -> list | None:
    cams = [c for c in man["camadas"] if c["var"] == var and c["ssp"] == C.HIST]
    if len(cams) < 12:
        return None
    c0 = cams[0]
    return media_raster(pasta, man["camadas"], var, c0["modelo"], C.HIST, c0["periodo"])


# ----------------------------------------------------------------------------- execução
PADRAO = {"local": {"tipo": "area"}, "criterio": "raio", "raio_km": 200.0, "pareadas": True,
          "tmed_normal": "media_tmax_tmin",
          "ampliar": True, "raio_max": 500.0, "min_pareadas": 3,
          "variaveis": list(VARIAVEIS), "periodos_proj": None, "idiomas": ["pt", "en"], "versao": ""}


def executar(cfg: dict, progresso=None, cancelado=None) -> dict:
    cfg = {**PADRAO, **{k: v for k, v in cfg.items() if v is not None}}
    prog = _Progresso(progresso, cancelado)
    avisos: list[str] = []
    cen = Path(cfg["cenarios"]) if cfg.get("cenarios") else None
    saida = Path(cfg["saida"])
    man = {}
    if cen is not None and (cen / "manifesto_cenarios.json").exists():
        man = json.loads((cen / "manifesto_cenarios.json").read_text(encoding="utf-8"))
    prog(2, "Lendo as normais do INMET")
    estacoes = carregar()
    lt = cfg["local"]
    if lt.get("tipo") == "nome":
        local = S.local_nome(lt.get("nome", ""), estacoes)
    elif lt.get("tipo") == "coordenadas":
        local = S.local_ponto(float(lt["lat"]), float(lt["lon"]))
    else:
        if cen is None:
            raise ErroValidacao(["Sem a Fase 1 no projeto, informe o local pelo nome ou pelas coordenadas."])
        area, e = geo.ler_vetor_area(cen / C.PASTAS["entradas"] / "area_estudo.gpkg")
        if area is None:
            raise ErroValidacao(e or ["O projeto não tem a área de estudo."])
        local = S.local_area(area.geom, "área de estudo do projeto")
    avisos += local.avisos
    if man and local.tipo == "ponto":
        a_proj, _ = geo.ler_vetor_area(cen / C.PASTAS["entradas"] / "area_estudo.gpkg")
        if a_proj is not None:
            from ..vies.referencia import ProjecaoArea
            d = ProjecaoArea(a_proj.geom).distancia_km(local.lon, local.lat)
            if d > 0:
                avisos.append(f"O local escolhido fica a {d:.0f} km da área de estudo do projeto: as normais são das "
                              "estações em torno do local, e as médias dos rasters são da área de estudo.")
    prog(10, "Normais regionais e taxas observadas")
    obs, por_est, cache, usadas, raio_ext = {}, [], {}, {}, float(cfg["raio_km"])
    chave_tmed = TMED_FONTES.get(cfg.get("tmed_normal", "media_tmax_tmin"), TMED_TX)
    for var in cfg["variaveis"]:
        chave = chave_tmed if var == "tmed" else var
        r, sel_v, raio_v = regional_adaptativo(estacoes, local, cfg["criterio"], float(cfg["raio_km"]), chave,
                                               cfg["pareadas"], cfg.get("raio_max") if cfg.get("ampliar", True)
                                               else None, cache=cache, min_pareadas=int(cfg.get("min_pareadas", 3)))
        if r is None:
            avisos.append(f"{var}: as estações até {raio_v:g} km não têm normais em dois períodos; taxa não "
                          "calculada.")
            continue
        r["estacoes"] = [e.codigo for e in sel_v
                         if r["periodo_inicial"] in e.normais.get(chave, {}) and r["periodo_final"] in e.normais.get(chave, {})]
        for e in sel_v:
            usadas[e.codigo] = e
        raio_ext = max(raio_ext, raio_v)
        if var == "tmed":
            r["fonte_tmed"] = chave
        if r.get("ampliado"):
            avisos.append(f"{var}: menos de {cfg.get('min_pareadas', 3)} estações pareadas em algum mês (ou par de "
                          f"períodos incompleto) até {cfg['raio_km']:g} km; o raio foi ampliado para {raio_v:g} km "
                          f"({len(sel_v)} estações; mínimo mensal pareado: {n_pareadas(r)}).")
        obs[var] = r
        if r.get("par_substituto"):
            avisos.append(f"{var}: nenhuma estação pareada fecha os 12 meses em {r['par_extremo'][0]} → "
                          f"{r['par_extremo'][1]}; a taxa usa {r['periodo_inicial']} → {r['periodo_final']} "
                          f"({r['anos']} anos).")
        if not r.get("completo"):
            avisos.append(f"{var}: só {r['meses_ok']} mês(es) com estação pareada; taxa anual não calculada.")
        if min(r["n"][r["periodo_inicial"]]) <= 1:
            avisos.append(f"{var}: há mês com uma única estação pareada ({r['periodo_inicial']} e "
                          f"{r['periodo_final']}).")
        for e in sel_v:
            t = taxas_estacao(e, chave)
            if t:
                por_est.append({"codigo": e.codigo, "nome": e.nome, "uf": e.uf, "var": var, **t})
    if not obs:
        raise ErroValidacao([f"Nenhuma estação com normais em dois períodos até {raio_ext:g} km de {local.descricao} "
                             f"({S.CRITERIOS[cfg['criterio']].format(raio=cfg['raio_km'])})."])
    linhas = S.selecionar(estacoes, local, cfg["criterio"] if raio_ext == cfg["raio_km"] else "raio", raio_ext,
                          1961, 2020)
    for l in linhas:
        l["selecionada"] = l["codigo"] in usadas
    linhas = [l for l in linhas if l["selecionada"] or l["distancia_km"] <= raio_ext]
    linhas.sort(key=lambda l: (not l["selecionada"], l["distancia_km"]))
    sel = list(usadas.values())
    if "etp" in obs and obs["etp"]["periodo_inicial"] != "1961-1990" and not obs["etp"].get("par_substituto"):
        avisos.append("ETP: o INMET não publica normal de evapotranspiração 1961–1990; a taxa usa "
                      f"{obs['etp']['periodo_inicial']} → {obs['etp']['periodo_final']} ({obs['etp']['anos']} anos).")
    proj, wc = [], {}
    if man:
        proj = projecoes(cen, man, [v for v in cfg["variaveis"] if v in obs], cfg["periodos_proj"],
                         lambda p, m: prog(15 + 0.75 * p, f"Taxas projetadas {m}"))
        for r in proj:
            r["pearson_obs"] = pearson(obs[r["var"]]["taxa"], r["taxa"])
            to = obs[r["var"]]["taxa_ano"]
            r["razao_obs"] = (r["taxa_ano"] / to) if (to not in (None, 0) and r["taxa_ano"] is not None) else None
        for var in obs:  # média do raster histórico na área × médias das normais das estações
            h = _hist(cen, man, var)
            if h:
                wc[var] = h
        if not proj:
            avisos.append("A pasta de cenários não tem dois períodos futuros para calcular as taxas projetadas.")
    else:
        avisos.append("Sem cenários no projeto: só as taxas observadas foram calculadas.")
    prog(92, "Tabelas e relatório")
    saida.mkdir(parents=True, exist_ok=True)
    arquivos = escrever(saida, cfg, local, linhas, obs, por_est, proj, wc, avisos)
    resumo = {"metodo": METODO, "fonte": FONTE, "local": {"tipo": local.tipo, "descricao": local.descricao,
                                                          "ufs": local.ufs, "lat": local.lat, "lon": local.lon},
              "criterio": S.CRITERIOS[cfg["criterio"]].format(raio=cfg["raio_km"]), "pareadas": cfg["pareadas"],
              "estacoes": [{"codigo": e.codigo, "nome": e.nome, "uf": e.uf} for e in sel],
              "observadas": obs, "projetadas": proj, "worldclim_historico": wc,
              "cenarios": str(cen) if cen else None, "avisos": avisos, "versao": cfg["versao"], "versoes": _versoes(),
              "utc": datetime.now(timezone.utc).isoformat()}
    (saida / "tendencia.json").write_text(json.dumps(resumo, ensure_ascii=False, indent=2, default=str),
                                          encoding="utf-8")
    prog(100, "Concluído")
    return {"situacao": "concluído com avisos" if avisos else "concluído", "avisos": avisos, "local": local,
            "linhas": linhas, "n_selecionadas": len(sel), "observadas": obs, "projetadas": proj,
            "arquivos": [str(a) for a in arquivos], "saida": str(saida)}


# ----------------------------------------------------------------------------- saídas
def _n(x, d=3, lang="pt", sinal=False):
    if x is None or (isinstance(x, float) and not math.isfinite(x)):
        return "—"
    t = f"{x:+.{d}f}" if sinal else f"{x:.{d}f}"
    return t.replace(".", ",") if lang == "pt" else t


def _csv(caminho: Path, linhas: list[dict]) -> Path:
    with caminho.open("w", encoding="utf-8-sig", newline="") as fh:
        if linhas:
            w = csv.DictWriter(fh, fieldnames=list(linhas[0]), delimiter=";")
            w.writeheader()
            for l in linhas:
                w.writerow({k: (round(v, 5) if isinstance(v, float) else v) for k, v in l.items()})
    return caminho


def escrever(dest: Path, cfg: dict, local, linhas: list, obs: dict, por_est: list, proj: list, wc: dict,
             avisos: list) -> list[Path]:
    arqs = []
    for lang in cfg["idiomas"]:
        pt = lang == "pt"
        M = MESES[lang]
        rows = [{("codigo" if pt else "code"): l["codigo"], ("nome" if pt else "name"): l["nome"],
                 ("uf" if pt else "state"): l["uf"], "latitude": round(l["lat"], 5), "longitude": round(l["lon"], 5),
                 "altitude_m": l["altitude"], ("distancia_km" if pt else "distance_km"): round(l["distancia_km"], 1),
                 ("selecionada" if pt else "selected"): l["selecionada"],
                 **{(f"periodos_{v}" if pt else f"periods_{v}"): " ".join(sorted(l["estacao"].normais.get(v, {})))
                    for v in VARIAVEIS}} for l in linhas]
        arqs.append(_csv(dest / f"estacoes_normais_{lang}.csv", rows))
        rows = []
        for var, r in obs.items():
            for per, vals in r["normais"].items():
                rows.append({("variavel" if pt else "variable"): NOME[lang][var], ("unidade" if pt else "unit"): UNID[var],
                             ("periodo" if pt else "period"): per, **{M[m]: vals[m] for m in range(12)},
                             ("ano" if pt else "year"): anual(vals, var),
                             ("n_estacoes_min" if pt else "n_stations_min"): min(r["n"][per])})
        arqs.append(_csv(dest / f"normais_regionais_{lang}.csv", rows))
        u = lambda v: f"{UNID[v]}/{'ano' if pt else 'yr'}"  # noqa: E731
        rows = []
        for var, r in obs.items():
            rows.append({("fonte" if pt else "source"): "INMET", ("modelo" if pt else "model"): "",
                         "ssp": "", ("variavel" if pt else "variable"): NOME[lang][var], ("unidade" if pt else "unit"): u(var),
                         ("periodo_inicial" if pt else "first_period"): r["periodo_inicial"],
                         ("periodo_final" if pt else "last_period"): r["periodo_final"], ("anos" if pt else "years"): r["anos"],
                         **{M[m]: r["taxa"][m] for m in range(12)}, ("ano" if pt else "year"): r["taxa_ano"],
                         ("r_pearson_obs" if pt else "pearson_r_obs"): "", ("razao_obs" if pt else "ratio_obs"): ""})
        for p in proj:
            rows.append({("fonte" if pt else "source"): "WorldClim CMIP6", ("modelo" if pt else "model"):
                         (p["modelo"] if p["modelo"] != "Conjunto" or pt else "All-model mean"),
                         "ssp": C.SSP_ARTIGO.get(p["ssp"], p["ssp"]), ("variavel" if pt else "variable"): NOME[lang][p["var"]],
                         ("unidade" if pt else "unit"): u(p["var"]), ("periodo_inicial" if pt else "first_period"): p["periodo_inicial"],
                         ("periodo_final" if pt else "last_period"): p["periodo_final"], ("anos" if pt else "years"): p["anos"],
                         **{M[m]: p["taxa"][m] for m in range(12)}, ("ano" if pt else "year"): p["taxa_ano"],
                         ("r_pearson_obs" if pt else "pearson_r_obs"): p.get("pearson_obs"),
                         ("razao_obs" if pt else "ratio_obs"): p.get("razao_obs")})
        arqs.append(_csv(dest / f"taxas_{lang}.csv", rows))
        rows = [{("codigo" if pt else "code"): t["codigo"], ("nome" if pt else "name"): t["nome"], ("uf" if pt else "state"): t["uf"],
                 ("variavel" if pt else "variable"): NOME[lang][t["var"]], ("periodo_inicial" if pt else "first_period"): t["periodo_inicial"],
                 ("periodo_final" if pt else "last_period"): t["periodo_final"], ("anos" if pt else "years"): t["anos"],
                 **{M[m]: t["taxa"][m] for m in range(12)}, ("ano" if pt else "year"): t["taxa_ano"]} for t in por_est]
        arqs.append(_csv(dest / f"taxas_estacoes_{lang}.csv", rows))
        if wc:
            rows = []
            for var, h in wc.items():
                rows.append({("variavel" if pt else "variable"): NOME[lang][var],
                             ("fonte" if pt else "source"): ("média do raster WorldClim 1970–2000 na área" if pt else
                                                             "WorldClim 1970–2000 raster mean over the area"),
                             **{M[m]: h[m] for m in range(12)}, ("ano" if pt else "year"): anual(h, var),
                             ("raster_menos_normal_ano" if pt else "raster_minus_normal_year"): None, "r_pearson": None})
                for per, vals in obs[var]["normais"].items():
                    ah, an = anual(h, var), anual(vals, var)
                    rows.append({("variavel" if pt else "variable"): NOME[lang][var],
                                 ("fonte" if pt else "source"): (f"média das normais {per} das estações" if pt else
                                                                 f"mean of the stations' {per} normals"),
                                 **{M[m]: vals[m] for m in range(12)}, ("ano" if pt else "year"): an,
                                 ("raster_menos_normal_ano" if pt else "raster_minus_normal_year"):
                                     (ah - an) if (ah is not None and an is not None) else None,
                                 "r_pearson": pearson(h, vals)})
            arqs.append(_csv(dest / f"comparacao_raster_normais_{lang}.csv", rows))
        arqs.append(_relatorio(dest / f"relatorio_tendencia_{lang}.md", lang, cfg, local, linhas, obs, proj, avisos,
                               wc))
    arqs.append(_gpkg(dest / "estacoes_normais.gpkg", linhas, local))
    return arqs


def _gpkg(caminho: Path, linhas: list, local) -> Path:
    from ..vies.delta import gravar_estacoes_gpkg
    lin = [{**l, "tipo": "convencional",
            **{f"meses_{v}": len(l["estacao"].normais.get(v, {})) for v in ("tmax", "tmin", "prec")}} for l in linhas]
    return gravar_estacoes_gpkg(caminho, lin, local)


def _relatorio(caminho: Path, lang: str, cfg: dict, local, linhas: list, obs: dict, proj: list, avisos: list,
               wc: dict | None = None) -> Path:
    pt = lang == "pt"
    M = MESES[lang]
    sel = [l for l in linhas if l["selecionada"]]
    crit = S.CRITERIOS[cfg["criterio"]].format(raio=cfg["raio_km"])
    if not pt:
        for a, b in (("mesma UF", "same state"), (" ou ", " or "), (" e ", " and "), ("até ", "within ")):
            crit = crit.replace(a, b)
    ua = "ano" if pt else "yr"
    L = [("# Avaliação de tendência com as normais climatológicas do INMET" if pt else
          "# Trend assessment with INMET climatological normals"), "",
         (f"- **Local:** {local.descricao} (UF: {', '.join(local.ufs)})" if pt else
          f"- **Location:** {local.descricao} (state: {', '.join(local.ufs)})"),
         (f"- **Critério de seleção:** {crit}; " + ("estações pareadas entre o primeiro e o último período"
                                                     if cfg["pareadas"] else "todas as estações de cada período")
          if pt else f"- **Selection criterion:** {crit}; " + ("stations paired between the first and last period"
                                                               if cfg["pareadas"] else "all stations in each period")),
         ("- **Taxa:** (valor do último período − valor do primeiro) ÷ (último ano do último período − primeiro ano "
          "do primeiro período), em unidades da variável por ano" if pt else
          "- **Rate:** (last-period value − first-period value) ÷ (last year of the last period − first year of the "
          "first period), in variable units per year"),
         ("- **Comparação:** média do raster (pixels da área de estudo) × média das normais das estações selecionadas; "
          "as taxas projetadas usam a média do raster na área em cada período" if pt else
          "- **Comparison:** raster mean (study-area pixels) × mean of the selected stations' normals; projected rates "
          "use the raster mean over the area in each period"),
         (f"- **Fonte:** {FONTE}" if pt else "- **Source:** INMET – Climatological Normals of Brazil 1961–1990, "
          "1981–2010 and 1991–2020"),
         (f"- **Método:** {METODO}" if pt else "- **Method:** Lima et al. (2026), Land Degradation & Development, "
          "doi:10.1002/ldr.70808, section 2.7"), "",
         (f"## Estações selecionadas ({len(sel)})" if pt else f"## Selected stations ({len(sel)})"), "",
         ("| Código | Estação | UF | Distância (km) | Normais |" if pt else
          "| Code | Station | State | Distance (km) | Normals |"), "|---|---|---|---:|---|"]
    for l in sel:
        pers = sorted({p for d in l["estacao"].normais.values() for p in d})
        L.append(f"| {l['codigo']} | {l['nome']} | {l['uf']} | {_n(l['distancia_km'], 1, lang)} | {', '.join(pers)} |")
    L += ["", ("## Taxas observadas (normais do INMET)" if pt else "## Observed rates (INMET normals)"), "",
          "| " + ("Variável" if pt else "Variable") + " | " + ("Períodos" if pt else "Periods") + " | "
          + " | ".join(M) + f" | {'Ano' if pt else 'Year'} |", "|---|---|" + "---:|" * 13]
    for var, r in obs.items():
        amp = (f"; {'raio' if pt else 'radius'} {r['raio_km']:g} km" if r.get("ampliado") else "")
        L.append(f"| {NOME[lang][var]} ({UNID[var]}/{ua}) | {r['periodo_inicial']} → {r['periodo_final']} "
                 f"({r['anos']} {'anos' if pt else 'yr'}{amp}) | " + " | ".join(_n(x, 3, lang, True) for x in r["taxa"])
                 + f" | **{_n(r['taxa_ano'], 3, lang, True)}** |")
    L += ["", ("### Normais regionais" if pt else "### Regional normals"), "",
          "| " + ("Variável" if pt else "Variable") + " | " + ("Período" if pt else "Period") + " | " + " | ".join(M)
          + f" | {'Ano' if pt else 'Year'} | {'Estações (mín.)' if pt else 'Stations (min.)'} |",
          "|---|---|" + "---:|" * 14]
    for var, r in obs.items():
        for per, vals in r["normais"].items():
            L.append(f"| {NOME[lang][var]} ({UNID[var]}) | {per} | " + " | ".join(_n(v, 1, lang) for v in vals)
                     + f" | {_n(anual(vals, var), 1, lang)} | {min(r['n'][per])} |")
    if proj:
        p0 = proj[0]
        L += ["", (f"## Taxas projetadas (WorldClim CMIP6, {p0['periodo_inicial']} → {p0['periodo_final']}, "
                   f"{p0['anos']} anos) e comparação com as observadas" if pt else
                   f"## Projected rates (WorldClim CMIP6, {p0['periodo_inicial']} → {p0['periodo_final']}, "
                   f"{p0['anos']} yr) compared with observed rates"), "",
              ("| Variável | Modelo | SSP | Taxa anual | Observada | Razão proj./obs. | r de Pearson (12 meses) |" if pt
               else "| Variable | Model | SSP | Annual rate | Observed | Proj./obs. ratio | Pearson r (12 months) |"),
              "|---|---|---|---:|---:|---:|---:|"]
        for p in sorted(proj, key=lambda p: (VARIAVEIS.index(p["var"]), p["modelo"] != "Conjunto", p["ssp"], p["modelo"])):
            mod = p["modelo"] if (pt or p["modelo"] != "Conjunto") else "All-model mean"
            if p["modelo"] == "Conjunto":
                mod = f"**{mod} ({p.get('n_modelos', '')})**"
            L.append(f"| {NOME[lang][p['var']]} ({UNID[p['var']]}/{ua}) | {mod} | {C.SSP_ARTIGO.get(p['ssp'], p['ssp'])} | "
                     f"{_n(p['taxa_ano'], 3, lang, True)} | {_n(obs[p['var']]['taxa_ano'], 3, lang, True)} | "
                     f"{_n(p.get('razao_obs'), 2, lang)} | {_n(p.get('pearson_obs'), 3, lang)} |")
    if wc:
        L += ["", ("## Médias comparadas: raster na área × normais das estações" if pt else
                   "## Compared means: raster over the area × station normals"), "",
              ("A comparação é sempre entre a **média do raster** (pixels da área de estudo) e a **média das normais** "
               "das estações selecionadas, mês a mês e no ano." if pt else
               "The comparison is always between the **raster mean** (study-area pixels) and the **mean of the "
               "normals** of the selected stations, per month and for the year."), "",
              "| " + ("Variável" if pt else "Variable") + " | " + ("Fonte" if pt else "Source") + " | " + " | ".join(M)
              + f" | {'Ano' if pt else 'Year'} | {'Raster − normal (ano)' if pt else 'Raster − normal (year)'} | r |",
              "|---|---|" + "---:|" * 15]
        for var, h in wc.items():
            L.append(f"| {NOME[lang][var]} ({UNID[var]}) | {'Raster WorldClim 1970–2000' if pt else 'WorldClim 1970–2000 raster'} | "
                     + " | ".join(_n(v, 1, lang) for v in h) + f" | {_n(anual(h, var), 1, lang)} | | |")
            for per, vals in obs[var]["normais"].items():
                ah, an = anual(h, var), anual(vals, var)
                L.append(f"| | {'Normais' if pt else 'Normals'} {per} | " + " | ".join(_n(v, 1, lang) for v in vals)
                         + f" | {_n(an, 1, lang)} | {_n((ah - an) if (ah is not None and an is not None) else None, 1, lang, True)}"
                         f" | {_n(pearson(h, vals), 3, lang)} |")
        if "tmed" in wc:
            L += ["", ("_Tmed: o raster usa (Tmin + Tmax)/2; as normais, " if pt else "_Tmean: the raster uses (Tmin + Tmax)/2; the normals use ")
                  + (("(Tmax + Tmin)/2 calculada das normais, para a comparação ser equivalente._" if pt else
                      "(Tmax + Tmin)/2 computed from the normals, so the comparison is like for like._")
                     if obs.get("tmed", {}).get("fonte_tmed") == TMED_TX else
                     ("a média compensada do INMET (fórmulas diferentes)._" if pt else
                      "INMET's compensated mean (different formulas)._"))]
    if avisos:
        L += ["", ("## Avisos" if pt else "## Warnings"), ""] + [f"- {a}" for a in avisos]
    L += ["", ("_Taxa positiva: aumento; negativa: diminuição. A razão compara a taxa anual projetada com a observada; o "
               "r de Pearson compara o padrão mensal das taxas._" if pt else
               "_Positive rate: increase; negative: decrease. The ratio compares the projected and observed annual rates; "
               "Pearson's r compares the monthly pattern of the rates._")]
    caminho.write_text("\n".join(L) + "\n", encoding="utf-8")
    return caminho
