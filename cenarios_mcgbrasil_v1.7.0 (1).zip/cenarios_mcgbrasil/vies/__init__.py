"""Correção de viés dos cenários climáticos com o banco de dados mensal do INMET (BDMEP).

Submódulos:
* banco      – leitura dos CSVs mensais do BDMEP (pastas, .zip ou arquivos), sem dependência do QGIS;
* referencia – municípios e limites das UFs do IBGE embutidos (busca por nome, UF de cada estação);
* selecao    – escolha das estações pela UF e/ou pela distância ao local de mapeamento;
* delta      – médias regionais, delta mensal, correlação de Pearson e aplicação aos rasters (Lima et al., 2026,
               Land Degradation & Development, doi:10.1002/ldr.70808, seção 2.6).
"""
