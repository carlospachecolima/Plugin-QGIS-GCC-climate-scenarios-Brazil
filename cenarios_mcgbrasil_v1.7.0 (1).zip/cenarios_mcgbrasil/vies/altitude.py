"""Ajuste das temperaturas das estações pela altitude, antes da média regional (Fase 2).

Problema: a média regional das estações e a média do WorldClim na área só são comparáveis se estiverem na mesma
altitude. No DF, por exemplo, as estações escolhidas ficam em média a ~750 m e a área a ~1.100 m, o que soma
cerca de +2,5 °C ao Delta da Tmin e "rebaixa" o planalto.

Correção: cada temperatura mensal da estação (Tmax, Tmin, Tmed) é levada à altitude média da área pelo gradiente
térmico vertical Γ (padrão 0,65 °C/100 m, atmosfera padrão):

    T_ajustada = T_estação + Γ · (z_estação − z_área)

z_área é a média da elevação do WorldClim v2.1 (wc2.1_30s_elev, a mesma usada na interpolação do clima) nos pixels
válidos do histórico recortado, os mesmos da média WorldClim do Delta. A precipitação não é ajustada.

Altitudes de estação suspeitas: valor ausente ou abaixo de 10 m num lugar cujas vizinhas (até 25 km) ficam acima
de 200 m. Se o valor × 1000 bate com as vizinhas (cadastro em km, ex.: 83380 Brasília-NOVACAP = 1,15), é corrigido;
senão, a estação fica fora das médias de temperatura.
"""

from __future__ import annotations

import statistics
from pathlib import Path

import numpy as np
from osgeo import gdal

from ..cenarios import catalogo as C
from ..cenarios import processamento as P
from ..cenarios import worldclim as W
from . import referencia as R

ARQUIVO = "elevacao_worldclim.tif"
GRADIENTE_PADRAO = 0.65          # °C por 100 m
RAIO_VIZINHAS_KM = 25.0


def caminho_na_fase1(pasta_fase1: Path) -> Path:
    return Path(pasta_fase1) / C.PASTAS["entradas"] / ARQUIVO


def baixar(destino: Path, envelope: tuple) -> Path:
    """Copia do servidor do WorldClim só o retângulo da área (com margem de 0,05°)."""
    P.configurar_http(W.OPCOES_HTTP)
    fonte = W.vsi_elevacao()
    if not P.existe(fonte):
        raise RuntimeError("elevação do WorldClim (wc2.1_30s_elev) não encontrada no servidor ou sem conexão")
    return P.subconjunto(fonte, Path(destino), envelope)


def obter(pasta_fase1: Path, destino: Path, envelope: tuple, avisos: list) -> Path | None:
    """O MDE salvo pela Fase 1 (entradas/elevacao_worldclim.tif) ou, se faltar, baixado agora para ``destino``."""
    p = caminho_na_fase1(pasta_fase1)
    if p.exists():
        return p
    try:
        q = baixar(destino, envelope)
        avisos.append("A Fase 1 não tinha a elevação do WorldClim (projetos anteriores à v1.7.0); baixada agora "
                      "do servidor do WorldClim (wc2.1_30s_elev), só o retângulo da área.")
        return q
    except Exception as exc:  # noqa: BLE001
        avisos.append(f"Elevação do WorldClim indisponível: {exc}.")
        return None


def altitude_area(mde: Path, referencia: Path) -> float:
    """Média da elevação nos pixels válidos de ``referencia`` (raster histórico recortado), na grade dela."""
    ref = gdal.Open(str(referencia))
    gt, nx, ny = ref.GetGeoTransform(), ref.RasterXSize, ref.RasterYSize
    limites = (gt[0], gt[3] + ny * gt[5], gt[0] + nx * gt[1], gt[3])
    ds = gdal.Warp("", str(mde), format="MEM", outputBounds=limites, width=nx, height=ny, resampleAlg="near",
                   dstNodata=P.NODATA, outputType=gdal.GDT_Float32)
    z = ds.GetRasterBand(1).ReadAsArray().astype(float)
    nd = ds.GetRasterBand(1).GetNoDataValue()
    if nd is not None:
        z[z == nd] = np.nan
    a, _ = P.ler(referencia)
    ok = np.isfinite(a) & np.isfinite(z)
    if not ok.any():
        raise RuntimeError("a elevação do WorldClim não cobre a área de estudo")
    return float(z[ok].mean())


def altitudes_validas(selecionadas: list, todas: list) -> tuple[dict, list[str]]:
    """codigo -> altitude usada (m) ou None (fora das temperaturas); e avisos."""
    out, avisos = {}, []
    for e in selecionadas:
        alt = e.altitude
        if alt is not None and alt >= 10:
            out[e.codigo] = float(alt)
            continue
        viz = [o.altitude for o in todas if o is not e and o.altitude is not None and o.altitude >= 10
               and R.haversine_km(e.lat, e.lon, o.lat, o.lon) <= RAIO_VIZINHAS_KM]
        med = statistics.median(viz) if viz else None
        if med is None or med < 200:
            if alt is None:
                out[e.codigo] = None
                avisos.append(f"Estação {e.codigo} ({e.nome}) sem altitude no cadastro do INMET e sem vizinhas para "
                              "conferir: fica fora das médias de temperatura.")
            else:
                out[e.codigo] = float(alt)     # baixada litorânea: altitude baixa plausível
            continue
        if alt and abs(alt * 1000 - med) <= max(150.0, 0.2 * med):
            out[e.codigo] = alt * 1000
            avisos.append(f"Estação {e.codigo} ({e.nome}): altitude cadastrada {alt:g} m parece estar em km "
                          f"(vizinhas a ~{med:.0f} m); usada {alt * 1000:.0f} m.")
        else:
            out[e.codigo] = None
            avisos.append(f"Estação {e.codigo} ({e.nome}): altitude cadastrada "
                          f"{'ausente' if alt is None else f'{alt:g} m'} incompatível com as vizinhas (~{med:.0f} m); "
                          "fica fora das médias de temperatura.")
    return out, avisos
