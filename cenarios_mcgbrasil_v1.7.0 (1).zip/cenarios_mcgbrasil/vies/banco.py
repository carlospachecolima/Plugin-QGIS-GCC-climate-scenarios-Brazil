"""Leitura do banco de dados mensal do INMET (BDMEP), no formato de exportação do portal.

Cada estação é um CSV (``dados_<código>_M_<início>_<fim>.csv``) com 9 linhas de cabeçalho (Nome, Codigo Estacao,
Latitude, Longitude, Altitude, Situacao, Data Inicial, Data Final, Periodicidade da Medicao), uma linha em branco,
a linha de colunas (``Data Medicao;…``) e os dados mensais separados por ``;``, com ``null`` para falta de dado.
As colunas mudam de estação para estação (as automáticas, código A…, não têm Tmax/Tmin mensais).

Defeito do portal (conferido no banco embutido): em 468 das 565 estações convencionais o cabeçalho omite colunas que
continuam nas linhas de dados. Em 463 delas falta só a "pressão ao nível do mar" e a coluna sobra vazia no fim da
linha (inofensivo); em outras (ex.: 83383 Buritis, cabeçalho com 11 colunas e dados com 17) os valores ficavam
atribuídos à variável errada (chuva lida como Tmax). Quando o número de valores não bate com o cabeçalho, as colunas
são lidas pela ordem fixa do BDMEP (``ORDEM_CONVENCIONAL``), e valores fora da faixa física de cada variável
(``FAIXA``) são descartados e contados.

Fontes aceitas: pastas (lidas recursivamente), arquivos .zip e arquivos .csv soltos.
"""

from __future__ import annotations

import math
import os
import re
import zipfile
from dataclasses import dataclass, field
from pathlib import Path

# variável canônica -> (rótulo pt, rótulo en, unidade, nomes das colunas no BDMEP sem a unidade)
VARIAVEIS = {
    "tmax": ("Temperatura máxima média", "Mean maximum temperature", "°C", ["TEMPERATURA MAXIMA MEDIA, MENSAL"]),
    "tmin": ("Temperatura mínima média", "Mean minimum temperature", "°C", ["TEMPERATURA MINIMA MEDIA, MENSAL"]),
    "tmed": ("Temperatura média", "Mean temperature", "°C",
             ["TEMPERATURA MEDIA COMPENSADA, MENSAL", "TEMPERATURA MEDIA, MENSAL (AUT)"]),
    "prec": ("Precipitação total", "Total precipitation", "mm",
             ["PRECIPITACAO TOTAL, MENSAL", "PRECIPITACAO TOTAL, MENSAL (AUT)"]),
    "etp": ("Evapotranspiração potencial (BH)", "Potential evapotranspiration (WB)", "mm",
            ["EVAPOTRANSPIRACAO POTENCIAL, BH MENSAL"]),
    "etr": ("Evapotranspiração real (BH)", "Actual evapotranspiration (WB)", "mm", ["EVAPOTRANSPIRACAO REAL, BH MENSAL"]),
    "evap_piche": ("Evaporação do Piche", "Piche evaporation", "mm", ["EVAPORACAO DO PICHE, MENSAL"]),
    "insolacao": ("Insolação total", "Total sunshine", "h", ["INSOLACAO TOTAL, MENSAL"]),
    "ur": ("Umidade relativa média", "Mean relative humidity", "%", ["UMIDADE RELATIVA DO AR, MEDIA MENSAL"]),
    "nebulosidade": ("Nebulosidade média", "Mean cloudiness", "décimos", ["NEBULOSIDADE, MEDIA MENSAL"]),
    "dias_chuva": ("Dias com precipitação", "Days with precipitation", "dias",
                   ["NUMERO DE DIAS COM PRECIP. PLUV, MENSAL", "NUMERO DE DIAS COM PRECIP. PLUV, MENSAL (AUT)"]),
    "vento_medio": ("Velocidade média do vento", "Mean wind speed", "m/s",
                    ["VENTO, VELOCIDADE MEDIA MENSAL", "VENTO, VELOCIDADE MEDIA MENSAL (AUT)"]),
    "pressao": ("Pressão atmosférica média", "Mean atmospheric pressure", "mB",
                ["PRESSAO ATMOSFERICA, MEDIA MENSAL", "PRESSAO ATMOSFERICA, MEDIA MENSAL (AUT)"]),
}
# derivadas, calculadas mês a mês quando as duas componentes existem
DERIVADAS = {
    "deficit_hidrico": ("Deficiência hídrica (ETP − ETR, BH)", "Water deficit (PET − AET, WB)", "mm", ("etp", "etr")),
}
PRINCIPAIS = ("tmax", "tmin", "prec")  # usadas no delta e na correlação
TEMPERATURAS = ("tmax", "tmin", "tmed")  # ajustadas pela altitude na média regional

# ordem fixa das 17 colunas das estações convencionais no portal do INMET (após "Data Medicao")
ORDEM_CONVENCIONAL = (
    "DIRECAO PREDOMINANTE DO VENTO, MENSAL", "EVAPORACAO DO PICHE, MENSAL", "EVAPOTRANSPIRACAO POTENCIAL, BH MENSAL",
    "EVAPOTRANSPIRACAO REAL, BH MENSAL", "INSOLACAO TOTAL, MENSAL", "NEBULOSIDADE, MEDIA MENSAL",
    "NUMERO DE DIAS COM PRECIP. PLUV, MENSAL", "PRECIPITACAO TOTAL, MENSAL",
    "PRESSAO ATMOSFERICA AO NIVEL DO MAR, MEDIA MENSAL", "PRESSAO ATMOSFERICA, MEDIA MENSAL",
    "TEMPERATURA MAXIMA MEDIA, MENSAL", "TEMPERATURA MEDIA COMPENSADA, MENSAL", "TEMPERATURA MINIMA MEDIA, MENSAL",
    "UMIDADE RELATIVA DO AR, MEDIA MENSAL", "VENTO, VELOCIDADE MAXIMA MENSAL", "VENTO, VELOCIDADE MEDIA MENSAL",
    "VISIBILIDADE, MEDIA MENSAL")
ORDEM_SEM_PNM = tuple(c for c in ORDEM_CONVENCIONAL if "NIVEL DO MAR" not in c)   # 16 colunas + 1 vazia no fim
# faixa física aceita por variável (valores mensais); fora dela o valor é descartado
FAIXA = {"tmax": (-5.0, 45.0), "tmin": (-15.0, 35.0), "tmed": (-10.0, 40.0), "prec": (0.0, 2000.0),
         "etp": (0.0, 400.0), "etr": (0.0, 400.0), "evap_piche": (0.0, 700.0), "insolacao": (0.0, 450.0),
         "ur": (1.0, 100.0), "nebulosidade": (0.0, 10.0), "dias_chuva": (0.0, 31.0), "vento_medio": (0.0, 30.0),
         "pressao": (600.0, 1050.0)}

_COLUNA = {nome: var for var, (_, _, _, nomes) in VARIAVEIS.items() for nome in nomes}
_UNIDADE = re.compile(r"\(([^()]*(\([^()]*\))?[^()]*)\)\s*$")
_ARQ = re.compile(r"dados_[^/\\]+_M_.*\.csv$", re.I)


def _sem_unidade(coluna: str) -> str:
    c = coluna.strip()
    m = _UNIDADE.search(c)
    return c[:m.start()].strip() if m else c


@dataclass
class Estacao:
    codigo: str
    nome: str
    lat: float
    lon: float
    altitude: float | None
    situacao: str
    inicio: str
    fim: str
    origem: str
    uf: str = ""
    dados: dict = field(default_factory=dict)  # var -> {(ano, mês): valor}
    leitura: str = ""                           # "" = cabeçalho correto; senão, como as colunas foram lidas
    descartados: dict = field(default_factory=dict)   # var -> nº de valores fora da faixa física

    @property
    def tipo(self) -> str:
        return "automática" if self.codigo[:1].upper() == "A" else "convencional"

    def valores(self, var: str, ano0: int, ano1: int, mes: int) -> list[float]:
        d = self.dados.get(var, {})
        return [v for (a, m), v in d.items() if m == mes and ano0 <= a <= ano1]

    def n_meses_validos(self, var: str, ano0: int, ano1: int) -> int:
        return sum(1 for (a, _m) in self.dados.get(var, {}) if ano0 <= a <= ano1)


def _num(txt: str):
    t = txt.strip()
    if not t or t.lower() == "null":
        return None
    try:
        return float(t.replace(",", "."))
    except ValueError:
        return None


def ler_texto(texto: str, origem: str) -> Estacao | None:
    linhas = texto.splitlines()
    cab, i_dados = {}, None
    for i, l in enumerate(linhas[:30]):
        if l.startswith("Data Medicao"):
            i_dados = i
            break
        if ":" in l:
            k, v = l.split(":", 1)
            cab[k.strip()] = v.strip()
    if i_dados is None or "Codigo Estacao" not in cab:
        return None
    try:
        lat, lon = float(cab["Latitude"].replace(",", ".")), float(cab["Longitude"].replace(",", "."))
    except (KeyError, ValueError):
        return None
    alt = _num(cab.get("Altitude", ""))
    est = Estacao(cab["Codigo Estacao"], cab.get("Nome", cab["Codigo Estacao"]), lat, lon, alt,
                  cab.get("Situacao", ""), cab.get("Data Inicial", ""), cab.get("Data Final", ""), origem)
    cab_col = linhas[i_dados].split(";")
    if cab_col and cab_col[-1] == "":
        cab_col = cab_col[:-1]
    nomes = [_sem_unidade(c) for c in cab_col]
    dados = []
    for l in linhas[i_dados + 1:]:
        p = l.split(";")
        if p and p[-1] == "":
            p = p[:-1]
        if not p or len(p[0]) < 7 or p[0][4] != "-":
            continue
        try:
            dados.append((int(p[0][:4]), int(p[0][5:7]), p))
        except ValueError:
            continue
    n_val = max((len(p) for _a, _m, p in dados), default=len(nomes))
    if n_val > len(nomes):   # cabeçalho incompleto: ordem fixa do BDMEP
        nomeados = set(nomes[1:])
        if n_val - 1 == len(ORDEM_CONVENCIONAL) and nomeados <= set(ORDEM_SEM_PNM) and \
                all(p[-1].strip().lower() in ("", "null") for _a, _m, p in dados if len(p) == n_val):
            nomes = ["Data Medicao", *ORDEM_SEM_PNM]                 # 16 colunas + 1 vazia no fim
            if len(cab_col) - 1 != len(ORDEM_SEM_PNM):
                est.leitura = "cabeçalho incompleto; colunas lidas pela ordem padrão do BDMEP (sem pressão ao nível do mar)"
        elif n_val - 1 == len(ORDEM_CONVENCIONAL) and nomeados <= set(ORDEM_CONVENCIONAL):
            nomes = ["Data Medicao", *ORDEM_CONVENCIONAL]
            est.leitura = "cabeçalho incompleto; colunas lidas pela ordem padrão do BDMEP"
        else:
            est.leitura = (f"cabeçalho com {len(cab_col) - 1} colunas e dados com {n_val - 1}, fora do padrão; "
                           "estação descartada")
            return est
    colunas = [_COLUNA.get(c) for c in nomes]
    for ano, mes, p in dados:
        for j in range(1, min(len(p), len(colunas))):
            var = colunas[j]
            if var is None:
                continue
            v = _num(p[j])
            if v is None:
                continue
            lo, hi = FAIXA.get(var, (-math.inf, math.inf))
            if not lo <= v <= hi:
                est.descartados[var] = est.descartados.get(var, 0) + 1
                continue
            est.dados.setdefault(var, {})[(ano, mes)] = v
    for der, (_pt, _en, _u, (a, b)) in DERIVADAS.items():
        da, db = est.dados.get(a, {}), est.dados.get(b, {})
        comum = set(da) & set(db)
        if comum:
            est.dados[der] = {k: da[k] - db[k] for k in comum}
    return est


def _decodificar(b: bytes) -> str:
    for enc in ("utf-8-sig", "latin-1"):
        try:
            return b.decode(enc)
        except UnicodeDecodeError:
            continue
    return b.decode("utf-8", errors="replace")


def ler_banco(fontes: list[str], progresso=None) -> tuple[list[Estacao], list[str]]:
    """Lê todas as estações das fontes. Retorna (estações, avisos). Códigos repetidos: fica a primeira leitura."""
    itens: list[tuple[str, callable]] = []
    avisos: list[str] = []
    for f in fontes:
        p = Path(f)
        if p.is_dir():
            for a in sorted(p.rglob("*.csv")):
                itens.append((str(a), lambda a=a: a.read_bytes()))
            for z in sorted(p.rglob("*.zip")):
                itens += _itens_zip(z)
        elif p.suffix.lower() == ".zip" and p.exists():
            itens += _itens_zip(p)
        elif p.suffix.lower() == ".csv" and p.exists():
            itens.append((str(p), lambda p=p: p.read_bytes()))
        else:
            avisos.append(f"Fonte do banco ignorada (não é pasta, .zip nem .csv): {f}")
    estacoes: dict[str, Estacao] = {}
    ignorados = 0
    for k, (nome, ler) in enumerate(itens):
        if progresso and k % 50 == 0:
            progresso(k, len(itens))
        if not _ARQ.search(os.path.basename(nome)) and not nome.lower().endswith(".csv"):
            continue
        e = ler_texto(_decodificar(ler()), nome)
        if e is None:
            ignorados += 1
            continue
        if e.leitura.endswith("descartada"):
            avisos.append(f"Estação {e.codigo} ({e.nome}): {e.leitura}.")
            continue
        if e.codigo in estacoes:
            avisos.append(f"Estação {e.codigo} repetida; mantida a primeira ({os.path.basename(estacoes[e.codigo].origem)}).")
            continue
        estacoes[e.codigo] = e
    if ignorados:
        avisos.append(f"{ignorados} arquivo(s) .csv sem o cabeçalho do BDMEP foram ignorados.")
    realinhadas = [e for e in estacoes.values() if e.leitura]
    if realinhadas:
        avisos.append(f"{len(realinhadas)} estação(ões) com cabeçalho incompleto no arquivo do INMET, lidas pela ordem "
                      "padrão das colunas do BDMEP: " + ", ".join(f"{e.codigo} {e.nome}" for e in realinhadas[:10])
                      + ("…" if len(realinhadas) > 10 else "") + ".")
    return list(estacoes.values()), avisos


def _itens_zip(z: Path) -> list:
    try:
        zf = zipfile.ZipFile(z)
    except zipfile.BadZipFile:
        return []
    return [(f"{z}!{n}", lambda zf=zf, n=n: zf.read(n)) for n in zf.namelist() if n.lower().endswith(".csv")]


UNIDADE_EN = {"décimos": "tenths", "dias": "days"}


def rotulo(var: str, lang: str = "pt") -> str:
    info = VARIAVEIS.get(var) or DERIVADAS.get(var)
    un = info[2] if lang == "pt" else UNIDADE_EN.get(info[2], info[2])
    return f"{info[0] if lang == 'pt' else info[1]} ({un})"


def unidade(var: str) -> str:
    return (VARIAVEIS.get(var) or DERIVADAS.get(var))[2]


def ordem_variaveis() -> list[str]:
    return list(VARIAVEIS) + list(DERIVADAS)
