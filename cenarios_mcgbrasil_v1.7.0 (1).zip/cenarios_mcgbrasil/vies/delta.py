"""Correção de viés pelo método Delta regional e correlação de Pearson (Lima et al., 2026, seção 2.6).

1. Seleciona as estações do banco do INMET pela distância ao local de mapeamento (padrão: até 200 km, sem ampliação),
   com ao menos 120 meses válidos no período (10 anos) e r de Pearson ≥ 0,8 com o WorldClim em Tmax, Tmin e Prec; a
   estação que falha em qualquer critério é eliminada. O critério do artigo (mesma UF ou raio) continua disponível.
2. Leva as temperaturas de cada estação à altitude média da área pelo gradiente térmico (0,65 °C/100 m), com a
   elevação do WorldClim (vies/altitude.py), para que estações mais baixas ou mais altas não criem um falso viés.
3. Média regional observada de cada mês (padrão do artigo: soma de todos os valores mensais das estações no período
   ÷ número de ocorrências), para Tmax, Tmin, Prec e as variáveis secundárias do banco.
4. Média regional do WorldClim histórico recortado (média simples dos pixels da área, 12 meses).
5. Delta mensal = observado − WorldClim (Tmin, Tmax) e fator = observado / WorldClim (Prec; padrão desde a v1.7.0,
   limitado a 0,5–2,0 nos meses com WorldClim < 10 mm), e r de Pearson entre as 12 médias mensais.
6. Opcional: aplica o delta e o fator a todos os rasters da pasta de cenários — histórico e todos os modelos, SSPs e
   períodos — gravando uma pasta corrigida com a mesma organização, estatísticas, layouts e PNG.
"""

from __future__ import annotations

import csv
import json
import math
import re
import shutil
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from ..cenarios import catalogo as C
from ..cenarios import manual as M
from ..cenarios import nomes as N
from ..cenarios import processamento as P
from ..comum import geo
from ..comum.config import ErroValidacao
from ..comum.util import sha256
from ..comum.util import _Progresso, _versoes
from . import altitude as A
from . import banco as B
from . import selecao as S

METODO = "Lima et al. (2026), Land Degradation & Development, doi:10.1002/ldr.70808, seção 2.6 (método Delta regional)"
MEDIAS = {"agrupada": "soma dos valores mensais de todas as estações ÷ número de ocorrências (artigo)",
          "estacoes": "média das médias mensais de cada estação"}
MESES_PT = ("Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez")
MESES_EN = ("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
PASTA_TABELAS = "correcao_vies"

PADRAO = {"local": {"tipo": "area"}, "criterio": "raio", "raio_km": 200.0, "raio_max": 200.0, "min_estacoes": 3,
          "min_meses": 120, "r_min_estacao": 0.8, "ajuste_altitude": True, "gradiente": A.GRADIENTE_PADRAO, "ano0": 1970, "ano1": 2000,
          "media": "agrupada", "min_anos": 1, "metodo_prec": "multiplicativo", "aplicar": True, "idiomas": ["pt", "en"],
          "gerar_mapas": True, "dpi": 300, "regiao": "", "autor": "", "simbologia": {}, "versao": ""}
PREC_SECO_MM = 10.0            # meses com WorldClim abaixo disto: fator limitado a FATOR_LIMITES
FATOR_LIMITES = (0.5, 2.0)
METODO_EN = {"aditivo": "additive", "multiplicativo": "multiplicative"}


# ----------------------------------------------------------------------------- cálculos
def medias_regionais(estacoes: list[B.Estacao], ano0: int, ano1: int, modo: str, min_anos: int,
                     variaveis: list[str], min_meses: int = 1, ajuste: dict | None = None) -> dict:
    """var -> 12 dicts {valor, n_estacoes, n_ocorrencias} (valor None sem dado).

    ``min_meses``: a estação só entra na variável com ao menos esse número de meses válidos no período.
    ``ajuste``: código -> correção de altitude (°C) somada às temperaturas; None = estação fora das temperaturas.
    """
    out = {}
    for var in variaveis:
        meses = []
        ests = [e for e in estacoes if e.n_meses_validos(var, ano0, ano1) >= max(1, min_meses)]
        corr = {e.codigo: 0.0 for e in ests}
        if ajuste is not None and var in B.TEMPERATURAS:
            ests = [e for e in ests if ajuste.get(e.codigo) is not None]
            corr = {e.codigo: ajuste[e.codigo] for e in ests}
        for mes in range(1, 13):
            por_est = [[v + corr[e.codigo] for v in vs] for e in ests
                       if len(vs := e.valores(var, ano0, ano1, mes)) >= max(1, min_anos)]
            todos = [v for vs in por_est for v in vs]
            if not todos:
                meses.append({"valor": None, "n_estacoes": 0, "n_ocorrencias": 0})
                continue
            valor = (sum(todos) / len(todos)) if modo == "agrupada" else float(np.mean([np.mean(vs) for vs in por_est]))
            meses.append({"valor": valor, "n_estacoes": len(por_est), "n_ocorrencias": len(todos)})
        if any(m["valor"] is not None for m in meses):
            out[var] = meses
    return out


def media_worldclim(pasta: Path, camadas: list[dict], var: str) -> list[float]:
    """Média simples dos pixels válidos de cada mês do histórico WorldClim recortado."""
    vals = []
    for mes in range(1, 13):
        cam = next((c for c in camadas if c["var"] == var and c["ssp"] == C.HIST and int(c["mes"]) == mes), None)
        if cam is None:
            raise ErroValidacao([f"A pasta de cenários não tem o histórico de {var}, mês {mes}. Rode antes a Fase 1 "
                                 "(etapa 1.1 ou 1.3) para tmin, tmax e prec."])
        a, _ = P.ler(pasta / cam["raster"])
        if not np.isfinite(a).any():
            raise ErroValidacao([f"Histórico de {var}, mês {mes}: nenhum pixel válido."])
        vals.append(float(np.nanmean(a)))
    return vals


def r_estacao(e: B.Estacao, wc: dict, ano0: int, ano1: int, min_meses: int) -> dict:
    """r de Pearson entre as 12 médias mensais da estação e as 12 do WorldClim na área, por variável principal.

    Só para as variáveis em que a estação entra (``min_meses``) e tem os 12 meses; senão, a variável não é avaliada.
    O ajuste de altitude é uma constante por estação e não muda o r.
    """
    out = {}
    for v in B.PRINCIPAIS:
        if e.n_meses_validos(v, ano0, ano1) < max(1, min_meses):
            continue
        medias = [np.mean(vs) if (vs := e.valores(v, ano0, ano1, m)) else None for m in range(1, 13)]
        if all(x is not None for x in medias):
            out[v] = pearson([float(x) for x in medias], wc[v])
    return out


def pearson(x: list[float], y: list[float]) -> float | None:
    a, b = np.asarray(x, float), np.asarray(y, float)
    if a.size < 3 or a.std() == 0 or b.std() == 0:
        return None
    return float(np.corrcoef(a, b)[0, 1])


def ajustes(obs: dict, wc: dict, metodo_prec: str) -> dict:
    out = {}
    for var in B.PRINCIPAIS:
        o = [m["valor"] for m in obs[var]]
        w = wc[var]
        metodo = metodo_prec if var == "prec" else "aditivo"
        delta = [oo - ww for oo, ww in zip(o, w)]
        fator = limitados = None
        if metodo == "multiplicativo":
            fator, limitados = [], []
            for i, (oo, ww) in enumerate(zip(o, w)):
                if ww <= 0:
                    f = 1.0                     # WorldClim sem chuva no mês: nada a multiplicar
                else:
                    f = oo / ww
                    if ww < PREC_SECO_MM:       # mês muito seco: razão instável
                        f = min(max(f, FATOR_LIMITES[0]), FATOR_LIMITES[1])
                if f != (oo / ww if ww > 0 else None):
                    limitados.append(i + 1)
                fator.append(f)
        out[var] = {"metodo": metodo, "observado": o, "worldclim": w, "delta": delta, "fator": fator,
                    "fator_limitado": limitados or [],
                    "pearson": pearson(o, w), "vies_medio": float(np.mean(delta)),
                    "mae": float(np.mean(np.abs(delta))),
                    "n_estacoes": [m["n_estacoes"] for m in obs[var]],
                    "n_ocorrencias": [m["n_ocorrencias"] for m in obs[var]]}
    return out


def corrigir(arr: np.ndarray, var: str, mes: int, aj: dict) -> tuple[np.ndarray, int]:
    out = arr.copy()
    ok = np.isfinite(out)
    if aj["metodo"] == "multiplicativo":
        out[ok] = out[ok] * aj["fator"][mes - 1]
    else:
        out[ok] = out[ok] + aj["delta"][mes - 1]
    negativos = 0
    if var == "prec":
        neg = ok & (out < 0)
        negativos = int(neg.sum())
        out[neg] = 0.0
    return out, negativos


# ----------------------------------------------------------------------------- saídas tabulares
def _motivo_en(t: str) -> str:
    return re.sub(r"(\d),(\d)", r"\1.\2", t.replace(" em ", " in "))


def _csv(caminho: Path, linhas: list[dict]) -> Path:
    caminho.parent.mkdir(parents=True, exist_ok=True)
    with caminho.open("w", encoding="utf-8-sig", newline="") as fh:
        if linhas:
            w = csv.DictWriter(fh, fieldnames=list(linhas[0]), delimiter=";")
            w.writeheader()
            w.writerows(linhas)
    return caminho


def _n(x, d=2, lang="pt"):
    if x is None or (isinstance(x, float) and math.isnan(x)):
        return "—"
    t = f"{x:.{d}f}"
    return t.replace(".", ",") if lang == "pt" else t


def _sinal(x, d=2, lang="pt"):
    return ("+" if x is not None and x >= 0 else "") + _n(x, d, lang)


def escrever_tabelas(dest: Path, linhas_sel: list[dict], obs: dict, aj: dict, cfg: dict, local: S.Local) -> list[Path]:
    arquivos = []
    for lang in cfg["idiomas"]:
        pt = lang == "pt"
        cab = (("codigo", "nome", "uf", "tipo", "latitude", "longitude", "altitude_m", "distancia_km", "na_uf",
                "no_raio", "selecionada", "meses_tmax", "meses_tmin", "meses_prec", "altitude_usada_m",
                "ajuste_altitude_C", "r_tmax", "r_tmin", "r_prec", "motivo_exclusao") if pt else
               ("code", "name", "state", "type", "latitude", "longitude", "altitude_m", "distance_km", "same_state",
                "within_radius", "selected", "months_tmax", "months_tmin", "months_prec", "altitude_used_m",
                "altitude_adjustment_C", "r_tmax", "r_tmin", "r_prec", "exclusion_reason"))
        rows = [dict(zip(cab, (l["codigo"], l["nome"], l["uf"], l["tipo"] if pt else
                               {"convencional": "conventional", "automática": "automatic"}[l["tipo"]],
                               round(l["lat"], 5), round(l["lon"], 5), l["altitude"], round(l["distancia_km"], 1),
                               l["na_uf"], l["no_raio"], l["selecionada"], l["meses_tmax"], l["meses_tmin"],
                               l["meses_prec"], None if l.get("altitude_usada") is None else round(l["altitude_usada"], 1),
                               None if l.get("ajuste_altitude") is None else round(l["ajuste_altitude"], 3),
                               *[None if (l.get("r") or {}).get(v) is None else round(l["r"][v], 3)
                                 for v in ("tmax", "tmin", "prec")],
                               l.get("motivo", "") if pt else _motivo_en(l.get("motivo", "")))))
                for l in linhas_sel]
        arquivos.append(_csv(dest / f"estacoes_{lang}.csv", rows))
        meses = MESES_PT if pt else MESES_EN
        rows = []
        for var, ms in obs.items():
            for i, m in enumerate(ms):
                rows.append({("variavel" if pt else "variable"): B.rotulo(var, lang), ("mes" if pt else "month"): meses[i],
                             ("media_regional" if pt else "regional_mean"): None if m["valor"] is None else round(m["valor"], 3),
                             ("n_estacoes" if pt else "n_stations"): m["n_estacoes"],
                             ("n_ocorrencias" if pt else "n_occurrences"): m["n_ocorrencias"]})
        arquivos.append(_csv(dest / f"medias_regionais_observadas_{lang}.csv", rows))
        for var, a in aj.items():
            rows = [{("mes" if pt else "month"): meses[i],
                     ("media_historica_estacoes" if pt else "historical_mean_stations"): round(a["observado"][i], 3),
                     ("media_historica_worldclim" if pt else "historical_mean_worldclim"): round(a["worldclim"][i], 3),
                     "DC": round(a["delta"][i], 3),
                     **({("fator" if pt else "factor"): round(a["fator"][i], 4)} if a["fator"] else {}),
                     ("n_estacoes" if pt else "n_stations"): a["n_estacoes"][i]} for i in range(12)]
            arquivos.append(_csv(dest / f"delta_{var}_{lang}.csv", rows))
        rows = [{("variavel" if pt else "variable"): B.rotulo(v, lang),
                 ("metodo" if pt else "method"): a["metodo"] if pt else METODO_EN.get(a["metodo"], a["metodo"]),
                 ("r_pearson"): None if a["pearson"] is None else round(a["pearson"], 3),
                 ("vies_medio" if pt else "mean_bias"): round(a["vies_medio"], 3), "MAE": round(a["mae"], 3)}
                for v, a in aj.items()]
        arquivos.append(_csv(dest / f"correlacao_{lang}.csv", rows))
        arquivos.append(_relatorio(dest / f"relatorio_correcao_vies_{lang}.md", lang, linhas_sel, obs, aj, cfg, local))
    return arquivos


def _relatorio(caminho: Path, lang: str, linhas: list[dict], obs: dict, aj: dict, cfg: dict, local: S.Local) -> Path:
    pt = lang == "pt"
    sel = [l for l in linhas if l["selecionada"]]
    crit = S.CRITERIOS[cfg["criterio"]].format(raio=cfg.get("raio_usado", cfg["raio_km"]))
    if cfg.get("raio_usado", cfg["raio_km"]) > cfg["raio_km"]:
        crit += (f" (ampliado a partir de {cfg['raio_km']:g} km)" if pt else f" (widened from {cfg['raio_km']:g} km)")
    alt = cfg.get("altitude")
    meses = MESES_PT if pt else MESES_EN
    L = [("# Correção de viés – método Delta regional e correlação" if pt else
          "# Bias correction – regional Delta method and correlation"), "",
         (f"- **Local:** {local.descricao} (UF: {', '.join(local.ufs)})" if pt else
          f"- **Location:** {local.descricao} (state: {', '.join(local.ufs)})"),
         (f"- **Critério de seleção:** {crit}" if pt else f"- **Selection criterion:** {crit.replace('mesma UF', 'same state').replace(' ou ', ' or ').replace(' e ', ' and ').replace('até', 'up to')}"),
         (f"- **Período observado:** {cfg['ano0']}–{cfg['ano1']} (histórico WorldClim v2.1: 1970–2000); mínimo de "
          f"{cfg['min_meses']} meses válidos por estação e variável" if pt else
          f"- **Observed period:** {cfg['ano0']}–{cfg['ano1']} (WorldClim v2.1 historical: 1970–2000); minimum of "
          f"{cfg['min_meses']} valid months per station and variable"),
         (f"- **Correlação mínima por estação:** r ≥ {_n(cfg['r_min_estacao'], 2, lang)} entre as 12 médias mensais da "
          "estação e as do WorldClim em Tmax, Tmin e Prec; a estação abaixo disso em qualquer uma sai por inteiro" if pt else
          f"- **Minimum correlation per station:** r ≥ {_n(cfg['r_min_estacao'], 2, lang)} between the station's 12 "
          "monthly means and WorldClim's in Tmax, Tmin and Prec; a station below it in any of them is left out"),
         ((f"- **Ajuste de altitude:** temperaturas das estações levadas à altitude média da área "
           f"({_n(alt['z_area_m'], 0, lang)} m, elevação do WorldClim) por {_n(alt['gradiente_C_100m'], 2, lang)} °C/100 m"
           if pt else
           f"- **Altitude adjustment:** station temperatures brought to the mean altitude of the area "
           f"({_n(alt['z_area_m'], 0, lang)} m, WorldClim elevation) at {_n(alt['gradiente_C_100m'], 2, lang)} °C/100 m")
          if alt else ("- **Ajuste de altitude:** não aplicado" if pt else "- **Altitude adjustment:** not applied")),
         (f"- **Média regional:** {MEDIAS[cfg['media']]}; mínimo de {cfg['min_anos']} ano(s) por estação e mês" if pt else
          f"- **Regional mean:** {'sum of all monthly station values ÷ number of occurrences (article)' if cfg['media'] == 'agrupada' else 'mean of each station mean'}; minimum of {cfg['min_anos']} year(s) per station and month"),
         (f"- **Correção:** DC = média das estações − média WorldClim (aditiva{'; precipitação multiplicativa: fator = estações ÷ WorldClim, limitado a 0,5–2,0 nos meses com WorldClim < 10 mm' if cfg['metodo_prec'] == 'multiplicativo' else ''})" if pt else
          f"- **Correction:** DC = station mean − WorldClim mean (additive{'; multiplicative for precipitation: factor = stations ÷ WorldClim, limited to 0.5–2.0 in months with WorldClim < 10 mm' if cfg['metodo_prec'] == 'multiplicativo' else ''})"),
         (f"- **Método:** {METODO}" if pt else "- **Method:** Lima et al. (2026), Land Degradation & Development, doi:10.1002/ldr.70808, section 2.6"),
         *([(f"- **Rasters da Fase 1:** {cfg['zip_fase1']['nome']} (SHA-256 `{cfg['zip_fase1']['sha256']}`)" if pt else
             f"- **Phase 1 rasters:** {cfg['zip_fase1']['nome']} (SHA-256 `{cfg['zip_fase1']['sha256']}`)")]
           if cfg.get("zip_fase1") else []),
         (f"- **Banco do INMET:** {', '.join(Path(b).name for b in cfg['banco'])}" if pt else
          f"- **INMET database:** {', '.join(Path(b).name for b in cfg['banco'])}"),
         "", (f"## Estações selecionadas ({len(sel)})" if pt else f"## Selected stations ({len(sel)})"), "",
         ("| Código | Estação | UF | Tipo | Distância (km) | Altitude (m) | Ajuste T (°C) | Meses Tmax/Tmin/Prec |" if pt else
          "| Code | Station | State | Type | Distance (km) | Altitude (m) | T adjustment (°C) | Months Tmax/Tmin/Prec |"),
         "|---|---|---|---|---:|---:|---:|---|"]
    for l in sel:
        tipo = l["tipo"] if pt else {"convencional": "conventional", "automática": "automatic"}[l["tipo"]]
        L.append(f"| {l['codigo']} | {l['nome']} | {l['uf']} | {tipo} | {_n(l['distancia_km'], 1, lang)} | "
                 f"{_n(l.get('altitude_usada'), 0, lang)} | {_sinal(l.get('ajuste_altitude'), 2, lang) if l.get('ajuste_altitude') is not None else '—'} | "
                 f"{l['meses_tmax']}/{l['meses_tmin']}/{l['meses_prec']} |")
    fora = [l for l in linhas if not l["selecionada"]]
    if fora:
        L += ["", ("Estações próximas não usadas: " if pt else "Nearby stations not used: ") + "; ".join(
            f"{l['nome']} ({l['codigo']}, {l['uf']}, {_n(l['distancia_km'], 1, lang)} km, "
            + (("fora do critério" if pt else "outside criterion") if not l["atende_criterio"] else
               (l["motivo"] if pt else _motivo_en(l["motivo"])) if l.get("motivo") else
               (f"menos de {cfg['min_meses']} meses no período" if pt else
                f"fewer than {cfg['min_meses']} months in the period")) + ")" for l in fora)]
    tit = {"tmax": ("Tmax", "°C"), "tmin": ("Tmin", "°C"), "prec": ("Prec", "mm")}
    for i, (var, a) in enumerate(aj.items(), start=1):
        nome, un = tit[var]
        r = a["pearson"]
        mult = a["fator"] is not None
        L += ["", (f"## Tabela {i} – Correção mensal de viés (método Delta) para {nome}" if pt else
                   f"## Table {i} – Monthly bias correction (Delta method) for {nome}"), "",
              (f"| Mês | Média histórica das estações ({un}) | Média histórica WorldClim 1 km ({un}) | DC |"
               + (" Fator aplicado |" if mult else "") if pt else
               f"| Month | Historical station mean ({un}) | Historical WorldClim 1 km mean ({un}) | DC |"
               + (" Applied factor |" if mult else "")),
              "|---|---:|---:|---:|" + ("---:|" if mult else "")]
        for m in range(12):
            L.append(f"| {meses[m]} | {_n(a['observado'][m], 2, lang)} | {_n(a['worldclim'][m], 2, lang)} | "
                     f"{_sinal(a['delta'][m], 2, lang)} |"
                     + (f" {_n(a['fator'][m], 3, lang)}{'*' if (m + 1) in a.get('fator_limitado', []) else ''} |"
                        if mult else ""))
        if mult and a.get("fator_limitado"):
            L += ["", ("\\* fator limitado a 0,5–2,0 (mês com WorldClim < 10 mm)." if pt else
                       "\\* factor limited to 0.5–2.0 (month with WorldClim < 10 mm).")]
        L += ["", (f"r de Pearson (12 médias mensais) = **{_n(r, 3, lang)}**; viés médio = {_sinal(a['vies_medio'], 2, lang)} {un}; "
                   f"MAE = {_n(a['mae'], 2, lang)} {un}." if pt else
                   f"Pearson's r (12 monthly means) = **{_n(r, 3, lang)}**; mean bias = {_sinal(a['vies_medio'], 2, lang)} {un}; "
                   f"MAE = {_n(a['mae'], 2, lang)} {un}.")]
    sec = [v for v in obs if v not in B.PRINCIPAIS]
    if sec:
        L += ["", ("## Médias regionais observadas das demais variáveis" if pt else "## Observed regional means of other variables"),
              "", "| " + ("Variável" if pt else "Variable") + " | " + " | ".join(meses) + " |", "|---|" + "---:|" * 12]
        for v in sec:
            L.append(f"| {B.rotulo(v, lang)} | " + " | ".join(_n(m['valor'], 1, lang) for m in obs[v]) + " |")
    L += ["", ("_DC positivo: o WorldClim subestima o observado. Correlação calculada entre as 12 médias mensais "
               "regionais (sazonalidade), como no artigo._" if pt else
               "_Positive DC: WorldClim underestimates the observations. Correlation computed between the 12 regional "
               "monthly means (seasonality), as in the article._")]
    caminho.write_text("\n".join(L) + "\n", encoding="utf-8")
    return caminho


def gravar_estacoes_gpkg(caminho: Path, linhas: list[dict], local: S.Local) -> Path:
    from osgeo import ogr
    if caminho.exists():
        caminho.unlink()
    ds = ogr.GetDriverByName("GPKG").CreateDataSource(str(caminho))
    lyr = ds.CreateLayer("estacoes_inmet", geo.srs_wgs84(), ogr.wkbPoint)
    for nome, tipo in (("codigo", ogr.OFTString), ("nome", ogr.OFTString), ("uf", ogr.OFTString),
                       ("tipo", ogr.OFTString), ("dist_km", ogr.OFTReal), ("selecion", ogr.OFTInteger),
                       ("m_tmax", ogr.OFTInteger), ("m_tmin", ogr.OFTInteger), ("m_prec", ogr.OFTInteger)):
        lyr.CreateField(ogr.FieldDefn(nome, tipo))
    for l in linhas:
        f = ogr.Feature(lyr.GetLayerDefn())
        for k, v in (("codigo", l["codigo"]), ("nome", l["nome"]), ("uf", l["uf"]), ("tipo", l["tipo"]),
                     ("dist_km", round(l["distancia_km"], 2)), ("selecion", int(l["selecionada"])),
                     ("m_tmax", l["meses_tmax"]), ("m_tmin", l["meses_tmin"]), ("m_prec", l["meses_prec"])):
            f.SetField(k, v)
        g = ogr.Geometry(ogr.wkbPoint)
        g.AddPoint_2D(l["lon"], l["lat"])
        f.SetGeometry(g)
        lyr.CreateFeature(f)
    if local.tipo == "ponto":
        lp = ds.CreateLayer("local", geo.srs_wgs84(), ogr.wkbPoint)
        lp.CreateField(ogr.FieldDefn("descricao", ogr.OFTString))
        f = ogr.Feature(lp.GetLayerDefn())
        f.SetField("descricao", local.descricao)
        g = ogr.Geometry(ogr.wkbPoint)
        g.AddPoint_2D(local.lon, local.lat)
        f.SetGeometry(g)
        lp.CreateFeature(f)
    ds = None
    return caminho


# ----------------------------------------------------------------------------- execução
def _origem_rotulo(cfg: dict, origem: Path) -> str:
    z = cfg.get("zip_fase1")
    return f"{z['arquivo']} (SHA-256 {z['sha256']})" if z else str(origem.resolve())


def executar(cfg: dict, progresso=None, cancelado=None) -> dict:
    cfg = {**PADRAO, **{k: v for k, v in cfg.items() if v is not None}}
    prog = _Progresso(progresso, cancelado)
    avisos: list[str] = []
    erros: list[str] = []
    origem = Path(cfg["cenarios"])
    saida = Path(cfg["saida"])
    prog(0, "Lendo a pasta de cenários")
    man_p = origem / M.MANIFESTO
    if not man_p.exists():
        raise ErroValidacao([f"'{origem}' não é uma pasta de cenários (Fase 1) (falta {M.MANIFESTO}). Use a pasta "
                             "gerada pela Fase 1."])
    man_o = json.loads(man_p.read_text(encoding="utf-8"))
    if man_o.get("estrutura") != M.ESTRUTURA:
        raise ErroValidacao(["A pasta de cenários foi gerada por uma versão anterior do complemento; gere-a de novo "
                             "com a Fase 1 desta versão."])
    if man_o.get("correcao_vies"):
        raise ErroValidacao(["A pasta informada já está corrigida. Informe a pasta de cenários original."])
    if cfg["aplicar"]:
        if saida.resolve() == origem.resolve():
            raise ErroValidacao(["A pasta corrigida deve ser diferente da pasta de cenários original."])
        if saida.exists() and any(saida.iterdir()):
            raise ErroValidacao([f"A pasta de saída '{saida}' já contém arquivos; use uma pasta vazia."])
    if not (1900 <= cfg["ano0"] <= cfg["ano1"] <= 2100):
        erros.append("Período inválido.")
    if cfg["ano0"] != 1970 or cfg["ano1"] != 2000:
        avisos.append(f"Período observado {cfg['ano0']}–{cfg['ano1']}: o histórico do WorldClim v2.1 é 1970–2000.")
    area, e = geo.ler_vetor_area(origem / C.PASTAS["entradas"] / "area_estudo.gpkg")
    if area is None:
        erros += e or ["A pasta de cenários não tem a área de estudo (entradas/area_estudo.gpkg)."]
    if erros:
        raise ErroValidacao(erros)

    prog(3, "Lendo o banco do INMET")
    estacoes, av = B.ler_banco(cfg["banco"], progresso=lambda k, n: prog(3 + 17 * k / max(n, 1), "Lendo o banco do INMET"))
    avisos += av
    if not estacoes:
        raise ErroValidacao(["Nenhuma estação do BDMEP encontrada no banco informado (pastas, .zip ou .csv)."])

    prog(20, "Selecionando as estações")
    lt = cfg["local"]
    if lt.get("tipo") == "nome":
        local = S.local_nome(lt.get("nome", ""), estacoes)
    elif lt.get("tipo") == "coordenadas":
        local = S.local_ponto(float(lt["lat"]), float(lt["lon"]))
    else:
        local = S.local_area(area.geom, "área de estudo da pasta de cenários")
    avisos += local.avisos

    # altitude média da área (mesmos pixels da média WorldClim) e altitudes das estações
    hist_ref = next((origem / c["raster"] for c in man_o["camadas"]
                     if c["var"] == "tmin" and c["ssp"] == C.HIST and int(c["mes"]) == 1), None)
    z_area = None
    if cfg["ajuste_altitude"]:
        if hist_ref is None:
            raise ErroValidacao(["A pasta de cenários não tem o histórico de tmin (necessário para o ajuste de altitude)."])
        prog(21, "Elevação do WorldClim (ajuste de altitude)")
        mde = A.obter(origem, saida / C.PASTAS["entradas"] / A.ARQUIVO, area.limites, avisos)
        if mde is None:
            raise ErroValidacao(["O ajuste de altitude precisa da elevação do WorldClim (wc2.1_30s_elev), que não está "
                                 "no .zip da Fase 1 e não pôde ser baixada agora. Conecte-se à internet, refaça a "
                                 "etapa 1.1 da Fase 1 (que a salva em entradas/) ou desmarque o ajuste de altitude em "
                                 "Parâmetros avançados."])
        z_area = A.altitude_area(mde, hist_ref)
    gamma = float(cfg["gradiente"]) / 100.0          # °C/m

    wc = {v: media_worldclim(origem, man_o["camadas"], v) for v in B.PRINCIPAIS}
    r_min = float(cfg["r_min_estacao"] or 0)
    raio = float(cfg["raio_km"])
    ampliar = cfg["criterio"] == "raio" and float(cfg["raio_max"] or 0) > raio
    while True:
        linhas = S.selecionar(estacoes, local, cfg["criterio"], raio, cfg["ano0"], cfg["ano1"], int(cfg["min_meses"]))
        for l in linhas:      # estação com r baixo em alguma variável principal sai por inteiro
            l["r"] = r_estacao(l["estacao"], wc, cfg["ano0"], cfg["ano1"], int(cfg["min_meses"])) \
                if l["selecionada"] else {}
            baixos = {v: r for v, r in l["r"].items() if r is not None and r < r_min}
            if baixos:
                l["selecionada"] = False
                l["motivo"] = ("r < " + f"{r_min:g}".replace(".", ",") + " em "
                               + ", ".join(f"{v} ({r:.2f})".replace(".", ",") for v, r in baixos.items()))
        sel = [l["estacao"] for l in linhas if l["selecionada"]]
        alt_usada, av_alt, ajuste = {}, [], None
        if z_area is not None:
            alt_usada, av_alt = A.altitudes_validas(sel, estacoes)
            ajuste = {c: (None if z is None else gamma * (z - z_area)) for c, z in alt_usada.items()}
        obs = medias_regionais(sel, cfg["ano0"], cfg["ano1"], cfg["media"], int(cfg["min_anos"]),
                               B.ordem_variaveis(), int(cfg["min_meses"]), ajuste)
        poucas = [v for v in B.PRINCIPAIS
                  if v not in obs or min(m["n_estacoes"] for m in obs[v]) < int(cfg["min_estacoes"])]
        if not sel and ampliar and raio < float(cfg["raio_max"]):
            raio = min(raio + 100.0, float(cfg["raio_max"]))
            continue
        if not poucas or not ampliar or raio >= float(cfg["raio_max"]):
            break
        raio = min(raio + 100.0, float(cfg["raio_max"]))
    cfg["raio_usado"] = raio
    if raio > float(cfg["raio_km"]):
        avisos.append(f"Raio ampliado de {cfg['raio_km']:g} para {raio:g} km para ter ao menos {cfg['min_estacoes']} "
                      "estações por mês em Tmax, Tmin e Prec.")
    if poucas:
        avisos.append(f"Com {raio:g} km, há mês com menos de {cfg['min_estacoes']} estações em: "
                      + ", ".join(poucas) + ".")
    avisos += av_alt
    excl = [l for l in linhas if l.get("motivo")]
    if excl:
        avisos.append(f"{len(excl)} estação(ões) retirada(s) por correlação com o WorldClim abaixo de "
                      f"{r_min:g}: ".replace(".", ",")
                      + "; ".join(f"{l['codigo']} {l['nome']} – {l['motivo']}" for l in excl) + ".")
    for l in linhas:
        z = alt_usada.get(l["codigo"]) if l["selecionada"] else None
        l["altitude_usada"] = z
        l["ajuste_altitude"] = None if (z is None or z_area is None) else gamma * (z - z_area)
    if not sel and excl:
        raise ErroValidacao([f"Todas as estações com dados até {raio:g} km foram retiradas por correlação com o "
                             f"WorldClim abaixo de {r_min:g}".replace(".", ",") + ": "
                             + "; ".join(f"{l['codigo']} {l['nome']} – {l['motivo']}" for l in excl[:12])
                             + ". Confira a área de estudo e o histórico da Fase 1 ou reduza a correlação mínima em "
                               "Parâmetros avançados."])
    if not sel:
        raise ErroValidacao([f"Nenhuma estação com ao menos {cfg['min_meses']} meses de dados em {cfg['ano0']}–"
                             f"{cfg['ano1']} atende ao critério ({S.CRITERIOS[cfg['criterio']].format(raio=raio)}) "
                             f"para {local.descricao}. Aumente o raio ou reduza o mínimo de meses."])

    prog(25, "Médias regionais")
    faltam = [f"{v} ({', '.join(MESES_PT[i] for i, m in enumerate(obs.get(v, [{}] * 12)) if m.get('valor') is None)})"
              for v in B.PRINCIPAIS if v not in obs or any(m["valor"] is None for m in obs[v])]
    if faltam:
        raise ErroValidacao(["As estações selecionadas não têm dados de todos os meses para: " + "; ".join(faltam)
                             + ". Aumente o raio, mude o critério ou reduza o mínimo de meses ou de anos."])
    for v in B.PRINCIPAIS:
        if min(m["n_estacoes"] for m in obs[v]) == 1:
            avisos.append(f"{v}: há mês com uma única estação na média regional.")
    cfg["altitude"] = None if z_area is None else {
        "z_area_m": z_area, "gradiente_C_100m": float(cfg["gradiente"]),
        "fonte": "WorldClim v2.1 wc2.1_30s_elev (média nos pixels do histórico recortado)",
        "estacoes": {l["codigo"]: {"altitude_cadastro_m": l["altitude"], "altitude_usada_m": l["altitude_usada"],
                                   "ajuste_C": l["ajuste_altitude"]} for l in linhas if l["selecionada"]}}
    aj = ajustes(obs, wc, cfg["metodo_prec"])
    for v, a in aj.items():
        if a["pearson"] is not None and a["pearson"] < 0.7:
            avisos.append(f"{v}: correlação baixa entre estações e WorldClim (r = {a['pearson']:.3f}); confira as estações.")

    dest_tab = saida / PASTA_TABELAS
    dest_tab.mkdir(parents=True, exist_ok=True)
    arquivos = escrever_tabelas(dest_tab, linhas, obs, aj, cfg, local)
    arquivos.append(gravar_estacoes_gpkg(dest_tab / "estacoes_inmet.gpkg", linhas, local))
    resumo_corr = {
        "metodo": METODO, "local": {"tipo": local.tipo, "descricao": local.descricao, "ufs": local.ufs,
                                     "lat": local.lat, "lon": local.lon},
        "criterio": S.CRITERIOS[cfg["criterio"]].format(raio=cfg["raio_usado"]), "periodo": [cfg["ano0"], cfg["ano1"]],
        "raio_inicial_km": cfg["raio_km"], "raio_usado_km": cfg["raio_usado"], "min_meses_por_estacao": cfg["min_meses"],
        "r_min_estacao": cfg["r_min_estacao"],
        "estacoes_retiradas_por_r": {l["codigo"]: l["motivo"] for l in linhas if l.get("motivo")},
        "ajuste_altitude": cfg["altitude"],
        "media_regional": MEDIAS[cfg["media"]], "min_anos": cfg["min_anos"],
        "estacoes": [{"codigo": e.codigo, "nome": e.nome, "uf": e.uf} for e in sel],
        "ajustes": {v: {k: a[k] for k in ("metodo", "observado", "worldclim", "delta", "fator", "fator_limitado",
                                          "pearson", "vies_medio", "mae")} for v, a in aj.items()},
        "pasta_original": _origem_rotulo(cfg, origem), "manifesto_original_sha256": sha256(man_p),
        "banco": [str(b) for b in cfg["banco"]],
    }
    if cfg.get("zip_fase1"):   # entrada: .zip da Fase 1 compactado pelo usuário (com SHA-256)
        resumo_corr["entrada_fase1_zip"] = cfg["zip_fase1"]
    n_grupos = n_png = n_neg = 0
    if cfg["aplicar"]:
        n_grupos, n_png, n_neg = _aplicar(origem, saida, man_o, aj, cfg, avisos, prog, resumo_corr, sel)
        if n_neg:
            avisos.append(f"Precipitação: {n_neg} pixel(s)-mês ficaram negativos após somar o delta e foram "
                          "ajustados para 0 mm.")
    extremos = [f"{MESES_PT[i]} ({f:.2f})".replace(".", ",") for i, f in enumerate(aj["prec"]["fator"] or [])
                if (i + 1) not in aj["prec"]["fator_limitado"] and not FATOR_LIMITES[0] <= f <= FATOR_LIMITES[1]]
    if extremos:
        avisos.append("Precipitação: fator fora de 0,5–2,0 em " + ", ".join(extremos) + "; confira se as estações "
                      "representam a área.")
    if aj["prec"]["fator_limitado"]:
        avisos.append("Precipitação: fator limitado a 0,5–2,0 nos meses muito secos (WorldClim < 10 mm): "
                      + ", ".join(MESES_PT[m - 1] for m in aj["prec"]["fator_limitado"]) + ".")
    (dest_tab / "correcao_vies.json").write_text(json.dumps({**resumo_corr, "avisos": avisos,
                                                             "versao": cfg["versao"], "versoes": _versoes(),
                                                             "utc": datetime.now(timezone.utc).isoformat()},
                                                            ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    prog(100, "Concluído")
    return {"situacao": "concluído com avisos" if avisos else "concluído", "avisos": avisos, "local": local,
            "linhas": linhas, "n_selecionadas": len(sel), "observado": obs, "ajustes": aj, "tabelas": str(dest_tab),
            "n_grupos": n_grupos, "n_png": n_png, "saida": str(saida)}


def _aplicar(origem: Path, saida: Path, man_o: dict, aj: dict, cfg: dict, avisos: list, prog, resumo: dict,
             sel: list) -> tuple[int, int, int]:
    (saida / C.PASTAS["entradas"]).mkdir(parents=True, exist_ok=True)
    mascara = saida / C.PASTAS["entradas"] / "area_estudo.gpkg"
    shutil.copy2(origem / C.PASTAS["entradas"] / "area_estudo.gpkg", mascara)
    mde = A.caminho_na_fase1(origem)
    if mde.exists() and not (saida / C.PASTAS["entradas"] / A.ARQUIVO).exists():
        shutil.copy2(mde, saida / C.PASTAS["entradas"] / A.ARQUIVO)
    ens_reg = ((man_o.get("ensemble") or {}).get("grupos") or {})
    grupos: dict = {}
    for cam in man_o["camadas"]:
        chave_ens = f"{cam['var']}|{cam['modelo']}|{cam['ssp']}|{cam['periodo']}"
        # ensemble com membros registrados: refeito como a média dos modelos corrigidos (= Delta aplicado ao ensemble);
        # sem registro dos membros: corrigido diretamente pelo Delta, como qualquer grupo
        if cam["var"] in aj and not (cam["modelo"] == C.ENSEMBLE and chave_ens in ens_reg):
            grupos.setdefault((cam["var"], cam["modelo"], cam["ssp"], cam["periodo"]), {})[int(cam["mes"])] = cam["raster"]
    ordem = sorted(grupos, key=lambda k: (k[2] != C.HIST, k[0], k[3], k[1], k[2]))
    man = {"modo": "manual", "estrutura": M.ESTRUTURA, "camadas": [], "simbologia": {}, "grade": None,
           "execucoes": [], "saidas_sha256": {}}
    # mapas por último, com escala única (cenarios/mapas.py)
    mcfg = {"idiomas": cfg["idiomas"], "gerar_mapas": False, "dpi": cfg["dpi"], "regiao": cfg["regiao"],
            "autor": cfg["autor"], "simbologia": cfg["simbologia"], "classes": {}, "qml": None, "versao": cfg["versao"]}
    alt_pt = ", ajuste de altitude" if cfg.get("altitude") else ""
    alt_en = ", altitude-adjusted" if cfg.get("altitude") else ""
    nota = {"pt": f"Corrigido pelo método Delta regional com {len(sel)} estação(ões) do INMET "
                  f"({cfg['ano0']}–{cfg['ano1']}{alt_pt}; Lima et al., 2026)",
            "en": f"Bias-corrected by the regional Delta method with {len(sel)} INMET station(s) "
                  f"({cfg['ano0']}–{cfg['ano1']}{alt_en}; Lima et al., 2026)"}
    n_png = n_neg = 0
    # 1) grava todos os rasters corrigidos
    gravados = {}
    for i, chave in enumerate(ordem):
        var, modelo, ssp, periodo = chave
        c = N.Cenario(var, modelo, ssp, periodo)
        prog(30 + 30 * i / len(ordem), f"Corrigindo {var} {periodo} {modelo} {ssp} ({i + 1}/{len(ordem)})")
        if len(grupos[chave]) != 12:
            avisos.append(f"{c.chave}: grupo incompleto na pasta original ({len(grupos[chave])} meses); ignorado.")
            continue
        destino = M.pastas_do_grupo(saida, c)["grupo"]
        mensais = {}
        for mes in range(1, 13):
            fonte = origem / grupos[chave][mes]
            a, _ = P.ler(fonte)
            corr, neg = corrigir(a, var, mes, aj[var])
            n_neg += neg
            mensais[mes] = P.gravar_como(fonte, corr, destino / Path(grupos[chave][mes]).name, c.nome(mes, "pt"),
                                         {"variavel": var, "modelo": modelo, "ssp": ssp, "periodo": periodo, "mes": mes,
                                          "correcao": f"Delta {aj[var]['metodo']} INMET",
                                          "delta": round(aj[var]["delta"][mes - 1], 4),
                                          **({"fator": round(aj[var]["fator"][mes - 1], 4)} if aj[var]["fator"] else {})})
        gravados[chave] = (c, mensais)
    mcfg["simbologia"] = dict(cfg["simbologia"] or {})
    # 3) estatísticas, layouts e PNG de cada grupo e manifesto
    for i, (chave, (c, mensais)) in enumerate(gravados.items()):
        prog(60 + 38 * i / max(len(gravados), 1), f"Estatísticas e mapas {c.chave} ({i + 1}/{len(gravados)})")
        criados = list(mensais.values())
        av_grupo: list[str] = []
        r = M.finalizar_grupo(saida, c, mensais, mcfg, man, mascara, av_grupo, lambda *_: None, criados, nota=nota)
        avisos += av_grupo
        M.registrar_grupo(saida, man, c, mensais, mcfg, r, ["correção Delta regional (INMET)"], av_grupo, criados,
                          arquivos=[grupos[chave][m] for m in range(1, 13)],
                          extra={"correcao_vies": resumo, "pasta_original": _origem_rotulo(cfg, origem),
                                 "etapa": "Cenários climáticos corrigidos – método Delta regional com estações INMET (Fase 2)"})
        n_png += r["mapas"].get("n_png", 0)
    derivadas = sorted({cam["var"] for cam in man_o["camadas"]} & {"tmed", "etp", "ia", "pci", "isc"})
    if derivadas:  # Tmed, ETP e índices (IA, PCI, ISC) refeitos a partir de Tmin, Tmax e Prec corrigidos
        from ..cenarios import derivadas as DV
        prog(98, "Tmed/ETP a partir dos dados corrigidos")
        rd = DV.calcular(saida, man, mcfg, derivadas, avisos, nota_extra=nota,
                         extra_manifesto={"correcao_vies": resumo, "pasta_original": _origem_rotulo(cfg, origem),
                                          "etapa": "Cenários climáticos corrigidos – método Delta regional com "
                                                   "estações INMET (Fase 2)"})
        n_png += rd["png"]
        avisos.append(f"{', '.join(derivadas)} recalculada(s) a partir de Tmin e Tmax corrigidos "
                      f"({rd['grupos']} grupo(s)).")
    alvos = [{"var": k.split("|")[0], "ssp": k.split("|")[2], "periodo": k.split("|")[3], "membros": m}
             for k, m in ((man_o.get("ensemble") or {}).get("grupos") or {}).items()]
    if alvos:  # ensemble: média dos modelos já corrigidos (mesmos modelos da Fase 1)
        from ..cenarios import ensemble as EN
        prog(99, "Ensemble a partir dos modelos corrigidos")
        re_ = EN.calcular(saida, man, mcfg, alvos, avisos, nota_extra=nota,
                          extra_manifesto={"correcao_vies": resumo, "pasta_original": _origem_rotulo(cfg, origem),
                                           "etapa": "Cenários climáticos corrigidos – método Delta regional com "
                                                    "estações INMET (Fase 2)"})
        n_png += re_["png"]
        avisos.append(f"Ensemble refeito a partir dos modelos corrigidos ({re_['grupos']} grupo(s)).")
    if cfg["gerar_mapas"]:   # 4) mapas por último: escala única por variável, de todos os grupos corrigidos
        from ..cenarios import mapas as MP
        prog(99, "Mapas com escala única")
        rm = MP.gerar(saida, man, {**mcfg, "gerar_mapas": True}, outras=[(origem, man_o)])   # mesma escala da Fase 1
        n_png = rm["png"]
        avisos.append("Escalas de cores dos mapas corrigidos (iguais para histórico e projeções e cobrindo também a "
                      "Fase 1 sem correção): " + "; ".join(
            f"{v} {d['min']:g}–{d['max']:g}" for v, d in rm["escalas"].items()) + ".")
    return len(gravados), n_png, n_neg
