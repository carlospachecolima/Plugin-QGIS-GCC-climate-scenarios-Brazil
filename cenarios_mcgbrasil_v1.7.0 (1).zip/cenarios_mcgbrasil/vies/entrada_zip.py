"""Entrada da Fase 2: o .zip com os rasters da Fase 1, compactado pelo usuário.

O usuário compacta a pasta ``1_cenarios_climaticos`` (ou a pasta do projeto inteira). Aqui se localiza, dentro do
.zip, o manifesto da Fase 1 (``manifesto_cenarios.json`` sem correção de viés, o mais raso), e se extraem para uma
pasta temporária só os arquivos dessa pasta, sem PNG, PDF e projetos .qgz. Os caminhos dos rasters no manifesto são
relativos, então a estrutura independe de onde o .zip foi criado. O SHA-256 do .zip fica registrado na Fase 2.
"""

from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path, PurePosixPath

MANIFESTO = "manifesto_cenarios.json"
IGNORAR = {".png", ".pdf", ".qgz", ".qgs", ".aux.xml"}


class ErroZip(Exception):
    pass


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def _manifesto_fase1(zf: zipfile.ZipFile) -> str:
    candidatos = []
    for n in zf.namelist():
        if PurePosixPath(n).name != MANIFESTO:
            continue
        try:
            man = json.loads(zf.read(n).decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            continue
        candidatos.append((bool(man.get("correcao_vies")), n.count("/"), n))
    if not candidatos:
        raise ErroZip(f"O .zip não contém os cenários da Fase 1 (falta {MANIFESTO}). Compacte a pasta "
                      "1_cenarios_climaticos do projeto (ou a pasta do projeto inteira).")
    fase1 = sorted(c for c in candidatos if not c[0])
    if not fase1:
        raise ErroZip("O .zip só contém cenários já corrigidos (Fase 2). Compacte a pasta 1_cenarios_climaticos.")
    return fase1[0][2]


def extrair(arquivo_zip, destino) -> tuple[Path, dict]:
    """Extrai a Fase 1 do .zip para ``destino``. Retorna (pasta de cenários, informações para o registro)."""
    arquivo_zip, destino = Path(arquivo_zip), Path(destino)
    if not arquivo_zip.is_file():
        raise ErroZip(f"Arquivo não encontrado: {arquivo_zip}")
    try:
        zf = zipfile.ZipFile(arquivo_zip)
    except zipfile.BadZipFile:
        raise ErroZip(f"{arquivo_zip.name} não é um .zip válido.") from None
    with zf:
        man_nome = _manifesto_fase1(zf)
        prefixo = man_nome[: -len(MANIFESTO)]
        base = destino.resolve()
        n = 0
        for info in zf.infolist():
            nome = info.filename
            if info.is_dir() or not nome.startswith(prefixo):
                continue
            rel = nome[len(prefixo):]
            if any(rel.lower().endswith(s) for s in IGNORAR):
                continue
            alvo = (base / rel).resolve()
            if base != alvo and base not in alvo.parents:   # caminho malicioso (../)
                raise ErroZip(f"Caminho inválido dentro do .zip: {nome}")
            alvo.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(info) as src, open(alvo, "wb") as dst:
                while True:
                    b = src.read(1 << 20)
                    if not b:
                        break
                    dst.write(b)
            n += 1
    man = json.loads((base / MANIFESTO).read_text(encoding="utf-8"))
    faltam = [c["raster"] for c in man.get("camadas", []) if not (base / c["raster"]).exists()]
    if not (base / "entradas" / "area_estudo.gpkg").exists():
        raise ErroZip("O .zip não traz a área de estudo da Fase 1 (entradas/area_estudo.gpkg). Compacte a pasta "
                      "1_cenarios_climaticos inteira.")
    info = {"arquivo": str(arquivo_zip.resolve()), "nome": arquivo_zip.name, "sha256": sha256(arquivo_zip),
            "pasta_no_zip": prefixo.rstrip("/") or ".", "arquivos_extraidos": n,
            "rasters_no_manifesto": len(man.get("camadas", [])), "rasters_ausentes": len(faltam)}
    return base, info
