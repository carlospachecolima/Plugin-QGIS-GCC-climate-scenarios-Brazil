"""Referências do IBGE embutidas: municípios (nome, UF, sede) e limites das UFs.

Ver ``dados/LEIAME_dados.md`` para fontes e licenças.
"""

from __future__ import annotations

import csv
import math
import unicodedata
from functools import lru_cache
from pathlib import Path

from osgeo import ogr, osr

DADOS = Path(__file__).resolve().parent.parent / "dados"
RAIO_TERRA_KM = 6371.0088
EXCECOES_UF = {"A650": "ES"}  # Ilha da Trindade (fora de qualquer polígono; o mais próximo seria a BA)
UFS = ("AC", "AL", "AM", "AP", "BA", "CE", "DF", "ES", "GO", "MA", "MG", "MS", "MT", "PA", "PB", "PE", "PI", "PR", "RJ",
       "RN", "RO", "RR", "RS", "SC", "SE", "SP", "TO")


def normalizar(txt: str) -> str:
    t = unicodedata.normalize("NFKD", txt or "").encode("ascii", "ignore").decode().upper()
    return " ".join(t.replace("-", " ").replace("'", " ").split())


def haversine_km(lat1, lon1, lat2, lon2) -> float:
    p = math.pi / 180
    a = math.sin((lat2 - lat1) * p / 2) ** 2 + math.cos(lat1 * p) * math.cos(lat2 * p) * math.sin((lon2 - lon1) * p / 2) ** 2
    return 2 * RAIO_TERRA_KM * math.asin(math.sqrt(a))


@lru_cache(maxsize=1)
def municipios() -> list[dict]:
    with (DADOS / "municipios_ibge.csv").open(encoding="utf-8") as fh:
        return [{"codigo": r["codigo_ibge"], "nome": r["nome"], "uf": r["uf"], "lat": float(r["latitude"]),
                 "lon": float(r["longitude"]), "chave": normalizar(r["nome"])} for r in csv.DictReader(fh)]


@lru_cache(maxsize=1)
def _poligonos_uf() -> list:
    ds = ogr.Open(str(DADOS / "ufs_ibge.gpkg"))
    if ds is None:
        raise RuntimeError("Limites das UFs (dados/ufs_ibge.gpkg) não encontrados no complemento.")
    lyr = ds.GetLayer(0)
    out = []
    for f in lyr:
        g = f.GetGeometryRef().Clone()
        out.append((f.GetField("uf"), g, g.GetEnvelope()))
    ds = None
    return out


def uf_do_ponto(lon: float, lat: float, codigo: str = "") -> tuple[str, float]:
    """(UF, distância em km até o polígono; 0 se dentro). Pontos no mar recebem a UF mais próxima."""
    if codigo in EXCECOES_UF:
        return EXCECOES_UF[codigo], 0.0
    pt = ogr.Geometry(ogr.wkbPoint)
    pt.AddPoint_2D(lon, lat)
    for uf, g, (x0, x1, y0, y1) in _poligonos_uf():
        if x0 <= lon <= x1 and y0 <= lat <= y1 and g.Contains(pt):
            return uf, 0.0
    uf, g, _ = min(_poligonos_uf(), key=lambda t: t[1].Distance(pt))
    return uf, g.Distance(pt) * 111.0


def ufs_da_area(geom_wgs84: ogr.Geometry) -> list[str]:
    """UFs que a área de estudo toca."""
    x0, x1, y0, y1 = geom_wgs84.GetEnvelope()
    return sorted(uf for uf, g, (a0, a1, b0, b1) in _poligonos_uf()
                  if not (a1 < x0 or a0 > x1 or b1 < y0 or b0 > y1) and g.Intersects(geom_wgs84))


def buscar_municipio(texto: str) -> list[dict]:
    """Aceita 'Nome', 'Nome - UF', 'Nome/UF' ou 'Nome (UF)'; ignora acentos e maiúsculas."""
    t = texto.strip()
    uf = None
    for sep in ("/", " - ", "(", ","):
        if sep in t:
            a, b = t.rsplit(sep, 1)
            cand = normalizar(b.strip(" )"))
            if cand in UFS:
                t, uf = a.strip(), cand
                break
    chave = normalizar(t)
    achados = [m for m in municipios() if m["chave"] == chave and (uf is None or m["uf"] == uf)]
    return achados


def srs_wgs84() -> osr.SpatialReference:
    s = osr.SpatialReference()
    s.ImportFromEPSG(4326)
    s.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
    return s


class ProjecaoArea:
    """Área projetada uma vez (azimutal equidistante centrada nela) para medir distâncias em km."""

    def __init__(self, geom_wgs84: ogr.Geometry):
        c = geom_wgs84.Centroid()
        aeqd = osr.SpatialReference()
        aeqd.ImportFromProj4(f"+proj=aeqd +lat_0={c.GetY()} +lon_0={c.GetX()} +datum=WGS84 +units=m +no_defs")
        aeqd.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
        self.tr = osr.CoordinateTransformation(srs_wgs84(), aeqd)
        self.geom = geom_wgs84.Clone()
        self.geom.Transform(self.tr)

    def distancia_km(self, lon: float, lat: float) -> float:
        """0 dentro da área; fora, a menor distância até o contorno."""
        p = ogr.Geometry(ogr.wkbPoint)
        p.AddPoint_2D(lon, lat)
        p.Transform(self.tr)
        return 0.0 if self.geom.Contains(p) else self.geom.Distance(p) / 1000.0
