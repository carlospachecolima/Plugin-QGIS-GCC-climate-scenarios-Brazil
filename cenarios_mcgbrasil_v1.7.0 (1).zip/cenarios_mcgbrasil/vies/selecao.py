"""Escolha das estações do INMET para a média regional.

Local de mapeamento: a área de estudo (polígono), um ponto (latitude/longitude) ou um nome — município do IBGE
('Propriá', 'Propriá - SE') ou, se não houver município com esse nome, estação do INMET.

Critérios: só raio (padrão desde a v1.7.0, com ampliação na Fase 2), mesma UF OU até o raio (critério do artigo),
mesma UF E até o raio ou só UF. Só entram estações com ao menos ``min_meses`` meses válidos no período em alguma das
variáveis principais (padrão da Fase 2: 120 meses = 10 anos). Para uma área, a
distância é medida até o polígono (0 dentro dele) e "mesma UF" vale para qualquer UF que a área toque.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from osgeo import ogr

from ..comum.config import ErroValidacao
from . import referencia as R
from .banco import PRINCIPAIS, Estacao

CRITERIOS = {
    "uf_ou_raio": "mesma UF ou até {raio:g} km",
    "uf_e_raio": "mesma UF e até {raio:g} km",
    "uf": "mesma UF",
    "raio": "até {raio:g} km",
}


@dataclass
class Local:
    tipo: str            # "area" ou "ponto"
    descricao: str
    lat: float
    lon: float
    ufs: list[str]
    geom: ogr.Geometry | None = None
    avisos: list[str] = field(default_factory=list)

    def distancia_km(self, e: Estacao) -> float:
        if self.tipo != "area":
            return R.haversine_km(self.lat, self.lon, e.lat, e.lon)
        if not hasattr(self, "_proj"):
            self._proj = R.ProjecaoArea(self.geom)
        return self._proj.distancia_km(e.lon, e.lat)


def local_area(geom_wgs84: ogr.Geometry, nome: str = "área de estudo") -> Local:
    c = geom_wgs84.Centroid()
    return Local("area", nome, c.GetY(), c.GetX(), R.ufs_da_area(geom_wgs84), geom_wgs84.Clone())


def local_ponto(lat: float, lon: float, descricao: str = "") -> Local:
    if not (-35 <= lat <= 6 and -75 <= lon <= -28):
        raise ErroValidacao([f"Coordenadas fora do Brasil: latitude {lat}, longitude {lon}. Use graus decimais "
                             "(ex.: latitude −10,21; longitude −36,84)."])
    uf, dist = R.uf_do_ponto(lon, lat)
    loc = Local("ponto", descricao or f"lat {lat:.4f}, lon {lon:.4f}", lat, lon, [uf])
    if dist > 0:
        loc.avisos.append(f"O ponto está fora do território (≈{dist:.1f} km); usada a UF mais próxima ({uf}).")
    return loc


def local_nome(nome: str, estacoes: list[Estacao]) -> Local:
    achados = R.buscar_municipio(nome)
    if len(achados) == 1:
        m = achados[0]
        loc = local_ponto(m["lat"], m["lon"], f"{m['nome']} - {m['uf']} (sede municipal, IBGE)")
        loc.ufs = [m["uf"]]
        return loc
    if len(achados) > 1:
        raise ErroValidacao([f"Há {len(achados)} municípios chamados '{nome}': "
                             + ", ".join(f"{m['nome']} - {m['uf']}" for m in achados)
                             + ". Informe também a UF, ex.: 'Bonito - PE'."])
    chave = R.normalizar(nome)
    est = [e for e in estacoes if R.normalizar(e.nome) == chave] or \
          [e for e in estacoes if chave and chave in R.normalizar(e.nome)]
    if len(est) == 1:
        e = est[0]
        loc = local_ponto(e.lat, e.lon, f"estação {e.nome} ({e.codigo}, INMET)")
        return loc
    if len(est) > 1:
        raise ErroValidacao([f"'{nome}' não é um município do IBGE e corresponde a {len(est)} estações: "
                             + ", ".join(f"{e.nome} ({e.codigo})" for e in est[:12])
                             + ". Use o nome completo de uma delas ou as coordenadas."])
    raise ErroValidacao([f"'{nome}' não foi encontrado entre os municípios do IBGE nem entre as estações do banco. "
                         "Confira a grafia (acentos são opcionais) ou informe latitude e longitude."])


def selecionar(estacoes: list[Estacao], local: Local, criterio: str, raio_km: float, ano0: int, ano1: int,
               min_meses: int = 1) -> list[dict]:
    """Uma linha por estação candidata (na UF do local ou até 2× o raio), com o motivo da escolha."""
    if criterio not in CRITERIOS:
        raise ErroValidacao([f"Critério inválido: {criterio}."])
    linhas = []
    for e in estacoes:
        if not e.uf:
            e.uf, _ = R.uf_do_ponto(e.lon, e.lat, e.codigo)
        na_uf = e.uf in local.ufs
        if not na_uf and local.tipo == "ponto" and R.haversine_km(local.lat, local.lon, e.lat, e.lon) > 1.5 * raio_km:
            continue  # atalho: longe e de outra UF
        dist = local.distancia_km(e)
        no_raio = dist <= raio_km
        ok = {"uf_ou_raio": na_uf or no_raio, "uf_e_raio": na_uf and no_raio, "uf": na_uf, "raio": no_raio}[criterio]
        if not ok and dist > 1.5 * raio_km:
            continue  # fora do critério e longe: nem entra na lista (as próximas ficam, para conferência)
        meses = {v: e.n_meses_validos(v, ano0, ano1) for v in PRINCIPAIS}
        com_dado = any(n >= max(1, min_meses) for n in meses.values())
        linhas.append({"estacao": e, "codigo": e.codigo, "nome": e.nome, "uf": e.uf, "tipo": e.tipo,
                       "lat": e.lat, "lon": e.lon, "altitude": e.altitude, "distancia_km": dist,
                       "na_uf": na_uf, "no_raio": no_raio, "atende_criterio": ok, "com_dado_periodo": com_dado,
                       "selecionada": ok and com_dado, **{f"meses_{v}": n for v, n in meses.items()}})
    return sorted(linhas, key=lambda l: (not l["selecionada"], l["distancia_km"]))
