# MCGBrasil Climate Scenarios (v1.2.2)

QGIS plugin to build **climate scenarios from General Circulation Models (CMIP6) for Brazil** from WorldClim v2.1, with bias correction using INMET weather stations. Developed at Embrapa Vegetables (Embrapa Hortaliças). Portuguese version: *Cenários MCGBrasil*.

## Installation

1. QGIS 3.30 to 3.44 or QGIS 4.x (tested on 3.34 and 4.2.3): **Plugins › Manage and Install Plugins › Install from ZIP**.
2. Choose `mcgbrasil_climate_scenarios_v1.2.2.zip` and click **Install Plugin**.
3. No extra libraries are needed: the plugin uses QGIS's own GDAL and numpy.

## Use

Open the **phase workflow panel** from the toolbar icon (or *Plugins › MCGBrasil Climate Scenarios*). Choose the **project folder** once: each phase writes to its own subfolder and reads the previous one.

| Phase | What it does | Method | Status |
|---|---|---|---|
| 1 – Climate scenarios | WorldClim v2.1 clipped to the area: 1970–2000 historical data and CMIP6 projections | Fontenelle et al. (2025), *Revista DCS*, doi:10.54899/dcs.v22i83.3456 | ready |
| 2 – Delta-method bias correction | INMET stations chosen automatically, monthly delta and Pearson r | Lima et al. (2026), *Land Degrad. Dev.*, doi:10.1002/ldr.70808, section 2.6 | ready |
| 3 – Scenario trend assessment | INMET normals rates × projected rates | same, section 2.7 | ready |
| 4 – WorldClim × historical Eta comparison (optional) | WorldClim × Eta-HadGEM2-ES × INMET correlation | same, section 2.8 | under development |

### Phase 1 – selection screen (step 1.1)

Tick:

- **Variables:** Tmin, Tmax, Tmean (mean of Tmin and Tmax), Prec and Evapotranspiration (Thornthwaite method);
- **Periods:** 2021–2040, 2041–2060, 2061–2080, 2081–2100 (and the 1970–2000 historical data);
- **Scenarios:** SSP1 2.6, SSP2 4.5, SSP3 7.0, SSP5 8.5;
- **Models:** the 14 WorldClim 30″ GCMs (ACCESS-CM2, BCC-CSM2-MR, CMCC-ESM2, EC-Earth3-Veg, FIO-ESM-2-0, GFDL-ESM4, GISS-E2-1-G, HadGEM3-GC31-LL, INM-CM5-0, IPSL-CM6A-LR, MIROC6, MPI-ESM1-2-HR, MRI-ESM2-0, UKESM1-0-LL).

As you tick, the screen reports **the combinations with no WorldClim data** (FIO-ESM-2-0 and HadGEM3-GC31-LL have no SSP3 7.0; GFDL-ESM4 has no SSP2 4.5 and only precipitation under SSP5 8.5) and how many files will be downloaded. Those combinations are skipped and listed in `disponibilidade_en.txt`; the others run normally.

The plugin downloads only the box around the area, clips each month by the mask and creates, for each group of 12 months, statistics (mean, median, SD, 95% CI, area by class), a .qgz project, 12 layouts and 12 PNG in Portuguese and English. Downloaded files and processed groups are kept.

- **Tmean** = (Tmin + Tmax)/2.
- **PET** by Thornthwaite (1948) from the 12 Tmean of the same scenario, with the Willmott et al. (1985) equation for T ≥ 26.5 °C and day-length correction by each pixel's latitude. Tmean and PET need Tmin and Tmax, which are added automatically.

Other steps: **1.2** historical from a downloaded file, **1.3** projection from a downloaded image, **1.4** compute Tmean and PET for scenarios built with 1.2 and 1.3.

**Indices.** Besides Tmin, Tmax, Tmean, Prec and PET (Thornthwaite), the selection screen offers: **AI** – aridity index P/PET, monthly and annual, with the UNEP-WCMC classes (humid ≥ 0.65; dry subhumid 0.50–0.65; semi-arid 0.20–0.50; arid 0.05–0.20; hyper-arid < 0.05), as in Lima et al. (2026, *Land Degradation & Development*); **PCI** – Oliver's (1980) annual precipitation concentration index, with the uniform (≤ 10), moderate (10–15), high (15–20) and very high (> 20) classes; **ISC** – annual rainfall severity index, ISC = PCI × R/P, with R = Σ 68.730·(p²/P)^0.841 (Lima et al., 2025, *Revista Aracê*). Source variables are downloaded automatically. The annual value appears as *Annual* in files and maps. Step 1.4 computes the indices in existing projects.

**Maps and color scale.** Layouts and PNG are made last, after all rasters (including Tmean, PET and ensemble). Each variable has the same scale in every map, from historical to 2100 and in Phases 1 and 2: it runs from the minimum to the maximum of all scenarios in the project (uncorrected and corrected), so no future scenario saturates the palette and maps are comparable; a fixed scale can be set under *Advanced parameters*. Step **1.6** redoes the maps of an existing project (Phase 1 or 2), e.g. those made with earlier versions.

**Model ensemble.** On the selection screen, tick *Build model ensemble* and choose the models that enter the mean (*Same as download* copies the selection above). For existing projects, use step **1.5**, on Phase 1 (uncorrected) or Phase 2 (corrected). The ensemble is the arithmetic mean, pixel by pixel and month by month, of the selected models that have data for that scenario (equal weights); the screen shows how many models enter each SSP and which are left out (e.g., GFDL-ESM4 under SSP2 4.5). The ensemble Tmean and PET are the mean of each model's Tmean and PET. The result is stored as the model `Ensemble` (`tmax/2041-2060/Ensemble/SSP245`), with statistics, layouts and PNG; the `incerteza` subfolder holds the between-model standard deviation and range and the list of models used. Phase 2 rebuilds the ensemble from the corrected models, with the same models, and AdaptaHorts can use it like any model.

### Phase 2 – 2.1 Delta method and correlation (INMET stations)

Inputs: (1) the **.zip of the Phase 1 rasters**, which you compress (the project's `1_cenarios_climaticos` folder or the whole project; the plugin finds Phase 1 inside the .zip, skips PNG and `.qgz` and records the file's SHA-256); (2) the **output folder**, empty (or a previous Phase 2, with *Redo*). The INMET/BDMEP monthly database is bundled with the plugin (565 conventional and 598 automatic stations across Brazil, 1970–2020). Phase 3 and AdaptaHorts accept the Phase 2 output folder directly. Another database exported from the INMET portal can be used under *Advanced parameters*. Stations are chosen by distance from the mapping location (the project area, a municipality or station by name, `Propriá - SE`, or latitude/longitude): default since v1.7.0, within 200 km, no widening, keeping only stations with at least 120 months (10 years) of data in the period and Pearson r ≥ 0.8 between their monthly means and WorldClim's in Tmax, Tmin and Prec (a station failing any criterion is eliminated); the article's criterion (same state or radius) is still available. Before the regional mean, each station's temperatures are brought to the mean altitude of the area by the lapse rate (0.65 °C/100 m), using the WorldClim elevation (`wc2.1_30s_elev`, saved by step 1.1 in `entradas/` or downloaded by Phase 2). Precipitation is corrected by a multiplicative factor (observed ÷ WorldClim, limited to 0.5–2.0 in months with WorldClim < 10 mm); the article's additive method is optional. INMET files with an incomplete header are read in the standard BDMEP column order. Outputs in `<output folder>/correcao_vies/`: stations (CSV and GeoPackage), regional means, `delta_<var>_pt|en.csv` (format of the article's Tables 1–3), correlation and report. With **Apply**, every Phase 1 raster is corrected; Tmean and PET are recomputed from the corrected Tmin and Tmax.

### Phase 3 – 3.1 INMET normals rates × projected rates

The official INMET climatological normals (1961–1990, 1981–2010 and 1991–2020: Tmax, Tmin, compensated mean temperature, accumulated precipitation and potential evapotranspiration) are bundled with the plugin. By default, stations are within 200 km of the location (radius-only criterion). The comparison is always between the **raster mean** (study-area pixels) and the **mean of the normals** of the selected stations; the normals Tmean is (Tmax + Tmin)/2, same as the rasters. The **rate of increase or decrease** is computed in variable units per year, from the last year relative to the first year of the series:

rate = (last-period value − first-period value) ÷ (last year of the last period − first year of the first period)

- Normals: 1961–1990 → 1991–2020 = 59 years. PET only has normals from 1981–2010 (39 years).
- CMIP6 projections: from the project's first to last future period (2021–2040 → 2081–2100 = 79 years), per model and SSP and as the model-ensemble mean.
- Per month and for the year (mean of temperatures; sum of precipitation and PET). By default, for each month only stations with normals in both the first and last period are used (paired). If no paired station closes the 12 months, the next longest pair of periods is used and, if needed (or if a month has fewer than 3 paired stations), the radius is widened in 100 km steps up to 500 km; the report records both.
- Comparison: ratio of projected to observed annual rate and Pearson's r between the 12 monthly rates.

Outputs in `3_tendencia_normais/`: stations (CSV and GeoPackage), regional normals, `taxas_pt|en.csv`, rates per station, raster × normals comparison and report.

### Project folder

```
<project>/
    projeto_mcgbrasil.json
    1_cenarios_climaticos/   <var>/historico/WorldClim/…  and  <var>/<period>/<model>/<SSP>/…
    2_correcao_delta/        same layout, corrected, plus correcao_vies/
    3_tendencia_normais/     observed and projected rates
```

Folder names are the same in both language versions, so a project can be opened by either. The **AdaptaHorts** plugin (vegetable climate risk) uses this folder as its climate input.

## Disclaimer

Scenarios are model projections and carry uncertainty; use the model ensemble and check the results against local data before supporting decisions.

## Integrity

`SHA256SUMS.txt` lists the SHA-256 of every plugin file; the `.sha256` next to the ZIP checks the whole package (`sha256sum -c`).
